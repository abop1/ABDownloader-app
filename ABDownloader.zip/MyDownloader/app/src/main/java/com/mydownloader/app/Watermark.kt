package com.mydownloader.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/**
 * 💧 Apna watermark (jaise "AB") videos par.
 * - Reels banate waqt khud lagta hai (on ho to)
 * - "Har nayi download par" on ho to har nayi video par khud
 * - Gallery mein videos chun kar bhi laga sakte hain
 */
object Watermark {
    var on by mutableStateOf(false)
    var auto by mutableStateOf(false)
    var text by mutableStateOf("AB")
    var pos by mutableStateOf("BR")   // TL, TR, BL, BR

    private fun p(ctx: Context) = ctx.getSharedPreferences("watermark", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val s = p(ctx)
        on = s.getBoolean("on", false)
        auto = s.getBoolean("auto", false)
        text = s.getString("text", ctx.getString(R.string.owner_name)) ?: "AB"
        pos = s.getString("pos", "BR") ?: "BR"
    }

    fun save(ctx: Context) {
        p(ctx).edit().putBoolean("on", on).putBoolean("auto", auto)
            .putString("text", text).putString("pos", pos).apply()
    }

    private fun font(): String? = listOf(
        "/system/fonts/Roboto-Black.ttf", "/system/fonts/Roboto-Bold.ttf",
        "/system/fonts/Roboto-Medium.ttf", "/system/fonts/Roboto-Regular.ttf",
        "/system/fonts/DroidSans-Bold.ttf", "/system/fonts/DroidSans.ttf"
    ).firstOrNull { File(it).exists() }

    private fun escape(t: String) = t
        .replace("\\", "\\\\").replace(":", "\\:").replace("'", "\u2019")
        .replace("%", "\\%").replace(",", "\\,")

    /** ffmpeg drawtext filter (null = band ya font nahi mila) */
    fun filter(): String? {
        if (!on || text.isBlank()) return null
        val f = font() ?: return null
        val (x, y) = when (pos) {
            "TL" -> "w*0.04" to "h*0.04"
            "TR" -> "w-tw-w*0.04" to "h*0.04"
            "BL" -> "w*0.04" to "h-th-h*0.07"
            else -> "w-tw-w*0.04" to "h-th-h*0.07"
        }
        return "drawtext=fontfile=$f:text='${escape(text.trim())}':fontsize=h*0.045:" +
            "fontcolor=white@0.88:borderw=3:bordercolor=black@0.55:shadowx=2:shadowy=2:shadowcolor=black@0.4:x=$x:y=$y"
    }

    /** Video par watermark laga kar usi naam se rakhta hai. Wapas: nayi file (null = nahi laga) */
    fun apply(ctx: Context, input: File, onProgress: (Float) -> Unit = {}): File? {
        val wm = filter() ?: return null
        if (!input.exists()) return null
        val out = File(input.parentFile, input.nameWithoutExtension + ".wm.tmp.mp4")
        val ok = Ffmpeg.encode(ctx, input, out, "[0:v]$wm,format=yuv420p[v]", onProgress)
        if (!ok) { out.delete(); return null }
        val target = File(input.parentFile, input.nameWithoutExtension + ".mp4")
        input.delete()
        return if (out.renameTo(target)) target else null
    }
}

/** App ke andar wala FFmpeg chalane ka saajha tareeqa (reels, watermark) */
object Ffmpeg {
    @Volatile var current: Process? = null

    fun durationSec(f: File): Double = try {
        val r = android.media.MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        val ms = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release(); ms / 1000.0
    } catch (e: Exception) { 0.0 }

    /** filterComplex ka output label "[v]" hona chahiye. Pehle H.264, na chale to mpeg4 */
    fun encode(ctx: Context, input: File, out: File, filterComplex: String, onProgress: (Float) -> Unit): Boolean {
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so")
        val pkgs = File(ctx.noBackupFilesDir, "youtubedl-android/packages")
        val ld = "${pkgs.absolutePath}/ffmpeg/usr/lib:${pkgs.absolutePath}/python/usr/lib"
        val total = durationSec(input)
        val encoders = listOf(
            listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "23"),
            listOf("-c:v", "mpeg4", "-q:v", "3")
        )
        for (enc in encoders) {
            out.delete()
            val cmd = mutableListOf(
                bin.absolutePath, "-hide_banner", "-y", "-i", input.absolutePath,
                "-filter_complex", filterComplex, "-map", "[v]", "-map", "0:a?"
            )
            cmd += enc
            cmd += listOf("-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", out.absolutePath)
            try {
                val pb = ProcessBuilder(cmd).redirectErrorStream(true)
                pb.environment()["LD_LIBRARY_PATH"] = ld
                val p = pb.start()
                current = p
                val reader = p.inputStream.bufferedReader()
                val sb = StringBuilder()
                while (true) {
                    val c = reader.read()
                    if (c == -1) break
                    if (c == '\r'.code || c == '\n'.code) {
                        Regex("time=(\\d+):(\\d+):(\\d+\\.?\\d*)").find(sb)?.let { m ->
                            val t = m.groupValues[1].toInt() * 3600 + m.groupValues[2].toInt() * 60 + m.groupValues[3].toDouble()
                            if (total > 0) onProgress((t / total).toFloat().coerceIn(0f, 1f))
                        }
                        sb.clear()
                    } else sb.append(c.toChar())
                }
                val code = p.waitFor()
                current = null
                if (code == 0 && out.exists() && out.length() > 0) return true
            } catch (e: Exception) {
                current = null
            }
        }
        out.delete()
        return false
    }
}
