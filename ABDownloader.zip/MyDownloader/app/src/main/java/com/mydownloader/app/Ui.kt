package com.mydownloader.app

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ===== VIP Themes =====
data class VipTheme(
    val id: String, val name: String,
    val bg1: Color, val bg2: Color, val card: Color, val card2: Color,
    val c1: Color, val c2: Color, val c3: Color,
    val text: Color, val muted: Color
)

object Themes {
    val all = listOf(
        VipTheme("neon", "Neon Purple",
            Color(0xFF07030F), Color(0xFF160A2B), Color(0xFF1A1030), Color(0xFF221540),
            Color(0xFF7B2FF7), Color(0xFFB026FF), Color(0xFFFF2BD6), Color(0xFFF3E9FF), Color(0xFFA894C7)),
        VipTheme("gold", "Royal Gold",
            Color(0xFF0B0904), Color(0xFF1E1608), Color(0xFF1F1A0E), Color(0xFF2A2212),
            Color(0xFFB8860B), Color(0xFFFFC94D), Color(0xFFFFE8A3), Color(0xFFFFF6E0), Color(0xFFC9B48A)),
        VipTheme("ocean", "Ocean Blue",
            Color(0xFF020812), Color(0xFF061A33), Color(0xFF0B1F3A), Color(0xFF12294A),
            Color(0xFF1E6BFF), Color(0xFF00B4FF), Color(0xFF00F0FF), Color(0xFFE6F6FF), Color(0xFF8FB3CC)),
        VipTheme("fire", "Red Fire",
            Color(0xFF0D0303), Color(0xFF240808), Color(0xFF2A0E0E), Color(0xFF361212),
            Color(0xFFB3122E), Color(0xFFFF3B3B), Color(0xFFFF9A3C), Color(0xFFFFECE6), Color(0xFFC99A90)),
        VipTheme("emerald", "Emerald",
            Color(0xFF020B07), Color(0xFF06231A), Color(0xFF0B2A1F), Color(0xFF103528),
            Color(0xFF0F9D58), Color(0xFF2BD98B), Color(0xFFB4FF5C), Color(0xFFE9FFF4), Color(0xFF8FC4AA))
    )

    var current by mutableStateOf(all[0])

    fun load(ctx: android.content.Context) {
        val id = ctx.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE).getString("theme", "neon")
        current = all.firstOrNull { it.id == id } ?: all[0]
    }

    fun set(ctx: android.content.Context, t: VipTheme) {
        current = t
        ctx.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE).edit().putString("theme", t.id).apply()
    }
}

// ===== Rang: chuni hui theme se (badalte hi poori app badal jati hai) =====
object Neon {
    val Bg1 get() = Themes.current.bg1
    val Bg2 get() = Themes.current.bg2
    val Card get() = Themes.current.card
    val Card2 get() = Themes.current.card2
    val Violet get() = Themes.current.c1
    val Purple get() = Themes.current.c2
    val Pink get() = Themes.current.c3
    val Text get() = Themes.current.text
    val Muted get() = Themes.current.muted
    val Gold = Color(0xFFFFC94D)
    val Green = Color(0xFF3CE89A)
    val Gradient: Brush get() = Brush.horizontalGradient(listOf(Violet, Purple, Pink))
}

val qualities = listOf("Best", "1080p", "720p", "480p", "MP3")

@Composable
fun ScreenTitle(title: String, subtitle: String, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = TextStyle(brush = Neon.Gradient, fontSize = 30.sp, fontWeight = FontWeight.Black))
            Text(subtitle, color = Neon.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text.uppercase(), color = Neon.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 4.dp, top = 6.dp)
    )
}

@Composable
fun NeonCard(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Neon.Card2, Neon.Card)))
            .border(1.dp, Brush.linearGradient(listOf(Neon.Violet.copy(alpha = 0.7f), Neon.Pink.copy(alpha = 0.2f))), shape)
            .padding(16.dp),
        content = content
    )
}

/** Settings ki ek line: icon + naam + chhoti tafseel + right side control */
@Composable
fun SettingRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Neon.Violet.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Neon.Purple, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Neon.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            if (subtitle.isNotEmpty()) Text(subtitle, color = Neon.Muted, fontSize = 12.sp)
        }
        trailing()
    }
}

@Composable
fun NeonSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked, onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White, checkedTrackColor = Neon.Purple,
            uncheckedThumbColor = Neon.Muted, uncheckedTrackColor = Neon.Bg1, uncheckedBorderColor = Neon.Violet
        )
    )
}

/** Bara chamakta button (dabane par halka sa dabna + vibration) */
@Composable
fun GlowButton(
    label: String,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val haptic = LocalHapticFeedback.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.96f else 1f, label = "press")
    Box(
        modifier
            .fillMaxWidth()
            .height(56.dp)
            .scale(sc)
            .shadow(if (enabled) 22.dp else 0.dp, shape, ambientColor = Neon.Purple, spotColor = Neon.Pink)
            .clip(shape)
            .background(if (enabled) Neon.Gradient else SolidColor(Neon.Card))
            .clickable(interactionSource = src, indication = null, enabled = enabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, null, tint = if (enabled) Color.White else Neon.Muted, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text(
                label, color = if (enabled) Color.White else Neon.Muted,
                fontWeight = FontWeight.Black, fontSize = 16.sp, letterSpacing = 1.sp
            )
        }
    }
}

/** Gol icon button */
@Composable
fun IconBtn(
    icon: ImageVector,
    filled: Boolean,
    enabled: Boolean = true,
    size: Int = 36,
    tint: Color? = null,
    onClick: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .then(
                if (filled && enabled) Modifier.background(Neon.Gradient)
                else Modifier.border(1.dp, (if (enabled) Neon.Pink else Neon.Muted).copy(alpha = 0.6f), CircleShape)
            )
            .clickable(enabled = enabled) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon, null,
            tint = tint ?: if (filled && enabled) Color.White else if (enabled) Neon.Pink else Neon.Muted,
            modifier = Modifier.size((size * 0.5f).dp)
        )
    }
}

@Composable
fun NeonProgressBar(value: Float, heightDp: Int) {
    Box(Modifier.fillMaxWidth().height(heightDp.dp).clip(RoundedCornerShape(50)).background(Neon.Bg1)) {
        Box(
            Modifier.fillMaxHeight().fillMaxWidth(value.coerceIn(0f, 1f))
                .clip(RoundedCornerShape(50)).background(Neon.Gradient)
        )
    }
}

@Composable
fun NeonOutlineButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .clip(shape)
            .border(1.dp, Neon.Purple.copy(alpha = 0.6f), shape)
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Neon.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun QualityChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .clip(shape)
            .then(
                if (selected) Modifier.background(Neon.Gradient)
                else Modifier.background(Neon.Bg1.copy(alpha = 0.6f)).border(1.dp, Neon.Violet.copy(alpha = 0.45f), shape)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, color = if (selected) Color.White else Neon.Muted,
            fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

@Composable
fun NeonField(value: String, onChange: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        placeholder = { Text(hint, color = Neon.Muted, fontSize = 14.sp) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Neon.Purple,
            unfocusedBorderColor = Neon.Violet.copy(alpha = 0.4f),
            focusedTextColor = Neon.Text,
            unfocusedTextColor = Neon.Text,
            cursorColor = Neon.Pink,
            focusedContainerColor = Neon.Bg1.copy(alpha = 0.5f),
            unfocusedContainerColor = Neon.Bg1.copy(alpha = 0.5f)
        )
    )
}

/** Chhota stat dabba: bara number + label */
@Composable
fun StatBox(value: String, label: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .background(Neon.Card)
            .border(1.dp, Neon.Violet.copy(alpha = 0.35f), shape)
            .padding(vertical = 12.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, style = TextStyle(brush = Neon.Gradient, fontSize = 20.sp, fontWeight = FontWeight.Black), maxLines = 1)
        Text(label, color = Neon.Muted, fontSize = 11.sp, maxLines = 1)
    }
}

/** Neeche ki VIP navigation bar */
@Composable
fun VipBottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val haptic = LocalHapticFeedback.current
    val items = listOf(
        Icons.Rounded.Download to "Download",
        Icons.Rounded.Groups to "Creators",
        Icons.Rounded.VideoLibrary to "Gallery",
        Icons.Rounded.Insights to "Stats",
        Icons.Rounded.Settings to "Settings"
    )
    Row(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Neon.Card.copy(alpha = 0.95f), Neon.Bg1)))
            .navigationBarsPadding()
            .padding(horizontal = 6.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        items.forEachIndexed { i, (icon, label) ->
            val sel = i == selected
            val w by animateFloatAsState(if (sel) 1f else 0f, label = "nav")
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable {
                        if (!sel) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(i)
                    }
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .width((34 + 18 * w).dp)
                        .height(30.dp)
                        .clip(RoundedCornerShape(50))
                        .then(if (sel) Modifier.background(Neon.Gradient) else Modifier),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, label, tint = if (sel) Color.White else Neon.Muted, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.height(3.dp))
                Text(
                    label, fontSize = 10.sp, maxLines = 1,
                    color = if (sel) Neon.Text else Neon.Muted,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun Avatar(name: String, sizeDp: Int) {
    Box(
        Modifier.size(sizeDp.dp).clip(CircleShape).background(Neon.Gradient),
        contentAlignment = Alignment.Center
    ) {
        Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Black, fontSize = (sizeDp / 2.3).sp)
    }
}

/** Settings line ke aakhir ka ">" nishan */
@Composable
fun Chevron() = Icon(Icons.Rounded.ChevronRight, null, tint = Neon.Muted)
