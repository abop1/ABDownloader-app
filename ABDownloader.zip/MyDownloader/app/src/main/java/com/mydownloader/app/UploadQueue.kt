package com.mydownloader.app

import java.io.File

/**
 * 🚀 Upload queue: hamesha "agli" sahi video deta hai.
 * - Jo series shuru ho chuki (Part 1 post hua) pehle usay poora karo: Part 2, Part 3...
 * - Phir sabse purani download hui video se nayi series
 * - Agar video ka [Reels] version bana hua hai to wohi diya jata hai (aur dono ek hi gine jate hain)
 */
object UploadQueue {

    private val partRx = Regex(" - Part (\\d+)$")

    /** "X [Reels]" aur "X" dono ki ek pehchaan */
    private fun itemKey(f: File) =
        (f.parentFile?.absolutePath ?: "") + "/" + f.nameWithoutExtension.removeSuffix(" [Reels]")

    private fun seriesKey(f: File): String {
        val n = f.nameWithoutExtension.removeSuffix(" [Reels]").replace(partRx, "")
        return (f.parentFile?.absolutePath ?: "") + "/" + n
    }

    private fun partOf(f: File): Int =
        partRx.find(f.nameWithoutExtension.removeSuffix(" [Reels]"))?.groupValues?.get(1)?.toIntOrNull() ?: 0

    private fun isReels(f: File) = f.nameWithoutExtension.endsWith(" [Reels]")

    /** Wapas: (agli video, kitni baaqi) */
    fun next(files: List<File>, postedPaths: Set<String>): Pair<File?, Int> {
        val audio = setOf("mp3", "m4a", "opus", "aac", "wav")
        val videos = files.filter { it.extension.lowercase() !in audio }

        // Jo item (asal ya reels) post ho chuka, woh poora posted
        val postedItems = videos.filter { it.absolutePath in postedPaths }.map { itemKey(it) }.toHashSet()

        // Har item ka ek hi version: reels ho to reels
        val byItem = videos.groupBy { itemKey(it) }.mapValues { (_, v) -> v.firstOrNull { isReels(it) } ?: v.first() }
        val pending = byItem.filterKeys { it !in postedItems }.values.toList()
        if (pending.isEmpty()) return null to 0

        val postedSeries = videos.filter { itemKey(it) in postedItems }.map { seriesKey(it) }.toHashSet()
        val bySeries = pending.groupBy { seriesKey(it) }

        // 1) Adhoori series pehle, 2) phir sabse purani
        val seriesOrder = bySeries.keys.sortedWith(
            compareBy<String>({ if (it in postedSeries) 0 else 1 }, { k -> bySeries[k]!!.minOf { f -> f.lastModified() } })
        )
        val chosen = bySeries[seriesOrder.first()]!!.minWith(compareBy<File>({ partOf(it) }, { it.lastModified() }))
        return chosen to pending.size
    }
}
