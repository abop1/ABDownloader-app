package com.mydownloader.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

data class StatsData(
    val files: Int = 0,
    val bytes: Long = 0,
    val posted: Int = 0,
    val pending: Int = 0,
    val history: Int = 0,
    val dlWeek: List<Int> = List(7) { 0 },
    val postWeek: List<Int> = List(7) { 0 },
    val dayLabels: List<String> = List(7) { "" },
    val topCreators: List<Triple<String, Int, Long>> = emptyList(),
    val streak: Int = 0,
    val today: Int = 0
)

private fun dayStart(offset: Int): Long = Calendar.getInstance().apply {
    add(Calendar.DAY_OF_YEAR, -offset)
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

/** Pichle 7 din ke dabbe: index 0 = 6 din pehle, 6 = aaj */
private fun weekCounts(times: List<Long>): List<Int> {
    val starts = (6 downTo 0).map { dayStart(it) }
    val end = dayStart(-1)
    return starts.mapIndexed { i, st ->
        val en = if (i < 6) starts[i + 1] else end
        times.count { it in st until en }
    }
}

fun loadStats(ctx: android.content.Context): StatsData {
    val files = scanMedia(ctx)
    val posted = Posted.all(ctx)
    val postedCount = files.count { it.absolutePath in posted }
    val pending = UploadQueue.next(files, posted).second
    val dayNames = arrayOf("Itwar", "Pir", "Mangal", "Budh", "Jumerat", "Juma", "Hafta")
    val labels = (6 downTo 0).map { off ->
        if (off == 0) "Aaj" else {
            val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -off) }
            dayNames[c.get(Calendar.DAY_OF_WEEK) - 1].take(3)
        }
    }
    val dl = weekCounts(files.map { it.lastModified() })
    val postTimes = Posted.postedTimes(ctx)
    val pw = weekCounts(postTimes)

    // Lagataar kitne din post kiya (aaj ya kal se peeche)
    var streak = 0
    var off = if (pw[6] > 0) 0 else 1
    while (true) {
        val st = dayStart(off); val en = dayStart(off - 1)
        if (postTimes.any { it in st until en }) { streak++; off++ } else break
    }

    // Har creator ke folder mein kitni videos
    val top = Jobs.creators.map { c ->
        val dir = Engine.publicFolder(c.base, c.folder)
        val fs = files.filter { it.parentFile?.absolutePath == dir.absolutePath }
        Triple(c.name, fs.size, fs.sumOf { it.length() })
    }.filter { it.second > 0 }.sortedByDescending { it.second }.take(5)

    return StatsData(
        files = files.size, bytes = files.sumOf { it.length() },
        posted = postedCount, pending = pending,
        history = countLines(archiveFile(ctx)),
        dlWeek = dl, postWeek = pw, dayLabels = labels,
        topCreators = top, streak = streak, today = dl[6]
    )
}

@Composable
fun StatsScreen(visible: Boolean) {
    val context = LocalContext.current
    var data by remember { mutableStateOf(StatsData()) }
    LaunchedEffect(visible, Jobs.running, Jobs.singleBusy) {
        if (visible) data = withContext(Dispatchers.IO) { try { loadStats(context) } catch (e: Exception) { StatsData() } }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Stats", "Aap ka VIP record")

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatBox("${data.history}", "Kul download", Modifier.weight(1f))
            StatBox("${data.today}", "Aaj aayin", Modifier.weight(1f))
            StatBox("🔥${data.streak}", "Din ki streak", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatBox("${data.files}", "Phone mein", Modifier.weight(1f))
            StatBox(humanSize(data.bytes), "Jagah li", Modifier.weight(1f))
            StatBox("${data.pending}", "Upload baaqi", Modifier.weight(1f))
        }

        // ---- Posting ring ----
        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val total = data.posted + data.pending
                val frac = if (total == 0) 0f else data.posted.toFloat() / total
                ProgressRing(frac, Modifier.size(96.dp))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text("Posting progress", color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("✅ ${data.posted} posted", color = Neon.Green, fontSize = 13.sp)
                    Text("⏳ ${data.pending} baaqi", color = Neon.Muted, fontSize = 13.sp)
                    if (data.streak > 0) Text("🔥 ${data.streak} din se lagataar!", color = Neon.Gold, fontSize = 12.sp)
                }
            }
        }

        // ---- Charts ----
        NeonCard {
            Text("⬇ Downloads  •  pichle 7 din", color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            BarChart(data.dlWeek, data.dayLabels)
        }
        NeonCard {
            Text("🚀 Posted  •  pichle 7 din", color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            BarChart(data.postWeek, data.dayLabels)
        }

        // ---- Top creators ----
        NeonCard {
            Text("👑 Top creators", color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            if (data.topCreators.isEmpty()) {
                Text("Abhi data nahi. Creators ki videos download karein.", color = Neon.Muted, fontSize = 12.sp)
            }
            val max = (data.topCreators.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
            data.topCreators.forEachIndexed { i, (name, n, bytes) ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 5.dp)) {
                    Text(listOf("🥇", "🥈", "🥉", "4", "5")[i], fontSize = 14.sp, modifier = Modifier.width(26.dp))
                    Avatar(name, 28)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Row {
                            Text(name, color = Neon.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Text("$n  •  ${humanSize(bytes)}", color = Neon.Muted, fontSize = 11.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        NeonProgressBar(n.toFloat() / max, 5)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun BarChart(values: List<Int>, labels: List<String>) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(values) { anim.snapTo(0f); anim.animateTo(1f, tween(700)) }
    val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
    val c1 = Neon.Violet; val c2 = Neon.Pink; val track = Neon.Bg1
    Row(Modifier.fillMaxWidth().height(130.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        values.forEachIndexed { i, v ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (v > 0) "$v" else "", color = Neon.Text, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Canvas(Modifier.weight(1f).width(18.dp)) {
                    val r = CornerRadius(8.dp.toPx())
                    drawRoundRect(track, cornerRadius = r)
                    val h = size.height * (v.toFloat() / max) * anim.value
                    if (h > 0f) drawRoundRect(
                        brush = Brush.verticalGradient(listOf(c2, c1)),
                        topLeft = Offset(0f, size.height - h),
                        size = Size(size.width, h),
                        cornerRadius = r
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(labels.getOrElse(i) { "" }, color = if (i == 6) Neon.Text else Neon.Muted, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun ProgressRing(fraction: Float, modifier: Modifier = Modifier) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(fraction) { anim.animateTo(fraction, tween(900)) }
    val c1 = Neon.Violet; val c2 = Neon.Purple; val c3 = Neon.Pink; val track = Neon.Bg1
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 10.dp.toPx()
            drawArc(track, 0f, 360f, false, style = Stroke(w))
            drawArc(
                Brush.sweepGradient(listOf(c1, c2, c3, c1)),
                -90f, 360f * anim.value, false, style = Stroke(w, cap = StrokeCap.Round)
            )
        }
        Text(
            "${(anim.value * 100).toInt()}%",
            style = TextStyle(brush = Neon.Gradient, fontSize = 20.sp, fontWeight = FontWeight.Black)
        )
    }
}
