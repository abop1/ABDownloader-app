package com.mydownloader.app

import android.content.Context
import java.io.File

/**
 * Video ko barabar time ke hisson (parts) mein todta hai, phir asal video delete.
 * App ke andar wala FFmpeg use hota hai (re-encode nahi, is liye bohat fast).
 */
object Splitter {

    /** Wapas: kitne parts bane (0 = split nahi hui, asal file salamat hai) */
    fun split(ctx: Context, input: File, seconds: Int): Int {
        if (!input.exists() || seconds <= 0) return 0
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so")
        val pkgs = File(ctx.noBackupFilesDir, "youtubedl-android/packages")
        val ld = "${pkgs.absolutePath}/ffmpeg/usr/lib:${pkgs.absolutePath}/python/usr/lib"

        val dir = input.parentFile ?: return 0
        val stem = input.nameWithoutExtension
        val ext = input.extension.ifBlank { "mp4" }
        val prefix = "$stem - Part "
        // "%" title mein ho to ffmpeg pattern kharab na ho
        val pattern = File(dir, prefix.replace("%", "%%") + "%03d.$ext").absolutePath

        val cmd = listOf(
            bin.absolutePath, "-hide_banner", "-y",
            "-i", input.absolutePath,
            "-map", "0:v?", "-map", "0:a?",
            "-c", "copy",
            "-f", "segment",
            "-segment_time", seconds.toString(),
            "-reset_timestamps", "1",
            "-segment_start_number", "1",
            pattern
        )
        return try {
            val pb = ProcessBuilder(cmd).redirectErrorStream(true)
            pb.environment()["LD_LIBRARY_PATH"] = ld
            val p = pb.start()
            p.inputStream.bufferedReader().use { r -> while (r.readLine() != null) { } }
            val code = p.waitFor()
            val parts = dir.listFiles()?.count { it.name.startsWith(prefix) && it.length() > 0 } ?: 0
            if (code == 0 && parts > 0) {
                deleteOriginal(input, prefix)
                parts
            } else {
                // Adhoore parts hata dein, asal video salamat rahe
                dir.listFiles()?.filter { it.name.startsWith(prefix) }?.forEach { it.delete() }
                0
            }
        } catch (e: Exception) {
            0
        }
    }

    /** Asal video aur uski bachi hui temp files delete — sirf parts rahenge */
    private fun deleteOriginal(input: File, prefix: String) {
        repeat(3) {
            if (input.exists() && !input.delete()) Thread.sleep(500)
        }
        val stem = input.nameWithoutExtension
        input.parentFile?.listFiles()?.forEach { f ->
            val leftover = f.name.startsWith(stem) && !f.name.startsWith(prefix) &&
                (f.name.endsWith(".part") || f.name.endsWith(".ytdl") || f.name.contains(".temp.") ||
                    Regex("\\.f\\d+\\.").containsMatchIn(f.name) || f.name == input.name)
            if (leftover) f.delete()
        }
    }

    fun label(sec: Int): String = when {
        sec <= 0 -> "Off"
        sec % 60 == 0 -> "${sec / 60} min"
        sec > 60 -> "${sec / 60}m ${sec % 60}s"
        else -> "${sec}s"
    }
}
