package com.mydownloader.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

// ================= Pehli dafa ka tour + "Kya naya hai" =================
object Intro {
    private fun p(ctx: Context) = ctx.getSharedPreferences("intro", Context.MODE_PRIVATE)
    fun onboarded(ctx: Context) = p(ctx).getBoolean("done", false)
    fun setOnboarded(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("done", v).apply()
    fun lastSeen(ctx: Context) = p(ctx).getLong("seen", 0L)
    fun markSeen(ctx: Context) = p(ctx).edit().putLong("seen", Updater.currentVersion(ctx)).apply()
    /** Update ke baad pehli dafa? */
    fun shouldShowWhatsNew(ctx: Context) = onboarded(ctx) && lastSeen(ctx) in 1 until Updater.currentVersion(ctx)
}

/** Har update par is list mein sabse upar nayi cheezein likhein */
val whatsNewItems = listOf(
    Icons.Rounded.WaterDrop to "Apna watermark: Settings → Watermark",
    Icons.Rounded.Bolt to "Quick share: TikTok mein Share → AB Download, chhota popup",
    Icons.Rounded.DataUsage to "Data counter: Stats mein aaj aur is mahine ka internet",
    Icons.Rounded.AutoAwesome to "Naya professional design, asal icons aur narm animations",
    Icons.Rounded.SmartDisplay to "Reels jaisa player: video tap karein, upar neeche swipe",
    Icons.Rounded.Checklist to "Gallery mein lamba daba kar kai videos ek saath chunein",
    Icons.Rounded.NotificationsActive to "Download ke baad notification mein thumbnail aur Upload button",
    Icons.Rounded.Palette to "5 VIP themes aur Stats dashboard",
    Icons.Rounded.Fingerprint to "Fingerprint app lock aur ✅ Posted tick"
)

private data class TourPage(val icon: ImageVector, val title: String, val text: String)

@Composable
fun WelcomeTour(onDone: () -> Unit) {
    val pages = listOf(
        TourPage(Icons.Rounded.CloudDownload, "Har jagah se download",
            "YouTube, TikTok, Instagram, Facebook, X aur 1000+ sites. Link paste karein, HD video foran."),
        TourPage(Icons.Rounded.Groups, "Creators khud chalte hain",
            "Apne pasandida creators add karein. Ek START, ya roz automatic. Nayi videos khud aayengi, purani khud hatengi."),
        TourPage(Icons.Rounded.RocketLaunch, "Ek tap mein upload",
            "Reels size, title copy, ✅ posted aur agli video ki queue. Posting ab bachon ka khel.")
    )
    val pager = rememberPagerState { pages.size }
    val scope = rememberCoroutineScope()
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.radialGradient(listOf(Neon.Violet.copy(alpha = 0.3f), Neon.Bg2, Neon.Bg1), radius = 1400f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
            Row {
                Spacer(Modifier.weight(1f))
                Text("Skip", color = Neon.Muted, fontSize = 14.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onDone).padding(10.dp))
            }
            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { i ->
                val pg = pages[i]
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        Modifier.size(150.dp).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Neon.Violet, Neon.Purple, Neon.Pink))),
                        contentAlignment = Alignment.Center
                    ) { Icon(pg.icon, null, tint = Color.White, modifier = Modifier.size(76.dp)) }
                    Spacer(Modifier.height(36.dp))
                    Text(pg.title, textAlign = TextAlign.Center,
                        style = TextStyle(brush = Neon.Gradient, fontSize = 28.sp, fontWeight = FontWeight.Black))
                    Spacer(Modifier.height(12.dp))
                    Text(pg.text, color = Neon.Muted, fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 22.sp)
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalArrangement = Arrangement.Center) {
                repeat(pages.size) { i ->
                    val w by animateDpAsState(if (pager.currentPage == i) 26.dp else 8.dp, label = "dot")
                    Box(
                        Modifier.padding(horizontal = 4.dp).height(8.dp).width(w).clip(RoundedCornerShape(50))
                            .background(if (pager.currentPage == i) Neon.Gradient else Brush.linearGradient(listOf(Neon.Card, Neon.Card)))
                    )
                }
            }
            val last = pager.currentPage == pages.size - 1
            GlowButton(if (last) "SHURU KAREIN" else "AAGE", icon = if (last) Icons.Rounded.RocketLaunch else Icons.Rounded.ArrowForward) {
                if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
            }
        }
    }
}

@Composable
fun WhatsNewDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Neon.Card,
        icon = { Icon(Icons.Rounded.Celebration, null, tint = Neon.Gold, modifier = Modifier.size(36.dp)) },
        title = {
            Text("Kya naya hai  •  v${Updater.currentVersion(context)}", color = Neon.Text, fontWeight = FontWeight.Black)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                whatsNewItems.forEach { (ic, t) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(Neon.Violet.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) { Icon(ic, null, tint = Neon.Purple, modifier = Modifier.size(18.dp)) }
                        Spacer(Modifier.width(10.dp))
                        Text(t, color = Neon.Text, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Zabardast!", color = Neon.Purple, fontWeight = FontWeight.Bold) } }
    )
}

// ================= About =================
private val faq = listOf(
    "Video download nahi ho rahi?" to "Settings → Download engine update dabayein. TikTok/Instagram ho to Settings → Login karein.",
    "TikTok bar bar rokta hai?" to "Settings → 'Ek saath' 1 ya 2 rakhein aur TikTok mein login karein.",
    "Videos kahan save hoti hain?" to "Download/ABDownloader mein, har creator ka apna folder.",
    "Reinstall ke baad creators wapas kaise?" to "Settings → Backup → Wapas laayein → Download/ABDownloader/backup/AB_backup.json chunein.",
    "Caption mein title kaise aaye?" to "🚀 Upload dabate hi title copy ho jata hai. Instagram mein caption par lamba daba kar Paste."
)

@Composable
fun AboutScreen(onClose: () -> Unit, onTour: () -> Unit, onWhatsNew: () -> Unit) {
    val context = LocalContext.current
    var open by remember { mutableIntStateOf(-1) }
    androidx.activity.compose.BackHandler { onClose() }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Neon.Bg1, Neon.Bg2)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(Modifier.fillMaxWidth()) {
                IconBtn(Icons.Rounded.ArrowBack, filled = false) { onClose() }
            }
            Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(110.dp))
            Text(stringResource(R.string.app_name),
                style = TextStyle(brush = Neon.Gradient, fontSize = 30.sp, fontWeight = FontWeight.Black))
            Text("👑 VIP EDITION  •  v${Updater.currentVersion(context)}", color = Neon.Gold, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("Made with 💜 by ${stringResource(R.string.owner_name)}", color = Neon.Muted, fontSize = 13.sp)

            NeonCard {
                SettingRow(Icons.Rounded.Explore, "Tour dobara dekhein", "App ki khoobiyan 3 screens mein", onClick = onTour) { Chevron() }
                SettingRow(Icons.Rounded.NewReleases, "Kya naya hai", "Is version ki nayi cheezein", onClick = onWhatsNew) { Chevron() }

            }

            SectionLabel("Madad (FAQ)")
            NeonCard {
                faq.forEachIndexed { i, (q, a) ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .clickable { open = if (open == i) -1 else i }.padding(vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.HelpOutline, null, tint = Neon.Purple, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(q, color = Neon.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Icon(if (open == i) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null, tint = Neon.Muted)
                        }
                        if (open == i) {
                            Spacer(Modifier.height(6.dp))
                            Text(a, color = Neon.Muted, fontSize = 13.sp, modifier = Modifier.padding(start = 26.dp))
                        }
                    }
                }
            }
            Text("© ${stringResource(R.string.owner_name)}  •  Sirf apne istemal ke liye. Creators ki izzat karein aur credit dein.",
                color = Neon.Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
}
