package com.mydownloader.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Foreground service: jab tak download chal raha ho, app ko zinda rakhti hai
 * (app band ho ya screen off) aur notification mein progress dikhati hai.
 */
class DownloadService : Service() {

    companion object {
        private const val CHANNEL = "downloads"
        private const val CHANNEL_DONE = "downloads_done"
        private const val ID = 77
        private const val ID_DONE = 78
        private const val ACTION_STOP = "com.ab.downloader.STOP"

        @Volatile private var instance: DownloadService? = null
        private var lastUpdate = 0L

        fun start(ctx: Context) {
            if (instance != null) return
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun update(ctx: Context, text: String, percent: Int) {
            val now = System.currentTimeMillis()
            if (now - lastUpdate < 800) return
            lastUpdate = now
            instance?.post(text, percent)
        }

        /** Sab kaam khatam ho to service band, aur "mukammal" notification */
        fun finished(ctx: Context, message: String, file: java.io.File? = null) {
            if (Jobs.isBusy()) return
            ctx.stopService(Intent(ctx, DownloadService::class.java))
            try {
                createChannels(ctx)
                val b = NotificationCompat.Builder(ctx, CHANNEL_DONE)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle(ctx.getString(R.string.app_name))
                    .setContentText(message)
                    .setContentIntent(openApp(ctx, tab = 2))
                    .setAutoCancel(true)
                // Rich: video ka thumbnail + seedha 🚀 Upload
                if (file != null && file.exists()) {
                    val title = try { Titles.get(ctx, file) } catch (e: Exception) { file.name }
                    b.setContentText(title)
                    b.setSubText(message)
                    Thumbs.get(file)?.let { bmp ->
                        b.setLargeIcon(bmp)
                        b.setStyle(NotificationCompat.BigPictureStyle().bigPicture(bmp).setSummaryText(title))
                    }
                    val up = PendingIntent.getActivity(
                        ctx, 3,
                        Intent(ctx, MainActivity::class.java)
                            .putExtra("upload_path", file.absolutePath)
                            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    b.addAction(0, "🚀 Upload", up)
                    b.addAction(0, "🎬 Gallery", openApp(ctx, tab = 2))
                }
                NotificationManagerCompat.from(ctx).notify(ID_DONE, b.build())
            } catch (e: SecurityException) {
                // Notification ki ijazat nahi di gayi — koi baat nahi
            }
        }

        private fun openApp(ctx: Context, tab: Int = -1): PendingIntent = PendingIntent.getActivity(
            ctx, 10 + tab,
            Intent(ctx, MainActivity::class.java)
                .putExtra("open_tab", tab)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        private fun createChannels(ctx: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Downloads chal rahe hain", NotificationManager.IMPORTANCE_LOW)
                )
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_DONE, "Download mukammal", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannels(this)
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, ID, build("Download shuru ho raha hai...", -1), type)
        // Screen off hone par bhi CPU chalta rahe
        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ABDownloader:download")
            .apply { acquire(6 * 60 * 60 * 1000L) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Jobs.stopAll()
        }
        return START_NOT_STICKY
    }

    private fun build(text: String, percent: Int) =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("${getString(R.string.app_name)} — downloading")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(this))
            .addAction(
                0, "■ Stop",
                PendingIntent.getService(
                    this, 1,
                    Intent(this, DownloadService::class.java).setAction(ACTION_STOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            .apply {
                if (percent in 0..100) setProgress(100, percent, false) else setProgress(0, 0, true)
            }
            .build()

    fun post(text: String, percent: Int) {
        try {
            NotificationManagerCompat.from(this).notify(ID, build(text, percent))
        } catch (e: SecurityException) { }
    }

    override fun onDestroy() {
        instance = null
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
