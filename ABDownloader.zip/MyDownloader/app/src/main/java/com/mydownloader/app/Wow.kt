package com.mydownloader.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.isActive
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// ================= 🌌 Zinda neon background =================
@Composable
fun AuroraBackground(modifier: Modifier = Modifier.fillMaxSize()) {
    val t = rememberInfiniteTransition(label = "aurora")
    val a by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(22000, easing = LinearEasing)), label = "a")
    val c1 = Neon.Violet; val c2 = Neon.Pink; val c3 = Neon.Purple
    val bg1 = Neon.Bg1; val bg2 = Neon.Bg2
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(listOf(bg1, bg2)))
        val w = size.width; val h = size.height
        fun blob(color: Color, cx: Float, cy: Float, r: Float, alpha: Float) =
            drawCircle(Brush.radialGradient(listOf(color.copy(alpha = alpha), Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))
        blob(c1, w * (0.25f + 0.15f * cos(a)), h * (0.18f + 0.08f * sin(a * 1.3f)), w * 0.75f, 0.30f)
        blob(c2, w * (0.85f + 0.12f * sin(a * 0.8f)), h * (0.55f + 0.10f * cos(a)), w * 0.65f, 0.20f)
        blob(c3, w * (0.35f + 0.20f * sin(a * 1.1f)), h * (0.95f + 0.05f * cos(a * 0.7f)), w * 0.7f, 0.18f)
    }
}

// ================= 🎉 Confetti =================
object Celebrate {
    var count by mutableIntStateOf(0)
    fun now() { count++ }
}

private class Bit(var x: Float, var y: Float, val vx: Float, var vy: Float, val color: Color, val size: Float, var rot: Float, val vr: Float)

@Composable
fun ConfettiOverlay() {
    val trigger = Celebrate.count
    if (trigger == 0) return
    var bits by remember(trigger) { mutableStateOf<List<Bit>>(emptyList()) }
    var frame by remember(trigger) { mutableIntStateOf(0) }
    var alive by remember(trigger) { mutableStateOf(true) }
    val colors = listOf(Neon.Violet, Neon.Purple, Neon.Pink, Neon.Gold, Neon.Green, Color.White)
    LaunchedEffect(trigger) {
        bits = List(140) {
            val ang = Random.nextFloat() * 3.1416f + 3.1416f
            val sp = 14f + Random.nextFloat() * 22f
            Bit(0.5f, 0.35f, cos(ang) * sp * 0.04f, sin(ang) * sp * 0.04f, colors.random(),
                8f + Random.nextFloat() * 12f, Random.nextFloat() * 360f, -12f + Random.nextFloat() * 24f)
        }
        val start = withFrameNanos { it }
        while (isActive) {
            val now = withFrameNanos { it }
            bits.forEach { b -> b.x += b.vx * 0.016f * 6; b.y += b.vy * 0.016f * 6; b.vy += 0.012f; b.rot += b.vr }
            frame++
            if (now - start > 2_600_000_000L) break
        }
        alive = false
    }
    if (!alive) return
    Canvas(Modifier.fillMaxSize()) {
        frame.let { }
        bits.forEach { b ->
            val px = b.x * size.width; val py = b.y * size.height
            rotate(b.rot, Offset(px, py)) {
                drawRect(b.color, Offset(px - b.size / 2, py - b.size / 4), Size(b.size, b.size / 2))
            }
        }
    }
}

// ================= 🔗 Platform pehchaan =================
data class Platform(val name: String, val color: Color)

fun detectPlatform(url: String): Platform? {
    val u = url.lowercase()
    return when {
        "tiktok.com" in u -> Platform("TikTok", Color(0xFFFF0050))
        "youtube.com" in u || "youtu.be" in u -> Platform("YouTube", Color(0xFFFF0000))
        "instagram.com" in u -> Platform("Instagram", Color(0xFFE1306C))
        "facebook.com" in u || "fb.watch" in u -> Platform("Facebook", Color(0xFF1877F2))
        "x.com" in u || "twitter.com" in u -> Platform("X", Color(0xFFE7E9EA))
        "reddit.com" in u -> Platform("Reddit", Color(0xFFFF4500))
        "pinterest." in u || "pin.it" in u -> Platform("Pinterest", Color(0xFFE60023))
        "snapchat.com" in u -> Platform("Snapchat", Color(0xFFFFFC00))
        "vimeo.com" in u -> Platform("Vimeo", Color(0xFF1AB7EA))
        "dailymotion" in u -> Platform("Dailymotion", Color(0xFF0066DC))
        u.startsWith("http") -> Platform("Link", Neon.Purple)
        else -> null
    }
}

fun findLink(text: String?): String? = text?.let { Regex("https?://\\S+").find(it)?.value }

// ================= 👀 Download se pehle video ki jhalak =================
data class PreviewInfo(val title: String, val uploader: String, val duration: Int, val thumb: Bitmap?)

object LinkPreview {
    private val cache = HashMap<String, PreviewInfo>()

    fun fetch(ctx: android.content.Context, url: String): PreviewInfo? {
        cache[url]?.let { return it }
        val req = YoutubeDLRequest(url).apply {
            addOption("--dump-single-json")
            addOption("--skip-download")
            addOption("--no-playlist")
            addOption("--socket-timeout", "15")
            if (Engine.hasLogin(ctx)) addOption("--cookies", Engine.cookiesFile(ctx).absolutePath)
        }
        val resp = YoutubeDL.getInstance().execute(req, "preview_${System.currentTimeMillis()}", false, null)
        val o = JSONObject(resp.out)
        val desc = o.optString("description")
        val title = o.optString("title").let { t ->
            if ((t.isBlank() || t.startsWith("Video by")) && desc.isNotBlank()) desc else t
        }
        val thumbUrl = o.optString("thumbnail")
        val bmp = if (thumbUrl.startsWith("http")) try {
            val c = URL(thumbUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            c.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) { null } else null
        val info = PreviewInfo(title, o.optString("uploader").ifBlank { o.optString("channel") }, o.optInt("duration", 0), bmp)
        cache[url] = info
        return info
    }
}

fun timeGreeting(): String = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
    in 5..11 -> "Subah bakhair"
    in 12..16 -> "Dopahar bakhair"
    in 17..20 -> "Shaam bakhair"
    else -> "Raat bakhair"
}

fun fmtDuration(sec: Int): String = if (sec >= 3600) String.format("%d:%02d:%02d", sec / 3600, sec % 3600 / 60, sec % 60)
    else String.format("%d:%02d", sec / 60, sec % 60)
