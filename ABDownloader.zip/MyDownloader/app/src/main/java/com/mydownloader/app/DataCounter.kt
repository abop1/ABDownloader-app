package com.mydownloader.app

import android.content.Context
import android.net.TrafficStats
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 📶 App ne kitna internet istemal kiya (aaj / is mahine) */
object DataCounter {
    private fun p(ctx: Context) = ctx.getSharedPreferences("data_counter", Context.MODE_PRIVATE)
    private fun dayKey() = "d" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    private fun monthKey() = "m" + SimpleDateFormat("yyyyMM", Locale.US).format(Date())
    private var lastTick = 0L

    /** Abhi tak ka hisaab jodo (bar bar bulaya ja sakta hai) */
    @Synchronized
    fun tick(ctx: Context, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - lastTick < 5000) return
        lastTick = now
        val rx = TrafficStats.getUidRxBytes(Process.myUid())
        if (rx < 0) return // phone ye ginti nahi deta
        val s = p(ctx)
        val last = s.getLong("last_rx", -1L)
        val delta = when {
            last < 0 -> 0L
            rx >= last -> rx - last
            else -> rx // phone restart hua
        }
        val d = dayKey(); val m = monthKey()
        s.edit()
            .putLong("last_rx", rx)
            .putLong(d, s.getLong(d, 0L) + delta)
            .putLong(m, s.getLong(m, 0L) + delta)
            .putLong("total", s.getLong("total", 0L) + delta)
            .apply()
    }

    fun today(ctx: Context) = p(ctx).getLong(dayKey(), 0L)
    fun month(ctx: Context) = p(ctx).getLong(monthKey(), 0L)
    fun total(ctx: Context) = p(ctx).getLong("total", 0L)

    /** Pichle 7 din (purane se naye) */
    fun week(ctx: Context): List<Long> {
        val f = SimpleDateFormat("yyyyMMdd", Locale.US)
        return (6 downTo 0).map { off ->
            val c = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -off) }
            p(ctx).getLong("d" + f.format(c.time), 0L)
        }
    }

    fun reset(ctx: Context) {
        val rx = TrafficStats.getUidRxBytes(Process.myUid())
        p(ctx).edit().clear().putLong("last_rx", rx).apply()
    }
}
