package com.mydownloader.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * ⚡ Quick share: TikTok/Instagram mein Share → AB Downloader.
 * Poori app nahi khulti, sirf neeche chhota popup. Download peeche chalta rehta hai.
 */
class ShareActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Jobs.init(applicationContext)
        Themes.load(this)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val link = Regex("https?://\\S+").find(text)?.value ?: ""

        var started = false
        if (savedInstanceState == null && link.isNotBlank() && !Jobs.singleBusy) {
            val folder = Engine.publicFolder("Download", getString(R.string.app_name).replace(" ", ""))
            Jobs.startSingle(this, link, "Best", folder)
            started = true
        }
        val busyBefore = savedInstanceState == null && !started && Jobs.singleBusy

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Neon.Purple, surface = Neon.Card)) {
                QuickSharePopup(
                    link = link,
                    busyBefore = busyBefore,
                    started = started,
                    onHide = { finish() },
                    onOpenApp = {
                        startActivity(Intent(this, MainActivity::class.java)
                            .putExtra("open_tab", 2)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                        finish()
                    },
                    onUpload = { f -> uploadFile(this, f); finish() }
                )
            }
        }
    }
}

@Composable
fun QuickSharePopup(
    link: String,
    busyBefore: Boolean,
    started: Boolean,
    onHide: () -> Unit,
    onOpenApp: () -> Unit,
    onUpload: (java.io.File) -> Unit
) {
    val busy = Jobs.singleBusy
    val progress by animateFloatAsState(Jobs.singleProgress, label = "p")
    val done = started && !busy && Jobs.singleStatus.startsWith("Mukammal")
    val failed = !busy && !done && link.isNotBlank() && !busyBefore

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onHide() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(12.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.verticalGradient(listOf(Neon.Card2, Neon.Card)))
                .border(1.dp, Neon.Violet.copy(alpha = 0.7f), RoundedCornerShape(26.dp))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(40.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("AB Downloader", style = TextStyle(brush = Neon.Gradient, fontSize = 18.sp, fontWeight = FontWeight.Black))
                    Text(
                        when {
                            link.isBlank() -> "Is share mein video link nahi mila"
                            busyBefore -> "Ek download pehle se chal rahi hai"
                            done -> "✅ Download mukammal!"
                            busy -> "⚡ Download ho rahi hai..."
                            else -> "Download nahi hui"
                        },
                        color = if (done) Neon.Green else Neon.Muted, fontSize = 12.sp
                    )
                }
                IconBtn(Icons.Rounded.Close, filled = false, size = 34) { onHide() }
            }

            if (link.isNotBlank()) {
                Text(link, color = Neon.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }

            if (busy || done) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${(progress * 100).toInt()}%",
                        style = TextStyle(brush = Neon.Gradient, fontSize = 26.sp, fontWeight = FontWeight.Black),
                        modifier = Modifier.weight(1f)
                    )
                    if (busy) Text("⚡ ${Jobs.singleSpeed}   ⏱ ${Jobs.singleEta}", color = Neon.Muted, fontSize = 12.sp)
                }
                NeonProgressBar(progress, 8)
            }
            if (failed) {
                Text(Jobs.singleStatus, color = Neon.Pink, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (done && Jobs.lastSingleFile != null) {
                    GlowButton("UPLOAD", icon = Icons.Rounded.RocketLaunch, modifier = Modifier.weight(1f)) {
                        Jobs.lastSingleFile?.let(onUpload)
                    }
                } else {
                    NeonOutlineButton(if (busy) "Peeche chalne do" else "Band karein", Modifier.weight(1f)) { onHide() }
                }
                NeonOutlineButton("App kholein", Modifier.weight(1f)) { onOpenApp() }
            }
            if (busy) {
                Text(
                    "Popup band kar dein, download notification mein chalta rahega.",
                    color = Neon.Muted, fontSize = 11.sp
                )
            }
        }
    }
}
