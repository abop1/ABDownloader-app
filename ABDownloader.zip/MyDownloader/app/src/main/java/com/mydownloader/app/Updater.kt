package com.mydownloader.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(val version: Int, val apkUrl: String, val pageUrl: String, val notes: String)

/** GitHub ke public "app" repo mein latest release dekh kar batata hai ke naya version hai ya nahi */
object Updater {

    fun currentVersion(ctx: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (e: Exception) { 0L }

    /** null = koi update nahi (ya check nahi ho saka) */
    fun check(ctx: Context): UpdateInfo? {
        val repo = ctx.getString(R.string.update_repo)
        val conn = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        try {
            if (conn.responseCode != 200) return null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val version = json.optString("tag_name").filter { it.isDigit() }.toIntOrNull() ?: return null
            if (version <= currentVersion(ctx)) return null
            var apk = ""
            val assets = json.optJSONArray("assets")
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) { apk = a.optString("browser_download_url"); break }
                }
            }
            val page = json.optString("html_url")
            return UpdateInfo(version, apk.ifBlank { page }, page, json.optString("body").take(300))
        } finally {
            conn.disconnect()
        }
    }

    fun openDownload(ctx: Context, info: UpdateInfo) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(info.apkUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }
}
