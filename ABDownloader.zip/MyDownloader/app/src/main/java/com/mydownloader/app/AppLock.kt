package com.mydownloader.app

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.io.File

/** Fingerprint / face / phone ke PIN se app lock */
object AppLock {
    private const val AUTH =
        BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("lock", Context.MODE_PRIVATE)

    fun enabled(ctx: Context) = prefs(ctx).getBoolean("on", false)

    fun setEnabled(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("on", on).apply()

    /** Phone mein fingerprint ya screen lock set hai? */
    fun available(ctx: Context) =
        BiometricManager.from(ctx).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS

    fun prompt(act: FragmentActivity, title: String, onOk: () -> Unit, onFail: (String) -> Unit = {}) {
        try {
            val p = BiometricPrompt(act, ContextCompat.getMainExecutor(act),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onOk()
                    override fun onAuthenticationError(code: Int, msg: CharSequence) = onFail(msg.toString())
                })
            p.authenticate(
                BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title)
                    .setSubtitle("Fingerprint ya phone ka PIN")
                    .setAllowedAuthenticators(AUTH)
                    .build()
            )
        } catch (e: Exception) {
            onFail(e.message ?: "Lock nahi khula")
        }
    }
}

/** ✅ Posted: jo videos upload ho chuki hain */
object Posted {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("posted", Context.MODE_PRIVATE)

    fun all(ctx: Context): Set<String> = prefs(ctx).getStringSet("paths", emptySet())?.toSet() ?: emptySet()

    /** Wapas: naya haal (true = posted) */
    fun toggle(ctx: Context, f: File): Boolean {
        val set = all(ctx).toMutableSet()
        val now = if (f.absolutePath in set) { set.remove(f.absolutePath); false } else { set.add(f.absolutePath); true }
        prefs(ctx).edit().putStringSet("paths", set).apply()
        return now
    }

    fun forget(ctx: Context, f: File) {
        val set = all(ctx).toMutableSet()
        if (set.remove(f.absolutePath)) prefs(ctx).edit().putStringSet("paths", set).apply()
    }
}
