package com.mydownloader.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Saare downloads yahan chalte hain (screen se alag), taake app band ya phone lock
 * hone par bhi kaam chalta rahe. DownloadService app ko zinda rakhti hai.
 */
object Jobs {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var initialized = false

    // ---------- Creators + settings ----------
    val creators = mutableStateListOf<Creator>()
    val results = mutableStateMapOf<String, String>()
    var perCreator by mutableIntStateOf(3)
    var random by mutableStateOf(true)
    var quality by mutableStateOf("720p")

    // ---------- Creators run state ----------
    var running by mutableStateOf(false)
    var cancelled by mutableStateOf(false)
    var currentPid by mutableStateOf<String?>(null)
    var currentId by mutableStateOf<String?>(null)
    var progress by mutableFloatStateOf(0f)
    var status by mutableStateOf("Start dabayein, nayi videos khud aa jayengi")
    var totalNew by mutableIntStateOf(0)
    var historyCount by mutableIntStateOf(0)

    // ---------- Single download state ----------
    var singleBusy by mutableStateOf(false)
    var singleProgress by mutableFloatStateOf(0f)
    var singleStatus by mutableStateOf("Link paste karein aur Download dabayein")
    var singleSpeed by mutableStateOf("--")
    var singleEta by mutableStateOf("--")
    private var singlePid: String? = null

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        creators.addAll(CreatorStore.load(ctx))
        historyCount = countLines(archiveFile(ctx))
        val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        perCreator = p.getInt("perCreator", 3)
        random = p.getBoolean("random", true)
        quality = p.getString("quality", "720p") ?: "720p"
    }

    fun saveCreators(ctx: Context) = CreatorStore.save(ctx, creators)

    fun saveSettings(ctx: Context) {
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
            .putInt("perCreator", perCreator).putBoolean("random", random)
            .putString("quality", quality).apply()
    }

    fun isBusy() = running || singleBusy

    private fun notify(ctx: Context) {
        val text = when {
            running -> {
                val name = creators.find { it.id == currentId }?.name ?: "Creators"
                "$name  •  ${(progress * 100).toInt()}%"
            }
            singleBusy -> "Video  •  ${(singleProgress * 100).toInt()}%  •  $singleSpeed"
            else -> ""
        }
        val pct = if (running) (progress * 100).toInt() else (singleProgress * 100).toInt()
        DownloadService.update(ctx, text, pct)
    }

    // ================= Single video =================
    fun startSingle(appCtx: Context, url: String, quality: String, folder: File) {
        val ctx = appCtx.applicationContext
        if (singleBusy) return
        singleBusy = true
        singleProgress = 0f; singleSpeed = "--"; singleEta = "--"
        singleStatus = "Download shuru ho raha hai..."
        DownloadService.start(ctx)
        scope.launch {
            val pid = "single_${System.currentTimeMillis()}"
            singlePid = pid
            val result = withContext(Dispatchers.IO) {
                downloadSingle(ctx, url, quality, folder) { p, line ->
                    if (p >= 0) singleProgress = p / 100f
                    Regex(" at\\s+(\\S+)").find(line)?.let { singleSpeed = it.groupValues[1] }
                    Regex("ETA\\s+(\\S+)").find(line)?.let { singleEta = it.groupValues[1] }
                    if (line.isNotBlank()) singleStatus = line
                    notify(ctx)
                }
            }
            if (result.startsWith("Mukammal")) singleProgress = 1f
            singleStatus = result
            singleBusy = false
            singlePid = null
            DownloadService.finished(ctx, if (result.startsWith("Mukammal")) "✓ Video download ho gayi" else "Video download nahi hui")
        }
    }

    // ================= Creators queue =================
    fun stopCurrentIf(id: String) {
        if (currentId == id) currentPid?.let { YoutubeDL.getInstance().destroyProcessById(it) }
    }

    fun stopAll() {
        if (running) {
            cancelled = true
            status = "Roka ja raha hai..."
            currentPid?.let { YoutubeDL.getInstance().destroyProcessById(it) }
        }
    }

    /** manual = true: sirf chune hue creator, chahe wo Stop par ho */
    fun runQueue(appCtx: Context, ids: List<String>, manual: Boolean) {
        val ctx = appCtx.applicationContext
        if (running) return
        running = true
        cancelled = false
        totalNew = 0
        saveSettings(ctx)
        if (manual) ids.forEach { results.remove(it) } else results.clear()
        DownloadService.start(ctx)
        scope.launch {
            for ((i, id) in ids.withIndex()) {
                if (cancelled) break
                val c = creators.find { it.id == id } ?: continue
                if (!manual && !c.enabled) { results[id] = "⏸ Stop hai, skip"; continue }
                Engine.publicFolder(c.base, c.folder).mkdirs()
                currentId = id
                progress = 0f
                results[id] = "Downloading..."
                status = if (manual) "${c.name} ki videos dhoondi ja rahi hain..."
                else "(${i + 1}/${ids.size}) ${c.name} ki videos dhoondi ja rahi hain..."
                notify(ctx)
                val pid = "creator_${System.currentTimeMillis()}"
                currentPid = pid
                val per = perCreator; val rnd = random; val q = quality
                val res = withContext(Dispatchers.IO) {
                    try {
                        val r = downloadFromCreator(ctx, c, per, rnd, q, pid) { p, line ->
                            if (p >= 0) progress = p / 100f
                            if (line.isNotBlank()) status = line
                            notify(ctx)
                        }
                        totalNew += r.videos
                        when {
                            r.videos == 0 -> "Koi nayi video nahi"
                            r.parts > 0 -> "✓ ${r.videos} nayi videos → ✂ ${r.parts} parts"
                            else -> "✓ ${r.videos} nayi videos"
                        }
                    } catch (e: YoutubeDL.CanceledException) {
                        if (cancelled) "Roka gaya" else "⏸ Stop kar diya"
                    } catch (e: Exception) {
                        "✕ Nahi hua: ${e.message?.take(80)}"
                    }
                }
                results[id] = res
            }
            currentPid = null
            currentId = null
            running = false
            historyCount = countLines(archiveFile(ctx))
            status = if (cancelled) "Rok diya gaya. $totalNew nayi videos aayin."
            else "Mukammal! $totalNew nayi videos download huin"
            DownloadService.finished(ctx, "✓ Creators: $totalNew nayi videos")
        }
    }
}
