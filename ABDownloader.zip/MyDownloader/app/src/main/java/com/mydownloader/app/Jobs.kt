package com.mydownloader.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.io.File

/**
 * Saare downloads yahan chalte hain (screen se alag), taake app band ya phone lock
 * hone par bhi kaam chalta rahe. DownloadService app ko zinda rakhti hai.
 */
/** Folder mein is waqt ke baad aayi sabse nayi video */
fun newestMedia(dir: File, since: Long): File? = try {
    val ext = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp")
    dir.listFiles()?.filter { it.isFile && it.extension.lowercase() in ext && it.lastModified() >= since }
        ?.maxByOrNull { it.lastModified() }
} catch (e: Exception) { null }

object Jobs {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var initialized = false

    // ---------- Creators + settings ----------
    val creators = mutableStateListOf<Creator>()
    val results = mutableStateMapOf<String, String>()
    val errors = mutableStateMapOf<String, String>()   // creator id -> poora asal error (tap karke dekhein)
    var perCreator by mutableIntStateOf(3)
    var random by mutableStateOf(true)
    var quality by mutableStateOf("720p")
    var cleanOld by mutableStateOf(true)   // nayi aane par purani delete
    var parallel by mutableIntStateOf(3)    // ek saath kitne creators
    var wifiOnly by mutableStateOf(false)   // sirf Wi-Fi par
    var autoOn by mutableStateOf(false)     // roz khud download
    var autoHour by mutableIntStateOf(9)
    var autoMinute by mutableIntStateOf(0)

    // ---------- Creators run state ----------
    var running by mutableStateOf(false)
    var cancelled by mutableStateOf(false)
    // Jo creators is waqt chal rahe hain: id -> progress
    val active = mutableStateMapOf<String, Float>()
    private val activePids = ConcurrentHashMap<String, String>()
    var doneCount by mutableIntStateOf(0)
    var totalCount by mutableIntStateOf(0)
    val progress: Float
        get() = if (totalCount == 0) 0f
        else ((doneCount + active.values.sum()) / totalCount).coerceIn(0f, 1f)
    var status by mutableStateOf("Start dabayein, nayi videos khud aa jayengi")
    var totalNew by mutableIntStateOf(0)
    var historyCount by mutableIntStateOf(0)

    // ---------- Single download state ----------
    var singleBusy by mutableStateOf(false)
    var singleProgress by mutableFloatStateOf(0f)
    var singleStatus by mutableStateOf("Link paste karein aur Download dabayein")
    var singleSpeed by mutableStateOf("--")
    var singleEta by mutableStateOf("--")
    private var singlePid: String? = null

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        // Download engine (auto/background ke liye bhi zaroori)
        try {
            YoutubeDL.getInstance().init(ctx)
            com.yausername.ffmpeg.FFmpeg.getInstance().init(ctx)
        } catch (e: Exception) { e.printStackTrace() }
        creators.addAll(CreatorStore.load(ctx))
        historyCount = countLines(archiveFile(ctx))
        Watermark.load(ctx)
        Titles.loadPrefs(ctx)
        DataCounter.tick(ctx, force = true)
        val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        perCreator = p.getInt("perCreator", 3)
        random = p.getBoolean("random", true)
        quality = p.getString("quality", "720p") ?: "720p"
        cleanOld = p.getBoolean("cleanOld", true)
        parallel = p.getInt("parallel", 3)
        wifiOnly = p.getBoolean("wifiOnly", false)
        autoOn = p.getBoolean("autoOn", false)
        autoHour = p.getInt("autoHour", 9)
        autoMinute = p.getInt("autoMinute", 0)
    }

    fun saveCreators(ctx: Context) {
        CreatorStore.save(ctx, creators)
        Backup.autoSave(ctx) // har tabdeeli par backup file bhi taaza
    }

    fun saveSettings(ctx: Context) {
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
            .putInt("perCreator", perCreator).putBoolean("random", random)
            .putString("quality", quality).putBoolean("cleanOld", cleanOld)
            .putInt("parallel", parallel).putBoolean("wifiOnly", wifiOnly)
            .putBoolean("autoOn", autoOn).putInt("autoHour", autoHour).putInt("autoMinute", autoMinute)
            .apply()
        Backup.autoSave(ctx)
    }

    fun isBusy() = running || singleBusy

    fun activeCount() = activePids.size

    var lastSingleFile by mutableStateOf<File?>(null)
    var wmBusy by mutableStateOf(false)

    /** Chuni hui videos par ek ek kar ke watermark */
    fun watermarkBatch(appCtx: Context, files: List<File>, onDone: () -> Unit) {
        val ctx = appCtx.applicationContext
        if (wmBusy || files.isEmpty()) return
        wmBusy = true
        android.widget.Toast.makeText(ctx, "💧 ${files.size} videos par watermark lag raha hai...", android.widget.Toast.LENGTH_SHORT).show()
        scope.launch {
            var ok = 0
            for (f in files) {
                if (withContext(Dispatchers.IO) { Watermark.apply(ctx, f) } != null) ok++
            }
            wmBusy = false
            android.widget.Toast.makeText(ctx, "💧 $ok/${files.size} videos par watermark lag gaya", android.widget.Toast.LENGTH_LONG).show()
            onDone()
        }
    }

    private fun notify(ctx: Context) {
        DataCounter.tick(ctx)
        val text = when {
            running -> "${active.size} creators chal rahe  •  $doneCount/$totalCount mukammal"
            singleBusy -> "Video  •  ${(singleProgress * 100).toInt()}%  •  $singleSpeed"
            else -> ""
        }
        val pct = if (running) (progress * 100).toInt() else (singleProgress * 100).toInt()
        DownloadService.update(ctx, text, pct)
    }

    // ================= Single video =================
    fun startSingle(appCtx: Context, url: String, quality: String, folder: File) {
        val ctx = appCtx.applicationContext
        if (singleBusy) return
        Guards.blockReason(ctx)?.let { singleStatus = it; return }
        singleBusy = true
        singleProgress = 0f; singleSpeed = "--"; singleEta = "--"
        singleStatus = "Download shuru ho raha hai..."
        DownloadService.start(ctx)
        val startedAt = System.currentTimeMillis() - 2000
        scope.launch {
            val pid = "single_${System.currentTimeMillis()}"
            singlePid = pid
            val result = withContext(Dispatchers.IO) {
                downloadSingle(ctx, url, quality, folder) { p, line ->
                    if (p >= 0) singleProgress = p / 100f
                    Regex(" at\\s+(\\S+)").find(line)?.let { singleSpeed = it.groupValues[1] }
                    Regex("ETA\\s+(\\S+)").find(line)?.let { singleEta = it.groupValues[1] }
                    if (line.isNotBlank()) singleStatus = line
                    notify(ctx)
                }
            }
            if (result.startsWith("Mukammal")) singleProgress = 1f
            singleStatus = result
            singleBusy = false
            singlePid = null
            val ok = result.startsWith("Mukammal")
            var newest = if (ok) withContext(Dispatchers.IO) { newestMedia(folder, startedAt) } else null
            if (newest != null && Watermark.on && Watermark.auto) {
                singleStatus = "💧 Watermark lag raha hai..."
                newest = withContext(Dispatchers.IO) { Watermark.apply(ctx, newest!!) { p -> singleProgress = p } } ?: newest
                singleStatus = result
                singleProgress = 1f
            }
            lastSingleFile = newest
            if (ok) Celebrate.now()
            DataCounter.tick(ctx, force = true)
            DownloadService.finished(ctx, if (ok) "✓ Video download ho gayi" else "Video download nahi hui", newest)
        }
    }

    // ================= Creators queue =================
    fun stopCurrentIf(id: String) {
        activePids[id]?.let { YoutubeDL.getInstance().destroyProcessById(it) }
    }

    fun stopAll() {
        if (running) {
            cancelled = true
            status = "Roka ja raha hai..."
            activePids.values.forEach { YoutubeDL.getInstance().destroyProcessById(it) }
        }
    }

    /**
     * Creators ko EK SAATH chalata hai (parallel = kitne ek waqt mein).
     * manual = true: sirf chune hue creator, chahe wo Stop par ho.
     */
    fun runQueue(appCtx: Context, ids: List<String>, manual: Boolean) {
        val ctx = appCtx.applicationContext
        if (running) return
        Guards.blockReason(ctx)?.let { status = it; return }
        running = true
        cancelled = false
        totalNew = 0
        doneCount = 0
        saveSettings(ctx)
        if (manual) ids.forEach { results.remove(it) } else results.clear()
        val todo = ids.filter { id ->
            val c = creators.find { it.id == id }
            if (c != null && !manual && !c.enabled) { results[id] = "⏸ Stop hai, skip"; false } else c != null
        }
        totalCount = todo.size
        status = "${todo.size} creators shuru ho rahe hain (${parallel} ek saath)..."
        DownloadService.start(ctx)
        val runStarted = System.currentTimeMillis() - 2000
        val per = perCreator; val rnd = random; val q = quality; val clean = cleanOld
        val gate = Semaphore(parallel.coerceIn(1, 6))

        scope.launch {
            todo.map { id ->
                launch {
                    gate.withPermit {
                        if (cancelled) return@withPermit
                        val c = creators.find { it.id == id } ?: return@withPermit
                        if (!manual && !c.enabled) { results[id] = "⏸ Stop kar diya"; doneCount++; return@withPermit }
                        if (Guards.freeBytes() < Guards.MIN_FREE_BYTES) {
                            results[id] = "💾 Jagah kam, skip"; doneCount++; return@withPermit
                        }
                        if (wifiOnly && !Guards.onWifi(ctx)) {
                            results[id] = "📶 Wi-Fi nahi, skip"; doneCount++; return@withPermit
                        }
                        Engine.publicFolder(c.base, c.folder).mkdirs()
                        val pid = "creator_${id}_${System.currentTimeMillis()}"
                        activePids[id] = pid
                        active[id] = 0f
                        results[id] = "Downloading..."
                        errors.remove(id)
                        notify(ctx)
                        val outcome: Pair<String, Int> = withContext(Dispatchers.IO) {
                            try {
                                val count = if (c.count > 0) c.count else per
                                val r = downloadFromCreator(ctx, c, count, rnd, q, pid, clean) { p, line ->
                                    if (p >= 0) active[id] = p / 100f
                                    if (line.isNotBlank()) status = "${c.name}: $line"
                                    notify(ctx)
                                }
                                val base = when {
                                    r.videos == 0 -> "Koi nayi video nahi"
                                    r.parts > 0 -> "✓ ${r.videos} nayi  •  ✂ ${r.parts} parts"
                                    else -> "✓ ${r.videos} nayi videos"
                                }
                                (if (r.deleted > 0) "$base  •  🧹 ${r.deleted} purani hatayin" else base) to r.videos
                            } catch (e: YoutubeDL.CanceledException) {
                                (if (cancelled) "Roka gaya" else "⏸ Stop kar diya") to 0
                            } catch (e: Exception) {
                                errors[id] = e.message ?: ""
                                "✕ ${Engine.friendlyError(e.message)}" to 0
                            }
                        }
                        results[id] = outcome.first
                        totalNew += outcome.second
                        activePids.remove(id)
                        active.remove(id)
                        doneCount++
                        notify(ctx)
                    }
                }
            }.joinAll()

            running = false
            historyCount = countLines(archiveFile(ctx))
            status = if (cancelled) "Rok diya gaya. $totalNew nayi videos aayin."
            else "Mukammal! $totalNew nayi videos download huin"
            val newest = if (totalNew > 0) withContext(Dispatchers.IO) {
                creators.mapNotNull { c -> newestMedia(Engine.publicFolder(c.base, c.folder), runStarted) }
                    .maxByOrNull { it.lastModified() }
            } else null
            if (totalNew > 0) Celebrate.now()
            DownloadService.finished(ctx, "✓ Creators: $totalNew nayi videos", newest)
        }
    }
}
