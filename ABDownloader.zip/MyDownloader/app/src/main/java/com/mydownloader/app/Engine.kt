package com.mydownloader.app

import android.content.Context
import android.os.Environment
import android.webkit.CookieManager
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File

/**
 * AB Turbo Engine
 * - Har download par 10 dafa retry
 * - Fail hone par khud engine update karke dobara try
 * - Roz khud update (nightly = sabse taaza fixes)
 * - Login cookies (Instagram, Facebook, TikTok, X) ka support
 */
object Engine {

    fun cookiesFile(ctx: Context) = File(ctx.filesDir, "cookies.txt")

    fun hasLogin(ctx: Context) = cookiesFile(ctx).let { it.exists() && it.length() > 40 }

    fun publicFolder(base: String, sub: String): File {
        val dir = if (base == "Documents") Environment.DIRECTORY_DOCUMENTS else Environment.DIRECTORY_DOWNLOADS
        return File(Environment.getExternalStoragePublicDirectory(dir), sub.trim().trim('/'))
    }

    fun applyRobust(req: YoutubeDLRequest, ctx: Context) {
        req.addOption("--retries", "10")
        req.addOption("--fragment-retries", "10")
        req.addOption("--extractor-retries", "3")
        req.addOption("--socket-timeout", "20")
        req.addOption("-N", "8")          // Turbo: 8 hisse ek saath
        req.addOption("--no-mtime")
        req.addOption("--no-part")
        if (hasLogin(ctx)) req.addOption("--cookies", cookiesFile(ctx).absolutePath)
    }

    /** yt-dlp ke lambe error mein se asal wajah nikal kar aasan zubaan mein */
    fun friendlyError(raw: String?): String {
        val text = raw ?: return "Pata nahi kya hua"
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val err = (lines.lastOrNull { it.startsWith("ERROR") } ?: lines.lastOrNull { !it.startsWith("WARNING") }
            ?: lines.lastOrNull() ?: text).removePrefix("ERROR:").trim()
        val all = text.lowercase()
        return when {
            "429" in all || "too many requests" in all || "rate-limit" in all || "rate limit" in all ->
                "Platform ne zyada requests par roka. 'Ek saath' 1-2 karein, thori der baad try"
            "secondary user id" in all || "unable to extract" in all && "tiktok" in all ->
                "TikTok ne profile ki list nahi di. 🔑 Login karein ya kuch der baad try"
            "login" in all || "cookies" in all || "private" in all || "sign in" in all ->
                "Login chahiye. Settings → 🔑 Login"
            "404" in all || "does not exist" in all || "not found" in all || "no longer available" in all ->
                "Profile ya video nahi mili. Link check karein"
            "timed out" in all || "network" in all || "connection" in all || "resolve host" in all ->
                "Internet ka masla. Connection check karke dobara"
            "videos ki list nahi mili" in all -> "Is account se videos ki list nahi mili"
            else -> err.take(120)
        }
    }

    fun applyQuality(req: YoutubeDLRequest, quality: String) {
        if (quality == "MP3") {
            req.addOption("-x")
            req.addOption("--audio-format", "mp3")
            req.addOption("--audio-quality", "0")
        } else {
            req.addOption("-f", formatFor(quality))
            req.addOption("--merge-output-format", "mp4")
        }
    }

    fun update(ctx: Context): String = try {
        val r = YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.NIGHTLY)
        ctx.getSharedPreferences("engine", Context.MODE_PRIVATE).edit()
            .putLong("last_update", System.currentTimeMillis()).apply()
        if (r == YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE) "Engine pehle se latest hai" else "Engine update ho gaya"
    } catch (e: Exception) {
        "Update nahi hua: ${e.message?.take(150)}"
    }

    /** Din mein ek dafa khud update */
    fun autoUpdateIfNeeded(ctx: Context) {
        val last = ctx.getSharedPreferences("engine", Context.MODE_PRIVATE).getLong("last_update", 0)
        if (System.currentTimeMillis() - last > 24L * 60 * 60 * 1000) update(ctx)
    }

    /** WebView login ke cookies ko yt-dlp ke liye file mein save karta hai */
    fun saveCookies(ctx: Context): Int {
        val cm = CookieManager.getInstance()
        cm.flush()
        val domains = listOf("instagram.com", "facebook.com", "tiktok.com", "x.com", "twitter.com")
        val exp = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        var count = 0
        for (d in domains) {
            val raw = cm.getCookie("https://www.$d") ?: continue
            raw.split(";").forEach { part ->
                val kv = part.trim()
                val i = kv.indexOf('=')
                if (i > 0) {
                    sb.append(".$d\tTRUE\t/\tTRUE\t$exp\t${kv.substring(0, i)}\t${kv.substring(i + 1)}\n")
                    count++
                }
            }
        }
        cookiesFile(ctx).writeText(sb.toString())
        return count
    }

    fun logout(ctx: Context) {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        cookiesFile(ctx).delete()
    }
}

fun formatFor(quality: String): String = when (quality) {
    "1080p" -> "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/bv*[height<=1080]+ba/b[height<=1080]/b"
    "720p" -> "bv*[height<=720][ext=mp4]+ba[ext=m4a]/bv*[height<=720]+ba/b[height<=720]/b"
    "480p" -> "bv*[height<=480][ext=mp4]+ba[ext=m4a]/bv*[height<=480]+ba/b[height<=480]/b"
    else -> "bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b"
}

/** Ek video download. Fail ho to engine update karke ek dafa dobara try. */
fun downloadSingle(
    ctx: Context,
    url: String,
    quality: String,
    folder: File,
    onProgress: (Float, String) -> Unit
): String {
    folder.mkdirs()
    fun build() = YoutubeDLRequest(url).apply {
        addOption("-o", folder.absolutePath + "/%(title).80s.%(ext)s")
        addOption("--no-playlist")
        addCommands(Titles.command(ctx))   // caption ke liye asal title
        Engine.applyRobust(this, ctx)
        Engine.applyQuality(this, quality)
    }
    fun run() = YoutubeDL.getInstance().execute(build(), null, false) { p, _, line -> onProgress(p, line) }
        .also { Titles.invalidate() }

    return try {
        run()
        "Mukammal! File ${folder.name} folder mein hai"
    } catch (e: YoutubeDL.CanceledException) {
        "Roka gaya"
    } catch (e: Exception) {
        onProgress(-1f, "Masla aaya, engine update karke dobara try ho raha hai...")
        Engine.update(ctx)
        try {
            run()
            "Mukammal! File ${folder.name} folder mein hai"
        } catch (e2: Exception) {
            val msg = e2.message ?: ""
            val hint = when {
                msg.contains("login", true) || msg.contains("cookies", true) || msg.contains("private", true) ->
                    "Is video ke liye login chahiye. 🔑 Login dabayein."
                msg.contains("DRM", true) -> "Ye video DRM se protected hai, download nahi ho sakti."
                else -> "Link check karein ya thori der baad try karein."
            }
            "Download nahi hua. $hint\n\n${msg.take(200)}"
        }
    }
}

// ================= Creator search (YouTube) =================

data class FoundCreator(val name: String, val url: String)

fun searchYouTubeCreators(query: String): List<FoundCreator> {
    val req = YoutubeDLRequest("ytsearch25:$query").apply {
        addOption("--flat-playlist")
        addOption("-J")
    }
    val resp = YoutubeDL.getInstance().execute(req, null, false, null)
    val entries = JSONObject(resp.out).optJSONArray("entries") ?: return emptyList()
    val map = LinkedHashMap<String, FoundCreator>()
    for (i in 0 until entries.length()) {
        val e = entries.optJSONObject(i) ?: continue
        val name = e.optString("channel").ifBlank { e.optString("uploader") }
        var url = e.optString("channel_url")
        if (url.isBlank()) {
            val id = e.optString("channel_id")
            if (id.isNotBlank()) url = "https://www.youtube.com/channel/$id"
        }
        if (name.isNotBlank() && url.isNotBlank() && !map.containsKey(url)) map[url] = FoundCreator(name, url)
    }
    return map.values.take(10)
}
