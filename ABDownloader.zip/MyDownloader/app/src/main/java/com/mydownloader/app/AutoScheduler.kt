package com.mydownloader.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar

/** Roz ek muqarrar waqt par creators ka download khud shuru */
object AutoScheduler {

    private fun pending(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 900, Intent(ctx, AutoReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun canExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(AlarmManager::class.java)
        return am.canScheduleExactAlarms()
    }

    fun nextTime(hour: Int, minute: Int): Long {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= System.currentTimeMillis() + 30_000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    /** Settings ke mutabiq alarm lagao ya hatao */
    fun apply(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx))
        if (!Jobs.autoOn) return
        val at = nextTime(Jobs.autoHour, Jobs.autoMinute)
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
        }
    }

    fun label(h: Int, m: Int): String {
        val ampm = if (h < 12) "AM" else "PM"
        val hh = if (h % 12 == 0) 12 else h % 12
        return String.format("%d:%02d %s", hh, m, ampm)
    }

    /** Auto chal na sake to user ko batayein */
    fun tellUser(ctx: Context, text: String) {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
                    NotificationChannel("auto", "Automatic download", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
            val open = PendingIntent.getActivity(
                ctx, 901, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, "auto")
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(ctx.getString(R.string.app_name))
                .setContentText(text)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(ctx).notify(79, n)
        } catch (e: SecurityException) { }
    }
}

/** Download se pehle hifazati checks */
object Guards {
    const val MIN_FREE_BYTES = 1L shl 30 // 1 GB

    fun onWifi(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    fun freeBytes(): Long = try {
        StatFs(Environment.getExternalStorageDirectory().path).availableBytes
    } catch (e: Exception) { Long.MAX_VALUE }

    /** null = sab theek. Warna wajah */
    fun blockReason(ctx: Context): String? = when {
        Jobs.wifiOnly && !onWifi(ctx) -> "📶 Wi-Fi only on hai, abhi Wi-Fi nahi. Wi-Fi se judein."
        freeBytes() < MIN_FREE_BYTES -> "💾 Phone mein 1 GB se kam jagah bachi hai, download roka gaya."
        else -> null
    }
}

class AutoReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val ctx = context.applicationContext
        Jobs.init(ctx)
        AutoScheduler.apply(ctx) // kal ka alarm abhi se
        if (!Jobs.autoOn) return
        val reason = Guards.blockReason(ctx)
        when {
            reason != null -> AutoScheduler.tellUser(ctx, "Aaj ka auto download nahi hua: $reason")
            Jobs.running -> { }
            Jobs.creators.none { it.enabled } -> { }
            else -> Jobs.runQueue(ctx, Jobs.creators.map { it.id }, manual = false)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val ctx = context.applicationContext
        Jobs.init(ctx)
        AutoScheduler.apply(ctx)
    }
}
