package com.mydownloader.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.material3.Text
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** App khulte waqt "AB" ki chamakti VIP entry (~2 second) */
@Composable
fun AbSplash(onDone: () -> Unit) {
    val appear = remember { Animatable(0f) }
    val textIn = remember { Animatable(0f) }
    val out = remember { Animatable(1f) }
    val spin = rememberInfiniteTransition(label = "spin")
    val angle by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "a")
    val bar = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        appear.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 180f))
    }
    LaunchedEffect(Unit) {
        delay(350)
        textIn.animateTo(1f, tween(600))
    }
    LaunchedEffect(Unit) {
        bar.animateTo(1f, tween(1700, easing = FastOutSlowInEasing))
        out.animateTo(0f, tween(350))
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .alpha(out.value)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .background(
                Brush.radialGradient(
                    listOf(Neon.Violet.copy(alpha = 0.35f), Neon.Bg2, Neon.Bg1),
                    radius = 1400f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(190.dp)) {
                // Ghoomta neon chhalla
                Canvas(Modifier.fillMaxSize().rotate(angle).alpha(appear.value)) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(Color.Transparent, Neon.Violet, Neon.Purple, Neon.Pink, Color.Transparent)
                        ),
                        startAngle = 0f, sweepAngle = 300f, useCenter = false,
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                    drawCircle(
                        color = Neon.Pink.copy(alpha = 0.9f), radius = 5.dp.toPx(),
                        center = Offset(size.width / 2 + size.width / 2 - 3.dp.toPx(), size.height / 2)
                    )
                }
                Image(
                    painterResource(R.drawable.ic_launcher), null,
                    modifier = Modifier.size(130.dp).scale(0.5f + appear.value * 0.5f).alpha(appear.value)
                )
            }
            Spacer(Modifier.height(26.dp))
            Text(
                stringResource(R.string.app_name),
                style = TextStyle(brush = Neon.Gradient, fontSize = 34.sp, fontWeight = FontWeight.Black),
                modifier = Modifier.alpha(textIn.value)
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "👑  V I P   E D I T I O N",
                color = Neon.Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                modifier = Modifier.alpha(textIn.value)
            )
            Spacer(Modifier.height(34.dp))
            Box(Modifier.width(160.dp).height(4.dp).background(Neon.Card, androidx.compose.foundation.shape.RoundedCornerShape(50))) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(bar.value)
                        .background(Neon.Gradient, androidx.compose.foundation.shape.RoundedCornerShape(50))
                )
            }
        }
        Text(
            "Made with 💜 by ${stringResource(R.string.owner_name)}",
            color = Neon.Muted, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 28.dp).alpha(textIn.value)
        )
    }
}
