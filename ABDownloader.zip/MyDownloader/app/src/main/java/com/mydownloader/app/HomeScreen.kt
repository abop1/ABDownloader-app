package com.mydownloader.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun HomeScreen(initialLink: String) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val appName = stringResource(R.string.app_name)
    val owner = stringResource(R.string.owner_name)

    var link by remember(initialLink) { mutableStateOf(initialLink) }
    var quality by remember { mutableStateOf("Best") }
    var clipOffer by remember { mutableStateOf<String?>(null) }
    var lastOffered by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<PreviewInfo?>(null) }
    var previewLoading by remember { mutableStateOf(false) }
    var recent by remember { mutableStateOf<List<File>>(emptyList()) }

    val busy = Jobs.singleBusy
    val progress by animateFloatAsState(Jobs.singleProgress, label = "p")
    val glow = rememberInfiniteTransition(label = "glow")
    val glowAlpha by glow.animateFloat(0.35f, 1f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "g")
    val platform = remember(link) { detectPlatform(link.trim()) }

    // 📋 Clipboard mein link? App khulne / wapas aane par ek dafa poochho
    var resumeTick by remember { mutableIntStateOf(0) }
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) resumeTick++
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(resumeTick) {
        if (resumeTick == 0) return@LaunchedEffect
        delay(700) // window focus milne ka intezar (Android tabhi clipboard deta hai)
        val clip = try { findLink(clipboard.getText()?.text) } catch (e: Exception) { null }
        if (clip != null && clip != lastOffered && clip != link.trim() && link.isBlank() && !Jobs.singleBusy) {
            clipOffer = clip
            lastOffered = clip
        }
    }

    // 👀 Link daalte hi jhalak
    LaunchedEffect(link) {
        preview = null
        val u = link.trim()
        if (!u.startsWith("http")) return@LaunchedEffect
        delay(700)
        previewLoading = true
        preview = withContext(Dispatchers.IO) { try { LinkPreview.fetch(context, u) } catch (e: Exception) { null } }
        previewLoading = false
    }

    // Haal hi ki videos
    LaunchedEffect(Jobs.singleBusy, Jobs.running) {
        recent = withContext(Dispatchers.IO) { try { scanMedia(context).take(12) } catch (e: Exception) { emptyList() } }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ---- Salaam ----
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${timeGreeting()}, $owner 👋", color = Neon.Muted, fontSize = 14.sp)
                Text(appName, style = TextStyle(brush = Neon.Gradient, fontSize = 28.sp, fontWeight = FontWeight.Black))
            }
            Text(
                "👑 VIP", color = Neon.Gold, fontSize = 12.sp, fontWeight = FontWeight.Black,
                modifier = Modifier
                    .border(1.dp, Neon.Gold.copy(alpha = glowAlpha), RoundedCornerShape(50))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            )
        }

        // ---- 📋 Clipboard offer ----
        AnimatedVisibility(clipOffer != null, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            val p = detectPlatform(clipOffer ?: "")
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.horizontalGradient(listOf(Neon.Violet.copy(alpha = 0.45f), Neon.Pink.copy(alpha = 0.25f))))
                    .border(1.dp, Neon.Pink.copy(alpha = 0.7f), RoundedCornerShape(18.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.ContentPaste, null, tint = Color.White)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("${p?.name ?: "Video"} link mila!", color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Download karein?", color = Neon.Muted, fontSize = 12.sp)
                }
                Text(
                    "Haan", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(Neon.Gradient)
                        .clickable { link = clipOffer ?: ""; clipOffer = null }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )
                Spacer(Modifier.width(4.dp))
                IconBtn(Icons.Rounded.Close, filled = false, size = 30) { clipOffer = null }
            }
        }

        // ---- Hero: link + jhalak + download ----
        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Video link", color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                if (platform != null && link.isNotBlank()) {
                    Text(
                        "● ${platform.name}", color = platform.color, fontSize = 12.sp, fontWeight = FontWeight.Black,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(platform.color.copy(alpha = 0.15f))
                            .border(1.dp, platform.color.copy(alpha = 0.6f), RoundedCornerShape(50))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            NeonField(link, { link = it }, "https://...")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonOutlineButton("📋  Paste", Modifier.weight(1f)) {
                    findLink(clipboard.getText()?.text)?.let { link = it } ?: clipboard.getText()?.text?.let { link = it.trim() }
                }
                NeonOutlineButton("✕  Clear", Modifier.weight(1f)) { link = "" }
            }

            // Jhalak
            if (previewLoading || preview != null) {
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Neon.Bg1.copy(alpha = 0.6f)).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(width = 72.dp, height = 96.dp).clip(RoundedCornerShape(10.dp))
                            .background(Neon.Card).alpha(if (previewLoading) glowAlpha else 1f),
                        contentAlignment = Alignment.Center
                    ) {
                        preview?.thumb?.let {
                            Image(it.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        } ?: Icon(Icons.Rounded.SmartDisplay, null, tint = Neon.Muted)
                        preview?.duration?.takeIf { it > 0 }?.let {
                            Text(
                                fmtDuration(it), color = Color.White, fontSize = 10.sp,
                                modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                                    .clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(alpha = 0.6f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        if (previewLoading) {
                            Text("Video dekh rahe hain...", color = Neon.Muted, fontSize = 13.sp, modifier = Modifier.alpha(glowAlpha))
                        } else preview?.let { pv ->
                            Text(pv.title, color = Neon.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 3, overflow = TextOverflow.Ellipsis)
                            if (pv.uploader.isNotBlank()) Text("@${pv.uploader}", color = Neon.Purple, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                qualities.forEach { q -> QualityChip(q, quality == q, Modifier.weight(1f)) { quality = q } }
            }
            Spacer(Modifier.height(14.dp))
            GlowButton(
                if (busy) "DOWNLOADING..." else "DOWNLOAD",
                enabled = !busy && link.isNotBlank(),
                icon = Icons.Rounded.Bolt,
                modifier = if (busy) Modifier.alpha(glowAlpha) else Modifier
            ) {
                val folder = Engine.publicFolder("Download", appName.replace(" ", ""))
                Jobs.startSingle(context, link.trim(), quality, folder)
            }

            if (busy || progress > 0f) {
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${(progress * 100).toInt()}%",
                        style = TextStyle(brush = Neon.Gradient, fontSize = 30.sp, fontWeight = FontWeight.Black))
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End) {
                        Text("⚡ ${Jobs.singleSpeed}", color = Neon.Text, fontSize = 12.sp)
                        Text("⏱ ${Jobs.singleEta}", color = Neon.Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                NeonProgressBar(progress, 8)
                Spacer(Modifier.height(6.dp))
                Text(Jobs.singleStatus, color = Neon.Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }

        // ---- Quick actions ----
        val creatorsOn = Jobs.creators.count { it.enabled }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction(Icons.Rounded.PlayCircle, if (Jobs.running) "Chal raha" else "Creators", "$creatorsOn on", Modifier.weight(1f)) {
                if (!Jobs.running && creatorsOn > 0) Jobs.runQueue(context, Jobs.creators.map { it.id }, manual = false)
                NavState.tab = 1
            }
            QuickAction(Icons.Rounded.RocketLaunch, "Agli upload", "Gallery", Modifier.weight(1f)) { NavState.tab = 2 }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction(Icons.Rounded.Insights, "Stats", "${Jobs.historyCount} kul", Modifier.weight(1f)) { NavState.tab = 3 }
            QuickAction(Icons.Rounded.Palette, "Theme", Themes.current.name, Modifier.weight(1f)) {
                val i = Themes.all.indexOf(Themes.current)
                Themes.set(context, Themes.all[(i + 1) % Themes.all.size])
            }
        }

        // ---- Haal hi ki videos ----
        if (recent.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionLabel("Haal hi mein")
                Spacer(Modifier.weight(1f))
                Text("Sab dekhein ›", color = Neon.Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { NavState.tab = 2 }.padding(6.dp))
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(recent, key = { it.absolutePath }) { f ->
                    val thumb by produceState<ImageBitmap?>(null, f.absolutePath) {
                        value = withContext(Dispatchers.IO) { Thumbs.get(f)?.asImageBitmap() }
                    }
                    Box(
                        Modifier.size(width = 104.dp, height = 150.dp).clip(RoundedCornerShape(16.dp))
                            .background(Neon.Card).border(1.dp, Neon.Violet.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                            .clickable { Overlay.player = recent to recent.indexOf(f) }
                    ) {
                        thumb?.let { Image(it, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                        Box(Modifier.fillMaxSize().background(
                            Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)))))
                        Icon(Icons.Rounded.PlayArrow, null, tint = Color.White,
                            modifier = Modifier.align(Alignment.Center).size(30.dp)
                                .clip(CircleShape).background(Color.Black.copy(alpha = 0.4f)).padding(4.dp))
                        Text(
                            Titles.get(context, f), color = Color.White, fontSize = 10.sp, maxLines = 2,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                        )
                    }
                }
            }
        }

        Text(
            "Made with 💜 by $owner", color = Neon.Muted, fontSize = 11.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 8.dp)
        )
    }
}

@Composable
private fun QuickAction(icon: ImageVector, title: String, sub: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(Neon.Card2, Neon.Card)))
            .border(1.dp, Neon.Violet.copy(alpha = 0.45f), shape)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Neon.Gradient),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            Text(sub, color = Neon.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
