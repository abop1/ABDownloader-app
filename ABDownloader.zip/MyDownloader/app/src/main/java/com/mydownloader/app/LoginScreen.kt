package com.mydownloader.app

import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay

/** Har site: login page, cookie domain, aur woh cookie jo login hone ka saboot hai */
data class SiteLogin(val name: String, val loginUrl: String, val domain: String, val proofs: List<String>, val qrUrl: String? = null)

val loginSites = listOf(
    SiteLogin("TikTok", "https://www.tiktok.com/login", "tiktok.com",
        listOf("sessionid", "sessionid_ss", "sid_tt", "sid_guard", "uid_tt"), "https://www.tiktok.com/login/qrcode"),
    SiteLogin("Instagram", "https://www.instagram.com/accounts/login/", "instagram.com", listOf("sessionid", "ds_user_id")),
    SiteLogin("Facebook", "https://m.facebook.com/login/", "facebook.com", listOf("c_user", "xs")),
    SiteLogin("X", "https://x.com/i/flow/login", "x.com", listOf("auth_token", "twid"))
)

object LoginStatus {
    fun connected(site: SiteLogin): Boolean = try {
        val all = listOf("https://www.${site.domain}", "https://${site.domain}", "https://m.${site.domain}")
            .joinToString(";") { CookieManager.getInstance().getCookie(it) ?: "" }
        all.split(";").map { it.trim() }.any { kv ->
            val name = kv.substringBefore("=")
            name in site.proofs && kv.substringAfter("=", "").length > 3
        }
    } catch (e: Exception) { false }

    fun connectedNames(): List<String> = loginSites.filter { connected(it) }.map { it.name }
}

private const val DESKTOP_UA =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

@Composable
fun LoginScreen(onClose: (String) -> Unit) {
    val context = LocalContext.current
    var site by remember { mutableStateOf(loginSites[0]) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var mobileUa by remember { mutableStateOf("") }
    var qrMode by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(loginSites.associate { it.name to LoginStatus.connected(it) }) }
    var justConnected by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableIntStateOf(0) }
    var checkNow by remember { mutableIntStateOf(0) }

    fun open(s: SiteLogin, qr: Boolean) {
        val wv = webView ?: return
        wv.settings.userAgentString = if (qr) DESKTOP_UA else mobileUa
        wv.loadUrl(if (qr && s.qrUrl != null) s.qrUrl else s.loginUrl)
    }

    LaunchedEffect(site, qrMode) { open(site, qrMode) }

    // Har 2 second dekho: login hua? Hua to foran save + "connected" dikhao
    LaunchedEffect(checkNow) {
        while (true) {
            val now = loginSites.associate { it.name to LoginStatus.connected(it) }
            val newly = now.filter { it.value && status[it.key] != true }.keys.firstOrNull()
            status = now
            if (newly != null) {
                Engine.saveCookies(context)
                justConnected = newly
            }
            delay(2000)
        }
    }
    LaunchedEffect(justConnected) {
        if (justConnected != null) { delay(4000); justConnected = null }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Neon.Bg1)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "🔑 Login",
                        style = TextStyle(brush = Neon.Gradient, fontSize = 26.sp, fontWeight = FontWeight.Black),
                        modifier = Modifier.weight(1f)
                    )
                    NeonOutlineButton("Logout", Modifier.width(84.dp)) {
                        Engine.logout(context)
                        onClose("Sab accounts se logout ho gaya")
                    }
                    Spacer(Modifier.width(8.dp))
                    NeonOutlineButton("✓ Done", Modifier.width(84.dp)) {
                        Engine.saveCookies(context)
                        val names = LoginStatus.connectedNames()
                        onClose(if (names.isNotEmpty()) "✅ Connected: ${names.joinToString(", ")}" else "Koi account connect nahi hua")
                    }
                }

                // Sites + har ek ka haal
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    loginSites.forEach { s ->
                        val ok = status[s.name] == true
                        val sel = site == s
                        Text(
                            (if (ok) "✅ " else "") + s.name,
                            color = if (sel) Color.White else if (ok) Neon.Green else Neon.Muted,
                            fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .then(
                                    if (sel) Modifier.background(Neon.Gradient)
                                    else Modifier.border(1.dp, if (ok) Neon.Green else Neon.Violet.copy(alpha = 0.5f), RoundedCornerShape(50))
                                )
                                .clickable { site = s; qrMode = false }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }

                val ok = status[site.name] == true
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (ok) Neon.Green.copy(alpha = 0.15f) else Neon.Card)
                        .border(1.dp, if (ok) Neon.Green else Neon.Violet.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (ok) "✅" else "⚪", fontSize = 18.sp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (ok) "${site.name} connected hai" else "${site.name} abhi connect nahi. Neeche login karein",
                        color = if (ok) Neon.Green else Neon.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    if (site.qrUrl != null) {
                        Text(
                            if (qrMode) "⌨ Normal" else "📱 QR code",
                            color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Neon.Gradient)
                                .clickable { qrMode = !qrMode }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
                if (qrMode) {
                    Text(
                        "QR ko dusre phone ki TikTok app se scan karein: TikTok → Profile → upar ☰ / scan icon → Scan. " +
                            "Page chhota dikhe to do ungliyon se zoom karein.",
                        color = Neon.Gold, fontSize = 11.sp
                    )
                } else {
                    Text(
                        "Email, phone ya username se login karein. \"Google se login\" yahan nahi chalta.",
                        color = Neon.Muted, fontSize = 11.sp
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonOutlineButton("↻ Reload", Modifier.weight(1f)) { webView?.reload() }
                    NeonOutlineButton("🏠 Login page", Modifier.weight(1f)) { open(site, qrMode) }
                    NeonOutlineButton("🔍 Check", Modifier.weight(1f)) { checkNow++ }
                }
                if (loading in 1..99) NeonProgressBar(loading / 100f, 4)
            }
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        settings.userAgentString = settings.userAgentString.replace("; wv", "")
                        mobileUa = settings.userAgentString
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        webViewClient = object : WebViewClient() {
                            // TikTok login ke baad apni app ("snssdk://", "intent://") kholne ki koshish karta hai
                            // jis se screen safed ho kar atak jati thi. Woh links rok do.
                            override fun shouldOverrideUrlLoading(
                                view: WebView?, request: android.webkit.WebResourceRequest?
                            ): Boolean {
                                val scheme = request?.url?.scheme ?: return false
                                return scheme != "http" && scheme != "https"
                            }
                            override fun onPageFinished(view: WebView?, url: String?) {
                                CookieManager.getInstance().flush()
                                checkNow++
                            }
                        }
                        webChromeClient = object : android.webkit.WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                loading = newProgress
                            }
                        }
                        loadUrl(site.loginUrl)
                        webView = this
                    }
                }
            )
        }

        // ---- ✅ Successfully connected banner ----
        AnimatedVisibility(
            visible = justConnected != null,
            enter = slideInVertically { -it } + fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 12.dp)
        ) {
            Column(
                Modifier
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Neon.Green)
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("✅ ${justConnected ?: ""} successfully connected!", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text("Save ho gaya. Ab ✓ Done daba sakte hain", color = Color.Black.copy(alpha = 0.7f), fontSize = 12.sp)
            }
        }
    }
}
