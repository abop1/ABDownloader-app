package com.mydownloader.app

import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

val loginSites = listOf(
    "Instagram" to "https://www.instagram.com/accounts/login/",
    "Facebook" to "https://m.facebook.com/login/",
    "TikTok" to "https://www.tiktok.com/login",
    "X" to "https://x.com/i/flow/login"
)

@Composable
fun LoginScreen(onClose: (String) -> Unit) {
    val context = LocalContext.current
    var site by remember { mutableStateOf(loginSites[0]) }
    var webView by remember { mutableStateOf<WebView?>(null) }

    LaunchedEffect(site) { webView?.loadUrl(site.second) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Neon.Bg1)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row {
                Text(
                    "🔑 Login",
                    style = TextStyle(brush = Neon.Gradient, fontSize = 26.sp, fontWeight = FontWeight.Black),
                    modifier = Modifier.weight(1f)
                )
                NeonOutlineButton("Logout", Modifier.width(90.dp)) {
                    Engine.logout(context)
                    onClose("Sab accounts se logout ho gaya")
                }
                Spacer(Modifier.width(8.dp))
                NeonOutlineButton("✓ Done", Modifier.width(90.dp)) {
                    val n = Engine.saveCookies(context)
                    onClose(if (n > 0) "Login save ho gaya ✓" else "Login nahi mila, pehle account mein login karein")
                }
            }
            Text(
                "Apne account mein login karein, phir Done dabayein. Is se private aur login wali videos bhi download hongi. Password app save nahi karti.",
                color = Neon.Muted, fontSize = 12.sp
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                loginSites.forEach { s ->
                    QualityChip(s.first, site == s, Modifier.width(96.dp)) { site = s }
                }
            }
        }
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.userAgentString = settings.userAgentString.replace("; wv", "")
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webViewClient = WebViewClient()
                    loadUrl(site.second)
                    webView = this
                }
            }
        )
    }
}
