package com.mydownloader.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Creators list + settings + history ka backup.
 * - Har tabdeeli par khud ek copy: Download/ABDownloader/backup/AB_backup.json
 * - Reinstall ke baad "Backup se wapas laayein" se sab wapas
 */
object Backup {

    fun autoFile(ctx: Context): File =
        File(Engine.publicFolder("Download", ctx.getString(R.string.app_name).replace(" ", "") + "/backup"), "AB_backup.json")

    fun toJson(ctx: Context): String {
        val o = JSONObject()
        o.put("app", "ABDownloader")
        o.put("version", 1)
        o.put("time", System.currentTimeMillis())
        o.put("creators", CreatorStore.toJson(Jobs.creators))
        o.put(
            "settings", JSONObject()
                .put("perCreator", Jobs.perCreator).put("random", Jobs.random)
                .put("quality", Jobs.quality).put("cleanOld", Jobs.cleanOld)
                .put("parallel", Jobs.parallel).put("wifiOnly", Jobs.wifiOnly)
                .put("autoOn", Jobs.autoOn).put("autoHour", Jobs.autoHour).put("autoMinute", Jobs.autoMinute)
        )
        val hist = JSONArray()
        val f = archiveFile(ctx)
        if (f.exists()) f.readLines().filter { it.isNotBlank() }.forEach { hist.put(it) }
        o.put("history", hist)
        return o.toString()
    }

    fun autoSave(ctx: Context) {
        try {
            val f = autoFile(ctx)
            f.parentFile?.mkdirs()
            f.writeText(toJson(ctx))
        } catch (e: Exception) { }
    }

    fun writeTo(ctx: Context, uri: Uri): Boolean = try {
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(toJson(ctx).toByteArray()) }
        true
    } catch (e: Exception) { false }

    /** Wapas: kitne naye creators aaye (-1 = file ghalat) */
    fun restoreFrom(ctx: Context, uri: Uri): Int = try {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        restore(ctx, text)
    } catch (e: Exception) { -1 }

    fun restore(ctx: Context, text: String): Int {
        val o = JSONObject(text)
        if (o.optString("app") != "ABDownloader") return -1

        // Creators (jo pehle se hain, unhein dobara nahi)
        val incoming = CreatorStore.fromJson(ctx, o.optJSONArray("creators") ?: JSONArray())
        var added = 0
        incoming.forEach { c ->
            if (Jobs.creators.none { it.url.trimEnd('/') == c.url.trimEnd('/') }) {
                Jobs.creators.add(c); added++
            }
        }

        // Settings
        o.optJSONObject("settings")?.let { st ->
            Jobs.perCreator = st.optInt("perCreator", Jobs.perCreator)
            Jobs.random = st.optBoolean("random", Jobs.random)
            Jobs.quality = st.optString("quality", Jobs.quality)
            Jobs.cleanOld = st.optBoolean("cleanOld", Jobs.cleanOld)
            Jobs.parallel = st.optInt("parallel", Jobs.parallel)
            Jobs.wifiOnly = st.optBoolean("wifiOnly", Jobs.wifiOnly)
            Jobs.autoOn = st.optBoolean("autoOn", Jobs.autoOn)
            Jobs.autoHour = st.optInt("autoHour", Jobs.autoHour)
            Jobs.autoMinute = st.optInt("autoMinute", Jobs.autoMinute)
        }

        // History (taake purani videos dobara download na hon)
        o.optJSONArray("history")?.let { h ->
            val f = archiveFile(ctx)
            val have = if (f.exists()) f.readLines().toHashSet() else HashSet()
            val extra = (0 until h.length()).map { h.getString(it) }.filter { it.isNotBlank() && it !in have }
            if (extra.isNotEmpty()) f.appendText(extra.joinToString("\n", postfix = "\n"))
        }

        Jobs.creators.forEach { Engine.publicFolder(it.base, it.folder).mkdirs() }
        Jobs.saveCreators(ctx)
        Jobs.saveSettings(ctx)
        Jobs.historyCount = countLines(archiveFile(ctx))
        AutoScheduler.apply(ctx)
        return added
    }
}
