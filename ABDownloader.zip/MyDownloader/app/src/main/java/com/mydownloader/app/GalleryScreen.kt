package com.mydownloader.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.webkit.MimeTypeMap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private val mediaExt = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp", "mp3", "m4a", "opus", "aac", "wav")
private val audioExt = setOf("mp3", "m4a", "opus", "aac", "wav")

/** App ke saare folders mein videos dhoondta hai (naye sabse upar) */
fun scanMedia(ctx: Context): List<File> {
    val roots = mutableSetOf<File>()
    roots += Engine.publicFolder("Download", ctx.getString(R.string.app_name).replace(" ", ""))
    Jobs.creators.forEach { roots += Engine.publicFolder(it.base, it.folder) }
    val out = LinkedHashMap<String, File>()
    roots.filter { it.exists() }.forEach { root ->
        root.walkTopDown().maxDepth(4).forEach { f ->
            if (f.isFile && f.extension.lowercase() in mediaExt && f.length() > 0) out[f.absolutePath] = f
        }
    }
    return out.values.sortedByDescending { it.lastModified() }
}

fun humanSize(bytes: Long): String = when {
    bytes >= 1L shl 30 -> String.format("%.1f GB", bytes / (1L shl 30).toDouble())
    bytes >= 1L shl 20 -> String.format("%.1f MB", bytes / (1L shl 20).toDouble())
    else -> "${bytes / 1024} KB"
}

object Thumbs {
    private val cache = LruCache<String, Bitmap>(80)

    fun get(f: File): Bitmap? {
        cache.get(f.absolutePath)?.let { return it }
        if (f.extension.lowercase() in audioExt) return null
        val bmp = try {
            if (Build.VERSION.SDK_INT >= 29) ThumbnailUtils.createVideoThumbnail(f, Size(320, 180), null)
            else ThumbnailUtils.createVideoThumbnail(f.absolutePath, MediaStore.Images.Thumbnails.MINI_KIND)
        } catch (e: Exception) { null }
        if (bmp != null) cache.put(f.absolutePath, bmp)
        return bmp
    }
}

private fun uriFor(ctx: Context, f: File) = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)

private fun mimeOf(f: File): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase())
        ?: if (f.extension.lowercase() in audioExt) "audio/*" else "video/*"

fun playFile(ctx: Context, f: File) {
    try {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(ctx, f), mimeOf(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Chalayein").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    } catch (e: Exception) { }
}

/** Video share + us ka title saath (caption). Title clipboard mein bhi copy hota hai. */
fun shareFile(ctx: Context, f: File) {
    try {
        val title = Titles.get(ctx, f)
        copyText(ctx, title)
        Toast.makeText(ctx, "📋 Title copy ho gaya — caption mein Paste karein", Toast.LENGTH_LONG).show()
        val uri = uriFor(ctx, f)
        val i = Intent(Intent.ACTION_SEND).setType(mimeOf(f))
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_TEXT, title)      // WhatsApp, Telegram waghera khud caption laga dete hain
            .putExtra(Intent.EXTRA_SUBJECT, title)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri("", uri)
        ctx.startActivity(Intent.createChooser(i, "Share karein"))
    } catch (e: Exception) { }
}

fun copyText(ctx: Context, text: String) {
    try {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("title", text))
    } catch (e: Exception) { }
}

@Composable
fun GalleryScreen(visible: Boolean) {
    val context = LocalContext.current
    var files by remember { mutableStateOf<List<File>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var folder by remember { mutableStateOf("Sab") }
    var toDelete by remember { mutableStateOf<File?>(null) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("Nayi") }

    // Tab khulte hi (aur download khatam hote hi) list taaza
    LaunchedEffect(visible, refreshKey, Jobs.running, Jobs.singleBusy) {
        if (visible) {
            loading = true
            Titles.invalidate()
            files = withContext(Dispatchers.IO) {
                try { Titles.all(context); scanMedia(context) } catch (e: Exception) { emptyList() }
            }
            loading = false
        }
    }

    val folders = remember(files) { listOf("Sab") + files.mapNotNull { it.parentFile?.name }.distinct() }
    val shown = files
        .filter { folder == "Sab" || it.parentFile?.name == folder }
        .filter {
            search.isBlank() || it.name.contains(search.trim(), ignoreCase = true) ||
                Titles.get(context, it).contains(search.trim(), ignoreCase = true)
        }
        .let { list ->
            when (sort) {
                "Purani" -> list.sortedBy { it.lastModified() }
                "Bari" -> list.sortedByDescending { it.length() }
                "Naam" -> list.sortedBy { it.name.lowercase() }
                else -> list.sortedByDescending { it.lastModified() }
            }
        }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Gallery", style = TextStyle(brush = Neon.Gradient, fontSize = 32.sp, fontWeight = FontWeight.Black))
                Text(
                    "${shown.size} files  •  ${humanSize(shown.sumOf { it.length() })}",
                    color = Neon.Muted, fontSize = 13.sp
                )
            }
            IconCircle(if (loading) "…" else "↻", filled = false) { refreshKey++ }
        }
        Spacer(Modifier.height(10.dp))
        NeonField(search, { search = it }, "🔍 Video ka naam dhoondein")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Nayi", "Purani", "Bari", "Naam").forEach { o ->
                QualityChip(o, sort == o, Modifier.weight(1f)) { sort = o }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            folders.forEach { f ->
                Text(
                    f,
                    color = if (folder == f) Color.White else Neon.Muted,
                    fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .then(
                            if (folder == f) Modifier.background(Neon.Gradient)
                            else Modifier.border(1.dp, Neon.Violet.copy(alpha = 0.5f), RoundedCornerShape(50))
                        )
                        .clickable { folder = f }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
        Spacer(Modifier.height(10.dp))

        if (!loading && shown.isEmpty() && search.isNotBlank()) {
            Text("\"$search\" naam ki koi video nahi mili", color = Neon.Muted, fontSize = 13.sp)
        } else if (!loading && shown.isEmpty()) {
            Text(
                "Abhi koi video nahi. Download ya Creators tab se videos download karein, yahan nazar aayengi.",
                color = Neon.Muted, fontSize = 13.sp
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 16.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(shown, key = { it.absolutePath }) { f ->
                MediaCard(
                    file = f,
                    onPlay = { playFile(context, f) },
                    onShare = { shareFile(context, f) },
                    onDelete = { toDelete = f }
                )
            }
        }
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = Neon.Card,
            title = { Text("Delete karein?", color = Neon.Text, fontWeight = FontWeight.Bold) },
            text = { Text(f.name, color = Neon.Muted, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = {
                    if (f.delete()) files = files.filterNot { it.absolutePath == f.absolutePath }
                    toDelete = null
                }) { Text("Delete", color = Neon.Pink, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel", color = Neon.Muted) } }
        )
    }
}

@Composable
fun MediaCard(file: File, onPlay: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit) {
    val context = LocalContext.current
    val title = remember(file.absolutePath) { Titles.get(context, file) }
    val thumb by produceState<ImageBitmap?>(null, file.absolutePath) {
        value = withContext(Dispatchers.IO) { Thumbs.get(file)?.asImageBitmap() }
    }
    val isAudio = file.extension.lowercase() in audioExt
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .clip(shape)
            .background(Neon.Card)
            .border(1.dp, Neon.Violet.copy(alpha = 0.35f), shape)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 10f)
                .background(Neon.Bg1)
                .clickable(onClick = onPlay),
            contentAlignment = Alignment.Center
        ) {
            thumb?.let {
                Image(it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center
            ) {
                Text(if (isAudio) "🎵" else "▶", color = Color.White, fontSize = 16.sp)
            }
        }
        Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(
                title,
                color = Neon.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${humanSize(file.length())}  •  ${file.parentFile?.name ?: ""}",
                    color = Neon.Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text("📋", fontSize = 15.sp, modifier = Modifier.clip(CircleShape).clickable {
                    copyText(context, title)
                    Toast.makeText(context, "📋 Title copy ho gaya", Toast.LENGTH_SHORT).show()
                }.padding(5.dp))
                Text("📤", fontSize = 15.sp, modifier = Modifier.clip(CircleShape).clickable(onClick = onShare).padding(5.dp))
                Text("🗑", fontSize = 15.sp, modifier = Modifier.clip(CircleShape).clickable(onClick = onDelete).padding(5.dp))
            }
        }
    }
}
