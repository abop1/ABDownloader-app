package com.mydownloader.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.webkit.MimeTypeMap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private val mediaExt = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp", "mp3", "m4a", "opus", "aac", "wav")
private val audioExt = setOf("mp3", "m4a", "opus", "aac", "wav")

/** App ke saare folders mein videos dhoondta hai (naye sabse upar) */
fun scanMedia(ctx: Context): List<File> {
    val roots = mutableSetOf<File>()
    roots += Engine.publicFolder("Download", ctx.getString(R.string.app_name).replace(" ", ""))
    Jobs.creators.forEach { roots += Engine.publicFolder(it.base, it.folder) }
    val out = LinkedHashMap<String, File>()
    roots.filter { it.exists() }.forEach { root ->
        root.walkTopDown().maxDepth(4).forEach { f ->
            if (f.isFile && f.extension.lowercase() in mediaExt && f.length() > 0) out[f.absolutePath] = f
        }
    }
    return out.values.sortedByDescending { it.lastModified() }
}

fun humanSize(bytes: Long): String = when {
    bytes >= 1L shl 30 -> String.format("%.1f GB", bytes / (1L shl 30).toDouble())
    bytes >= 1L shl 20 -> String.format("%.1f MB", bytes / (1L shl 20).toDouble())
    else -> "${bytes / 1024} KB"
}

object Thumbs {
    private val cache = LruCache<String, Bitmap>(80)

    fun get(f: File): Bitmap? {
        cache.get(f.absolutePath)?.let { return it }
        if (f.extension.lowercase() in audioExt) return null
        val bmp = try {
            if (Build.VERSION.SDK_INT >= 29) ThumbnailUtils.createVideoThumbnail(f, Size(320, 180), null)
            else ThumbnailUtils.createVideoThumbnail(f.absolutePath, MediaStore.Images.Thumbnails.MINI_KIND)
        } catch (e: Exception) { null }
        if (bmp != null) cache.put(f.absolutePath, bmp)
        return bmp
    }
}

private fun uriFor(ctx: Context, f: File) = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)

private fun mimeOf(f: File): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase())
        ?: if (f.extension.lowercase() in audioExt) "audio/*" else "video/*"

fun playFile(ctx: Context, f: File) {
    try {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(ctx, f), mimeOf(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Chalayein").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    } catch (e: Exception) { }
}

/** 🚀 Upload: ek tap mein title copy + ✅ posted + share (Instagram/TikTok/WhatsApp...) */
fun uploadFile(ctx: Context, f: File) {
    Posted.mark(ctx, f)
    shareFile(ctx, f)
}

/** Video share + us ka title saath (caption). Title clipboard mein bhi copy hota hai. */
fun shareFile(ctx: Context, f: File) {
    try {
        val title = Titles.get(ctx, f)
        copyText(ctx, title)
        Toast.makeText(ctx, "✅ Posted  •  📋 Title copy — caption mein Paste karein", Toast.LENGTH_LONG).show()
        val uri = uriFor(ctx, f)
        val i = Intent(Intent.ACTION_SEND).setType(mimeOf(f))
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_TEXT, title)      // WhatsApp, Telegram waghera khud caption laga dete hain
            .putExtra(Intent.EXTRA_SUBJECT, title)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri("", uri)
        ctx.startActivity(Intent.createChooser(i, "Share karein"))
    } catch (e: Exception) { }
}

fun copyText(ctx: Context, text: String) {
    try {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("title", text))
    } catch (e: Exception) { }
}

/** Reels banane ki darkhwast (toasts ke saath) */
fun requestReels(ctx: Context, f: File) {
    when {
        ReelsMaker.busyFile != null -> Toast.makeText(ctx, "Ek reels pehle se ban rahi hai", Toast.LENGTH_SHORT).show()
        f.extension.lowercase() in audioExt -> Toast.makeText(ctx, "Audio ki reels nahi banti", Toast.LENGTH_SHORT).show()
        ReelsMaker.isVertical(f) -> Toast.makeText(ctx, "📐 Ye pehle se reels size (9:16) mein hai", Toast.LENGTH_SHORT).show()
        else -> {
            ReelsMaker.start(ctx, f)
            Toast.makeText(ctx, "📐 Reels ban rahi hai...", Toast.LENGTH_SHORT).show()
        }
    }
}

/** App bhar ke upar dikhne wale cheezein (player) */
object Overlay {
    var player by mutableStateOf<Pair<List<File>, Int>?>(null)
    var changes by mutableIntStateOf(0)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryScreen(visible: Boolean) {
    val context = LocalContext.current
    var files by remember { mutableStateOf<List<File>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var folder by remember { mutableStateOf("Sab") }
    var toDelete by remember { mutableStateOf<List<File>>(emptyList()) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("Nayi pehle") }
    var status by remember { mutableStateOf("Sab") }   // Sab / Baaqi / Posted
    var posted by remember { mutableStateOf(Posted.all(context)) }
    var showSearch by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    val selecting = selected.isNotEmpty()

    BackHandler(enabled = selecting && visible) { selected = emptySet() }

    LaunchedEffect(ReelsMaker.doneCount) {
        if (ReelsMaker.doneCount > 0) {
            Toast.makeText(context, ReelsMaker.lastMessage, Toast.LENGTH_LONG).show()
            refreshKey++
        }
    }
    // Player band hone par (post/delete hue hon) taaza
    LaunchedEffect(Overlay.changes) {
        posted = Posted.all(context)
        if (Overlay.changes > 0) refreshKey++
    }
    LaunchedEffect(visible, refreshKey, Jobs.running, Jobs.singleBusy) {
        if (visible) {
            loading = true
            Titles.invalidate()
            files = withContext(Dispatchers.IO) {
                try { Titles.all(context); scanMedia(context) } catch (e: Exception) { emptyList() }
            }
            posted = Posted.all(context)
            loading = false
        }
    }

    val folders = remember(files) { listOf("Sab") + files.mapNotNull { it.parentFile?.name }.distinct() }
    val shown = files
        .filter { folder == "Sab" || it.parentFile?.name == folder }
        .filter {
            when (status) {
                "Baaqi" -> it.absolutePath !in posted
                "Posted" -> it.absolutePath in posted
                else -> true
            }
        }
        .filter {
            search.isBlank() || it.name.contains(search.trim(), ignoreCase = true) ||
                Titles.get(context, it).contains(search.trim(), ignoreCase = true)
        }
        .let { list ->
            when (sort) {
                "Purani pehle" -> list.sortedBy { it.lastModified() }
                "Bari pehle" -> list.sortedByDescending { it.length() }
                "Naam A-Z" -> list.sortedBy { Titles.get(context, it).lowercase() }
                else -> list.sortedByDescending { it.lastModified() }
            }
        }

    fun toggleSel(f: File) {
        selected = if (f.absolutePath in selected) selected - f.absolutePath else selected + f.absolutePath
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(14.dp))
        if (selecting) {
            // ---- Kai videos chuni hui hain ----
            val chosen = files.filter { it.absolutePath in selected }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Neon.Card)
                    .border(1.dp, Neon.Pink.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconBtn(Icons.Rounded.Close, filled = false) { selected = emptySet() }
                Text(
                    "${selected.size} chuni", color = Neon.Text, fontWeight = FontWeight.Black,
                    fontSize = 16.sp, modifier = Modifier.weight(1f)
                )
                IconBtn(Icons.Rounded.DoneAll, filled = false) { selected = shown.map { it.absolutePath }.toSet() }
                IconBtn(Icons.Rounded.CheckCircle, filled = false) {
                    chosen.forEach { Posted.mark(context, it) }
                    posted = Posted.all(context)
                    Toast.makeText(context, "✅ ${chosen.size} posted mark", Toast.LENGTH_SHORT).show()
                    selected = emptySet()
                }
                IconBtn(Icons.Rounded.AspectRatio, filled = false) {
                    val todo = chosen.filter { it.extension.lowercase() !in audioExt && !ReelsMaker.isVertical(it) }
                    if (todo.isEmpty()) Toast.makeText(context, "In mein reels banane layak koi video nahi", Toast.LENGTH_SHORT).show()
                    else ReelsMaker.startBatch(context, todo)
                    selected = emptySet()
                }
                IconBtn(Icons.Rounded.WaterDrop, filled = false) {
                    when {
                        !Watermark.on -> Toast.makeText(context, "Pehle Settings → Watermark on karein", Toast.LENGTH_LONG).show()
                        Jobs.wmBusy -> Toast.makeText(context, "Watermark pehle se lag raha hai", Toast.LENGTH_SHORT).show()
                        else -> {
                            val todo = chosen.filter { it.extension.lowercase() !in audioExt }
                            Jobs.watermarkBatch(context, todo) { refreshKey++ }
                        }
                    }
                    selected = emptySet()
                }
                IconBtn(Icons.Rounded.DeleteOutline, filled = true) { toDelete = chosen }
            }
            Spacer(Modifier.height(6.dp))
            Text("Tap = chuno / hatao  •  lamba dabao = shuru", color = Neon.Muted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
        } else {
            val postedCount = files.count { it.absolutePath in posted }
            ScreenTitle("Gallery", "${files.size} videos  •  ✓ $postedCount posted  •  ${humanSize(files.sumOf { it.length() })}") {
                IconBtn(Icons.Rounded.Search, filled = showSearch) { showSearch = !showSearch; if (!showSearch) search = "" }
                Spacer(Modifier.width(8.dp))
                IconBtn(Icons.Rounded.Refresh, filled = false, enabled = !loading) { refreshKey++ }
            }
            if (showSearch) {
                Spacer(Modifier.height(10.dp))
                NeonField(search, { search = it }, "Video ka title dhoondein")
            }
            Spacer(Modifier.height(12.dp))
            val queueFiles = if (folder == "Sab") files else files.filter { it.parentFile?.name == folder }
            val (nextFile, pendingCount) = remember(files, posted, folder) { UploadQueue.next(queueFiles, posted) }
            NextUploadCard(nextFile, pendingCount, if (folder == "Sab") "" else folder) { f ->
                uploadFile(context, f)
                posted = Posted.all(context)
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Sab", "Baaqi", "Posted").forEach { o ->
                    QualityChip(o, status == o, Modifier.weight(1f)) { status = o }
                }
                QualityChip("⇅ ${sort.substringBefore(" ")}", false, Modifier.weight(1.1f)) {
                    val order = listOf("Nayi pehle", "Purani pehle", "Bari pehle", "Naam A-Z")
                    sort = order[(order.indexOf(sort) + 1) % order.size]
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                folders.forEach { f ->
                    val pend = if (f == "Sab") 0 else files.count { it.parentFile?.name == f && it.absolutePath !in posted }
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .then(
                                if (folder == f) Modifier.background(Neon.Gradient)
                                else Modifier.border(1.dp, Neon.Violet.copy(alpha = 0.5f), RoundedCornerShape(50))
                            )
                            .clickable { folder = f }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Folder, null, tint = if (folder == f) Color.White else Neon.Muted, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(
                            (if (f == "Sab") "Sab creators" else f) + (if (pend > 0) "  $pend" else ""),
                            color = if (folder == f) Color.White else Neon.Muted,
                            fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        if (!loading && shown.isEmpty() && search.isNotBlank()) {
            Text("\"$search\" naam ki koi video nahi mili", color = Neon.Muted, fontSize = 13.sp)
        } else if (!loading && shown.isEmpty()) {
            Text(
                "Abhi koi video nahi. Download ya Creators tab se videos download karein, yahan nazar aayengi.",
                color = Neon.Muted, fontSize = 13.sp
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 16.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(shown, key = { it.absolutePath }) { f ->
                MediaCard(
                    file = f,
                    posted = f.absolutePath in posted,
                    selected = f.absolutePath in selected,
                    selecting = selecting,
                    onClick = {
                        if (selecting) toggleSel(f)
                        else Overlay.player = shown to shown.indexOf(f).coerceAtLeast(0)
                    },
                    onLongPress = { toggleSel(f) },
                    onShare = {
                        uploadFile(context, f)
                        posted = Posted.all(context)
                    },
                    onDelete = { toDelete = listOf(f) },
                    onReels = { requestReels(context, f) },
                    onPosted = {
                        val now = Posted.toggle(context, f)
                        posted = Posted.all(context)
                        Toast.makeText(context, if (now) "✅ Posted mark ho gayi" else "Posted hata diya", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }

    ReelsMaker.busyFile?.let { f ->
        AlertDialog(
            onDismissRequest = { },
            containerColor = Neon.Card,
            title = {
                Text(
                    if (ReelsMaker.batchTotal > 1) "📐 Reels bana rahe hain (${ReelsMaker.batchIndex}/${ReelsMaker.batchTotal})"
                    else "📐 Reels bana rahe hain",
                    color = Neon.Text, fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(Titles.get(context, f), color = Neon.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(14.dp))
                    Text(
                        "${(ReelsMaker.progress * 100).toInt()}%",
                        style = TextStyle(brush = Neon.Gradient, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    )
                    Spacer(Modifier.height(8.dp))
                    NeonProgressBar(ReelsMaker.progress, 8)
                    Spacer(Modifier.height(8.dp))
                    Text("9:16 size + blur background. Asal video salamat rahegi.", color = Neon.Muted, fontSize = 11.sp)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { ReelsMaker.cancel() }) { Text("Roko", color = Neon.Pink) } }
        )
    }

    if (toDelete.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { toDelete = emptyList() },
            containerColor = Neon.Card,
            title = {
                Text(
                    if (toDelete.size == 1) "Delete karein?" else "${toDelete.size} videos delete karein?",
                    color = Neon.Text, fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    if (toDelete.size == 1) Titles.get(context, toDelete[0]) else "Ye wapas nahi aayengi.",
                    color = Neon.Muted, fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val gone = toDelete.filter { it.delete() }
                    gone.forEach { Posted.forget(context, it) }
                    val goneSet = gone.map { it.absolutePath }.toSet()
                    files = files.filterNot { it.absolutePath in goneSet }
                    posted = Posted.all(context)
                    selected = emptySet()
                    toDelete = emptyList()
                    Toast.makeText(context, "🗑 ${gone.size} delete", Toast.LENGTH_SHORT).show()
                }) { Text("Delete", color = Neon.Pink, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { toDelete = emptyList() }) { Text("Cancel", color = Neon.Muted) } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MediaCard(
    file: File,
    posted: Boolean,
    selected: Boolean,
    selecting: Boolean,
    onClick: () -> Unit,
    onLongPress: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    onPosted: () -> Unit,
    onReels: () -> Unit
) {
    val context = LocalContext.current
    val title = remember(file.absolutePath) { Titles.get(context, file) }
    val thumb by produceState<ImageBitmap?>(null, file.absolutePath) {
        value = withContext(Dispatchers.IO) { Thumbs.get(file)?.asImageBitmap() }
    }
    val isAudio = file.extension.lowercase() in audioExt
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .clip(shape)
            .background(Neon.Card)
            .border(
                if (selected) 2.dp else 1.dp,
                when { selected -> Neon.Pink; posted -> Neon.Green.copy(alpha = 0.7f); else -> Neon.Violet.copy(alpha = 0.35f) },
                shape
            )
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(9f / 11f)
                .background(Neon.Bg1)
                .combinedClickable(onClick = onClick, onLongClick = onLongPress),
            contentAlignment = Alignment.Center
        ) {
            thumb?.let {
                Image(it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color.Black.copy(alpha = 0.75f)))
                )
            )
            if (!selecting) {
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f))
                        .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (isAudio) Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow, null, tint = Color.White)
                }
            }
            if (posted) {
                Row(
                    Modifier.align(Alignment.TopStart).padding(8.dp)
                        .clip(RoundedCornerShape(50)).background(Neon.Green.copy(alpha = 0.9f))
                        .padding(horizontal = 7.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(12.dp))
                    Text(" Posted", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (selecting) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(8.dp).size(26.dp).clip(CircleShape)
                        .then(if (selected) Modifier.background(Neon.Gradient) else Modifier.background(Color.Black.copy(alpha = 0.4f)))
                        .border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) { if (selected) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
            } else {
                Text(
                    humanSize(file.length()), color = Color.White, fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                        .clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.5f))
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                )
            }
            Text(
                title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.BottomStart).padding(8.dp)
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CardAction(if (posted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                if (posted) Neon.Green else Neon.Muted, onPosted)
            CardAction(Icons.Rounded.ContentCopy, Neon.Muted) {
                copyText(context, title)
                Toast.makeText(context, "📋 Title copy ho gaya", Toast.LENGTH_SHORT).show()
            }
            CardAction(Icons.Rounded.AspectRatio, Neon.Muted, onReels)
            CardAction(Icons.Rounded.DeleteOutline, Neon.Muted, onDelete)
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, end = 8.dp, bottom = 8.dp)
                .height(34.dp)
                .clip(RoundedCornerShape(12.dp))
                .then(
                    if (posted) Modifier.border(1.dp, Neon.Green.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                    else Modifier.background(Neon.Gradient)
                )
                .clickable(onClick = onShare),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.RocketLaunch, null, tint = if (posted) Neon.Green else Color.White, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                if (posted) "Dobara upload" else "UPLOAD",
                color = if (posted) Neon.Green else Color.White,
                fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
private fun CardAction(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp)) }
}

@Composable
fun NextUploadCard(file: File?, pending: Int, folderName: String, onUpload: (File) -> Unit) {
    val context = LocalContext.current
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Neon.Violet.copy(alpha = 0.35f), Neon.Pink.copy(alpha = 0.18f))))
            .border(1.dp, Neon.Pink.copy(alpha = 0.6f), shape)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (file == null) {
            Text("🎉", fontSize = 28.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (folderName.isEmpty()) "Sab upload ho chuki!" else "$folderName ki sab upload ho chuki!",
                    color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp
                )
                Text("Nayi videos aate hi yahan agli dikhegi", color = Neon.Muted, fontSize = 11.sp)
            }
            return@Row
        }
        val thumb by produceState<ImageBitmap?>(null, file.absolutePath) {
            value = withContext(Dispatchers.IO) { Thumbs.get(file)?.asImageBitmap() }
        }
        val title = remember(file.absolutePath) { Titles.get(context, file) }
        Box(
            Modifier.size(width = 52.dp, height = 68.dp).clip(RoundedCornerShape(10.dp)).background(Neon.Bg1),
            contentAlignment = Alignment.Center
        ) {
            thumb?.let { Image(it, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                ?: Text("🎬", fontSize = 20.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                if (folderName.isEmpty()) "🚀 AGLI UPLOAD  •  $pending baaqi" else "🚀 $folderName  •  $pending baaqi",
                color = Neon.Gold, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(title, color = Neon.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Neon.Gradient)
                .clickable { onUpload(file) }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) { Text("UPLOAD", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black) }
    }
}
