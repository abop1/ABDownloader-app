package com.mydownloader.app

import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** 🎬 Reels jaisa player: full screen, upar/neeche swipe = agli/pichli video */
@Composable
fun ReelsPlayer(
    files: List<File>,
    startIndex: Int,
    posted: Set<String>,
    onClose: () -> Unit,
    onUpload: (File) -> Unit,
    onTogglePosted: (File) -> Unit,
    onReels: (File) -> Unit,
    onDelete: (File) -> Unit
) {
    val context = LocalContext.current
    if (files.isEmpty()) { LaunchedEffect(Unit) { onClose() }; return }
    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, files.size - 1)) { files.size }
    BackHandler { onClose() }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) {
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize(), key = { files[it].absolutePath }) { page ->
            val f = files[page]
            val isPosted = f.absolutePath in posted
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (page == pager.currentPage) {
                    key(f.absolutePath) { VideoBox(f) }
                } else {
                    val thumb by produceState<ImageBitmap?>(null, f.absolutePath) {
                        value = withContext(Dispatchers.IO) { Thumbs.get(f)?.asImageBitmap() }
                    }
                    thumb?.let { Image(it, null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()) }
                }

                // neeche andhera + title
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.35f), Color.Transparent, Color.Transparent, Color.Black.copy(alpha = 0.8f)))
                    )
                )
                Column(
                    Modifier.align(Alignment.BottomStart).navigationBarsPadding()
                        .padding(start = 16.dp, end = 86.dp, bottom = 24.dp)
                ) {
                    if (isPosted) {
                        Text(
                            "✓ POSTED", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(Neon.Green)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                        Spacer(Modifier.height(6.dp))
                    }
                    Text(
                        Titles.get(context, f), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 3, overflow = TextOverflow.Ellipsis
                    )
                    Text("${page + 1} / ${files.size}  •  ${humanSize(f.length())}", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                }

                // Right side buttons (bilkul reels jaise)
                Column(
                    Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 12.dp, bottom = 30.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    SideAction(Icons.Rounded.RocketLaunch, "Upload", highlight = true) { onUpload(f) }
                    SideAction(Icons.Rounded.ContentCopy, "Title") {
                        copyText(context, Titles.get(context, f))
                        Toast.makeText(context, "📋 Title copy ho gaya", Toast.LENGTH_SHORT).show()
                    }
                    SideAction(if (isPosted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                        if (isPosted) "Posted" else "Post?") { onTogglePosted(f) }
                    SideAction(Icons.Rounded.AspectRatio, "Reels") { onReels(f) }
                    SideAction(Icons.Rounded.OpenInNew, "Kholein") { playFile(context, f) }
                    SideAction(Icons.Rounded.DeleteOutline, "Delete") { onDelete(f) }
                }
            }
        }

        // Upar: band karein
        Row(
            Modifier.align(Alignment.TopStart).statusBarsPadding().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.4f)).clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Close, "Band", tint = Color.White) }
            Spacer(Modifier.width(10.dp))
            Text("Reels", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun SideAction(icon: ImageVector, label: String, highlight: Boolean = false, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(
            Modifier.size(46.dp).clip(CircleShape)
                .background(if (highlight) Neon.Gradient else Brush.linearGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Black.copy(alpha = 0.45f)))),
            contentAlignment = Alignment.Center
        ) { Icon(icon, label, tint = Color.White, modifier = Modifier.size(24.dp)) }
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Ek video chalane wala dabba: tap = roko/chalao, khud repeat */
@Composable
private fun VideoBox(file: File) {
    var view by remember { mutableStateOf<VideoView?>(null) }
    var paused by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AndroidView(
            factory = { ctx ->
                VideoView(ctx).apply {
                    setVideoPath(file.absolutePath)
                    setOnPreparedListener { mp -> mp.isLooping = true; start() }
                    view = this
                }
            }
        )
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                view?.let { if (it.isPlaying) { it.pause(); paused = true } else { it.start(); paused = false } }
            },
            contentAlignment = Alignment.Center
        ) {
            if (paused) {
                Box(
                    Modifier.size(72.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(44.dp)) }
            }
        }
    }
    DisposableEffect(file.absolutePath) { onDispose { view?.stopPlayback() } }
}
