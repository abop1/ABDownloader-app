package com.mydownloader.app

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Har download hui video ka asal (poora) title yaad rakhta hai,
 * taake share karte waqt caption mein ja sake.
 */
object Titles {
    fun file(ctx: Context) = File(ctx.filesDir, "titles.jsonl")

    /** yt-dlp ko batata hai ke har video ke baad path + title is file mein likhe */
    fun command(ctx: Context): List<String> = listOf(
        "--print-to-file",
        "after_move:{\"p\":%(filepath)j,\"t\":%(title)j}",
        file(ctx).absolutePath
    )

    @Volatile private var cache: Map<String, String>? = null

    fun invalidate() { cache = null }

    @Synchronized
    fun all(ctx: Context): Map<String, String> {
        cache?.let { return it }
        val map = HashMap<String, String>()
        val f = file(ctx)
        if (f.exists()) {
            f.readLines().forEach { line ->
                try {
                    val o = JSONObject(line)
                    val t = o.optString("t")
                    if (t.isNotBlank()) map[File(o.getString("p")).nameWithoutExtension] = t
                } catch (e: Exception) { }
            }
        }
        cache = map
        return map
    }

    /** Split ke parts ka title bhi asal video wala */
    private fun stemOf(f: File) = f.nameWithoutExtension
        .replace(Regex(" \\[Reels\\]$"), "")
        .replace(Regex(" - Part \\d+$"), "")

    /** File ke naam se "[id]" hata kar saaf naam (purani videos ke liye) */
    private fun clean(stem: String) = stem.replace(Regex("\\s*\\[[^\\]]+\\]$"), "").trim()

    fun get(ctx: Context, f: File): String {
        val stem = stemOf(f)
        return all(ctx)[stem] ?: clean(stem)
    }
}
