package com.mydownloader.app

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Har download hui video ka asal (poora) title yaad rakhta hai,
 * taake share karte waqt caption mein ja sake.
 */
object Titles {
    fun file(ctx: Context) = File(ctx.filesDir, "titles.jsonl")

    /** yt-dlp ko batata hai ke har video ke baad path + title is file mein likhe */
    fun command(ctx: Context): List<String> = listOf(
        "--print-to-file",
        "after_move:{\"p\":%(filepath)j,\"t\":%(title)j}",
        file(ctx).absolutePath
    )

    @Volatile private var cache: Map<String, String>? = null

    fun invalidate() { cache = null; partTotals.clear() }

    @Synchronized
    fun all(ctx: Context): Map<String, String> {
        cache?.let { return it }
        val map = HashMap<String, String>()
        val f = file(ctx)
        if (f.exists()) {
            f.readLines().forEach { line ->
                try {
                    val o = JSONObject(line)
                    val t = o.optString("t")
                    if (t.isNotBlank()) map[File(o.getString("p")).nameWithoutExtension] = t
                } catch (e: Exception) { }
            }
        }
        cache = map
        return map
    }

    /** Split ke parts ka title bhi asal video wala */
    private fun stemOf(f: File) = f.nameWithoutExtension
        .replace(Regex(" \\[Reels\\]$"), "")
        .replace(Regex(" - Part \\d+$"), "")

    /** File ke naam se "[id]" hata kar saaf naam (purani videos ke liye) */
    private fun clean(stem: String) = stem.replace(Regex("\\s*\\[[^\\]]+\\]$"), "").trim()

    // Kisi video ke kul kitne parts hain (yaad rakhte hain taake bar bar folder na dekhna pare)
    private val partTotals = java.util.concurrent.ConcurrentHashMap<String, Int>()

    private fun totalParts(f: File, stem: String): Int {
        val dir = f.parentFile ?: return 0
        val key = dir.absolutePath + "/" + stem
        partTotals[key]?.let { return it }
        val prefix = "$stem - Part "
        val n = dir.listFiles()?.count { val nm = it.nameWithoutExtension
            nm.startsWith(prefix) && !nm.endsWith("[Reels]") } ?: 0
        partTotals[key] = n
        return n
    }

    /** Asal title + agar part hai to "Part 1/3" */
    fun get(ctx: Context, f: File): String {
        val stem = stemOf(f)
        val base = all(ctx)[stem] ?: clean(stem)
        val num = Regex(" - Part (\\d+)").find(f.nameWithoutExtension)?.groupValues?.get(1)?.toIntOrNull()
            ?: return base
        val total = totalParts(f, stem)
        return if (total > 1) "$base  (Part $num/$total)" else "$base  (Part $num)"
    }

    fun clearParts() = partTotals.clear()
}
