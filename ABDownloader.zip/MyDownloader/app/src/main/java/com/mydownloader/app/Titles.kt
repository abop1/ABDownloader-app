package com.mydownloader.app

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Har download hui video ka asal (poora) title yaad rakhta hai,
 * taake share karte waqt caption mein ja sake.
 */
object Titles {
    fun file(ctx: Context) = File(ctx.filesDir, "titles.jsonl")

    /** yt-dlp ko batata hai ke har video ke baad path + title is file mein likhe */
    fun command(ctx: Context): List<String> = listOf(
        "--print-to-file",
        "after_move:{\"p\":%(filepath)j,\"t\":%(title)j}",
        file(ctx).absolutePath,
        // Asal caption (Instagram/Facebook/TikTok ka poora text) alag line mein
        "--print-to-file",
        "after_move:{\"p\":%(filepath)j,\"e\":%(extractor_key)j,\"d\":%(description)j}",
        file(ctx).absolutePath
    )

    @Volatile private var cache: Map<String, String>? = null
    private val descs = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val sites = java.util.concurrent.ConcurrentHashMap<String, String>()

    /** Caption ke aakhir mein "(Part 1/3)" lagana hai ya nahi */
    var partTag: Boolean = true
    fun loadPrefs(ctx: Context) {
        partTag = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("partTag", true)
    }
    fun setPartTag(ctx: Context, on: Boolean) {
        partTag = on
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putBoolean("partTag", on).apply()
    }

    fun invalidate() { cache = null; partTotals.clear(); descs.clear(); sites.clear() }

    @Synchronized
    fun all(ctx: Context): Map<String, String> {
        cache?.let { return it }
        val map = HashMap<String, String>()
        val f = file(ctx)
        if (f.exists()) {
            f.readLines().forEach { line ->
                try {
                    val o = JSONObject(line)
                    val key = File(o.getString("p")).nameWithoutExtension
                    val t = o.optString("t")
                    val d = if (o.isNull("d")) "" else o.optString("d")
                    if (t.isNotBlank()) map[key] = t
                    if (d.isNotBlank() && d != "NA") descs[key] = d
                    val e = if (o.isNull("e")) "" else o.optString("e")
                    if (e.isNotBlank()) sites[key] = e.lowercase()
                } catch (e: Exception) { }
            }
        }
        cache = map
        return map
    }

    /** Split ke parts ka title bhi asal video wala */
    private fun stemOf(f: File) = f.nameWithoutExtension
        .replace(Regex(" \\[Reels\\]$"), "")
        .replace(Regex(" - Part \\d+$"), "")

    /** File ke naam se "[id]" hata kar saaf naam (purani videos ke liye) */
    private fun clean(stem: String) = stem.replace(Regex("\\s*\\[[^\\]]+\\]$"), "").trim()

    // Kisi video ke kul kitne parts hain (yaad rakhte hain taake bar bar folder na dekhna pare)
    private val partTotals = java.util.concurrent.ConcurrentHashMap<String, Int>()

    private fun totalParts(f: File, stem: String): Int {
        val dir = f.parentFile ?: return 0
        val key = dir.absolutePath + "/" + stem
        partTotals[key]?.let { return it }
        val prefix = "$stem - Part "
        val n = dir.listFiles()?.count { val nm = it.nameWithoutExtension
            nm.startsWith(prefix) && !nm.endsWith("[Reels]") } ?: 0
        partTotals[key] = n
        return n
    }

    /** Asal title + agar part hai to "Part 1/3" */
    fun get(ctx: Context, f: File): String {
        val stem = stemOf(f)
        val title = all(ctx)[stem]
        val desc = descs[stem] ?: ""
        val site = sites[stem] ?: ""
        val social = listOf("tiktok", "instagram", "facebook", "twitter", "x").any { site.startsWith(it) }
        val base = when {
            // TikTok / Instagram / Facebook / X: bilkul wahi caption jo post par likha hai (hashtags samait)
            social && desc.isNotBlank() -> desc.trim().take(2200)
            title == null -> if (desc.isNotBlank()) desc.trim().take(2200) else clean(stem)
            desc.isBlank() -> title
            title.startsWith("Video by", true) || title.startsWith("Instagram", true) ||
                title.startsWith("Facebook", true) || title.length < 4 -> desc.trim().take(2200)
            desc.length > title.length &&
                desc.startsWith(title.removeSuffix("...").removeSuffix("…").take(25)) -> desc.trim().take(2200)
            else -> title
        }
        if (!partTag) return base
        val num = Regex(" - Part (\\d+)").find(f.nameWithoutExtension)?.groupValues?.get(1)?.toIntOrNull()
            ?: return base
        val total = totalParts(f, stem)
        // Part number caption ke shuru mein: "Part 1", "Part 2"...
        return "Part $num\n$base"
    }

    fun clearParts() = partTotals.clear()
}
