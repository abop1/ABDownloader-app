package com.mydownloader.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(onLogin: () -> Unit, onCheckUpdate: () -> Unit, onToast: (String) -> Unit, onAbout: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val running = Jobs.running

    var perCreator by Jobs::perCreator
    var quality by Jobs::quality
    var parallel by Jobs::parallel
    var random by Jobs::random
    var cleanOld by Jobs::cleanOld
    var wifiOnly by Jobs::wifiOnly
    var autoOn by Jobs::autoOn
    var lockOn by remember { mutableStateOf(AppLock.enabled(context)) }
    var engineMsg by remember { mutableStateOf("") }
    var updating by remember { mutableStateOf(false) }

    fun save() = Jobs.saveSettings(context)

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) onToast(if (Backup.writeTo(context, uri)) "✓ Backup save ho gaya" else "Backup save nahi hua")
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val n = Backup.restoreFrom(context, uri)
            onToast(if (n < 0) "Ye sahi backup file nahi hai" else "✓ Backup wapas aa gaya ($n naye creators)")
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Settings", "Apni app apne andaaz mein")

        // ---------- Theme ----------
        SectionLabel("VIP Theme")
        NeonCard {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Themes.all.forEach { t ->
                    val sel = Themes.current.id == t.id
                    Column(
                        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                            .clickable { Themes.set(context, t) }
                            .padding(4.dp)
                    ) {
                        Box(
                            Modifier
                                .size(46.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(
                                    androidx.compose.ui.graphics.Brush.linearGradient(listOf(t.c1, t.c2, t.c3))
                                )
                                .border(
                                    if (sel) 3.dp else 0.dp,
                                    if (sel) androidx.compose.ui.graphics.Color.White else androidx.compose.ui.graphics.Color.Transparent,
                                    androidx.compose.foundation.shape.CircleShape
                                ),
                            contentAlignment = androidx.compose.ui.Alignment.Center
                        ) { if (sel) Text("✓", color = androidx.compose.ui.graphics.Color.White, fontSize = 18.sp) }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            t.name.substringBefore(" "),
                            color = if (sel) Neon.Text else Neon.Muted, fontSize = 10.sp, maxLines = 1
                        )
                    }
                }
            }
        }

        // ---------- Download ----------
        SectionLabel("Download")
        NeonCard {
            Text("🎬  Har creator se kitni nayi videos", color = Neon.Text, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(1, 3, 5, 10).forEach { n ->
                    QualityChip("$n", perCreator == n, Modifier.weight(1f)) { if (!running) { perCreator = n; save() } }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("🎞  Quality", color = Neon.Text, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                qualities.forEach { q ->
                    QualityChip(q, quality == q, Modifier.weight(1f)) { if (!running) { quality = q; save() } }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("⚡  Ek saath kitne creators", color = Neon.Text, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(1, 2, 3, 4, 5).forEach { n ->
                    QualityChip("$n", parallel == n, Modifier.weight(1f)) { if (!running) { parallel = n; save() } }
                }
            }
            Spacer(Modifier.height(8.dp))
            SettingRow(Icons.Rounded.Shuffle, "Random videos", "Poore account mein se random (off = nayi pehle)") {
                NeonSwitch(random) { if (!running) { random = it; save() } }
            }
            SettingRow(Icons.Rounded.CleaningServices, "Purani videos hatao", "Nayi aate hi us creator ki purani delete") {
                NeonSwitch(cleanOld) { if (!running) { cleanOld = it; save() } }
            }
        }

        // ---------- Automation ----------
        SectionLabel("Automation")
        NeonCard {
            SettingRow(
                Icons.Rounded.Schedule, "Roz automatic download",
                if (autoOn) "Har roz ${AutoScheduler.label(Jobs.autoHour, Jobs.autoMinute)} par" else "Band hai"
            ) {
                NeonSwitch(autoOn) { on ->
                    autoOn = on; save(); AutoScheduler.apply(context)
                    if (on && !AutoScheduler.canExact(context) && android.os.Build.VERSION.SDK_INT >= 31) {
                        try {
                            context.startActivity(
                                android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                    .setData(android.net.Uri.parse("package:" + context.packageName))
                            )
                        } catch (e: Exception) { }
                    }
                }
            }
            if (autoOn) {
                SettingRow(Icons.Rounded.AccessTime, "Waqt badlein", AutoScheduler.label(Jobs.autoHour, Jobs.autoMinute), onClick = {
                    android.app.TimePickerDialog(context, { _, h, m ->
                        Jobs.autoHour = h; Jobs.autoMinute = m; save(); AutoScheduler.apply(context)
                    }, Jobs.autoHour, Jobs.autoMinute, false).show()
                }) { Icon(Icons.Rounded.ChevronRight, null, tint = Neon.Muted) }
            }
            SettingRow(Icons.Rounded.Wifi, "Sirf Wi-Fi par", "Mobile data par download nahi") {
                NeonSwitch(wifiOnly) { wifiOnly = it; save() }
            }
            SettingRow(Icons.Rounded.Storage, "Storage ki hifazat", "1 GB se kam jagah par ruk jata hai  •  Khali: ${humanSize(Guards.freeBytes())}")
        }

        // ---------- Security ----------
        // ---------- Caption ----------
        SectionLabel("Caption")
        NeonCard {
            var partTag by remember { mutableStateOf(Titles.partTag) }
            SettingRow(Icons.Rounded.Notes, "Asal caption", "TikTok/Instagram ka caption bilkul wahi, hashtags samait")
            SettingRow(Icons.Rounded.FormatListNumbered, "Caption mein Part number", "Split videos ke shuru mein: Part 1, Part 2...") {
                NeonSwitch(partTag) { partTag = it; Titles.setPartTag(context, it); Titles.invalidate() }
            }
        }

        // ---------- Watermark ----------
        SectionLabel("Watermark")
        NeonCard {
            SettingRow(Icons.Rounded.WaterDrop, "Apna watermark", if (Watermark.on) "\"${Watermark.text}\" videos par" else "Band hai") {
                NeonSwitch(Watermark.on) { Watermark.on = it; Watermark.save(context) }
            }
            if (Watermark.on) {
                Spacer(Modifier.height(6.dp))
                NeonField(Watermark.text, { Watermark.text = it.take(30); Watermark.save(context) }, "Watermark text (jaise AB)")
                Spacer(Modifier.height(10.dp))
                Text("Jagah", color = Neon.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("TL" to "↖ Upar", "TR" to "Upar ↗", "BL" to "↙ Neeche", "BR" to "Neeche ↘").forEach { (k, l) ->
                        QualityChip(l, Watermark.pos == k, Modifier.weight(1f)) { Watermark.pos = k; Watermark.save(context) }
                    }
                }
                Spacer(Modifier.height(6.dp))
                SettingRow(Icons.Rounded.AutoMode, "Har nayi download par khud", "Thora waqt lagega (video dobara banti hai)") {
                    NeonSwitch(Watermark.auto) { Watermark.auto = it; Watermark.save(context) }
                }
                Text(
                    "Reels (9:16) banate waqt watermark hamesha khud lagta hai. Gallery mein videos chun kar 💧 se bhi laga sakte hain.",
                    color = Neon.Muted, fontSize = 11.sp
                )
            }
        }

        SectionLabel("Security")
        NeonCard {
            SettingRow(Icons.Rounded.Fingerprint, "App lock", if (lockOn) "Fingerprint / PIN se khulegi" else "Band hai") {
                NeonSwitch(lockOn) { on ->
                    val act = context as? FragmentActivity
                    when {
                        act == null -> {}
                        on && !AppLock.available(context) ->
                            onToast("Pehle phone mein fingerprint ya screen lock set karein")
                        else -> AppLock.prompt(act, if (on) "App lock on karein" else "App lock band karein", onOk = {
                            AppLock.setEnabled(context, on); lockOn = on
                            onToast(if (on) "🔒 App lock on ho gaya" else "App lock band")
                        })
                    }
                }
            }
        }

        // ---------- Backup ----------
        SectionLabel("Backup")
        NeonCard {
            Text(
                "Creators, settings aur history ki copy khud banti rehti hai: Download/ABDownloader/backup",
                color = Neon.Muted, fontSize = 12.sp
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonOutlineButton("💾 Save", Modifier.weight(1f)) { exportLauncher.launch("AB_backup.json") }
                NeonOutlineButton("📥 Wapas laayein", Modifier.weight(1f)) {
                    importLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*"))
                }
            }
        }

        // ---------- Accounts ----------
        SectionLabel("Accounts")
        NeonCard {
            SettingRow(
                Icons.Rounded.Key, "Login (Instagram, TikTok, FB, X)",
                LoginStatus.connectedNames().let { n ->
                    if (n.isNotEmpty()) "✅ Connected: ${n.joinToString(", ")}" else "Koi account connect nahi"
                }, onClick = onLogin
            ) { Icon(Icons.Rounded.ChevronRight, null, tint = Neon.Muted) }
        }

        // ---------- App ----------
        SectionLabel("App")
        NeonCard {
            SettingRow(Icons.Rounded.SystemUpdate, "Update check", "Version v${Updater.currentVersion(context)}", onClick = onCheckUpdate) {
                Icon(Icons.Rounded.ChevronRight, null, tint = Neon.Muted)
            }
            SettingRow(
                Icons.Rounded.Build, "Download engine update",
                if (updating) "Update ho raha hai..." else engineMsg.ifEmpty { "Kisi site par masla ho to dabayein" },
                onClick = {
                    if (!updating) {
                        updating = true
                        scope.launch {
                            engineMsg = withContext(Dispatchers.IO) { Engine.update(context) }
                            updating = false
                        }
                    }
                }
            ) { Icon(Icons.Rounded.ChevronRight, null, tint = Neon.Muted) }
        }

        NeonCard {
            SettingRow(Icons.Rounded.Info, "About AB Downloader", "Version, help aur tour", onClick = onAbout) {
                Icon(Icons.Rounded.ChevronRight, null, tint = Neon.Muted)
            }
        }

        Spacer(Modifier.height(10.dp))
    }
}
