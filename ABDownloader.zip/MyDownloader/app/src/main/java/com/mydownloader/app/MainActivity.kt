package com.mydownloader.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** App bhar ki navigation (notification se bhi badli ja sake) */
object NavState {
    var tab by mutableIntStateOf(0)
    var pendingUpload by mutableStateOf<String?>(null)
    var showTour by mutableStateOf(false)
    var showWhatsNew by mutableStateOf(false)
    var showAbout by mutableStateOf(false)
}

class MainActivity : FragmentActivity() {

    private val sharedLink = mutableStateOf("")
    val locked = mutableStateOf(false)
    private val showSplash = mutableStateOf(false)
    private var hiddenAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)

        Jobs.init(applicationContext)
        Themes.load(this)
        locked.value = AppLock.enabled(this)
        showSplash.value = savedInstanceState == null   // sirf app khulte waqt

        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            perms += Manifest.permission.POST_NOTIFICATIONS
            perms += Manifest.permission.READ_MEDIA_VIDEO
            perms += Manifest.permission.READ_MEDIA_AUDIO
        } else {
            perms += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
        requestPermissions(perms.toTypedArray(), 1)

        sharedLink.value = extractLink(intent)
        handleNotificationIntent(intent)

        // Pehli dafa: tour. Update ke baad: "Kya naya hai"
        if (!Intro.onboarded(this)) NavState.showTour = true
        else if (Intro.shouldShowWhatsNew(this)) NavState.showWhatsNew = true
        else if (Intro.lastSeen(this) == 0L) Intro.markSeen(this)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Neon.Purple, surface = Neon.Card)) {
                Box(Modifier.fillMaxSize()) {
                    AppRoot(sharedLink.value)

                    // 🎬 Reels player (Gallery se)
                    Overlay.player?.let { (list, start) ->
                        val ctx = LocalContext.current
                        val postedSet = remember(Overlay.changes) { Posted.all(ctx) }
                        ReelsPlayer(
                            files = list, startIndex = start, posted = postedSet,
                            onClose = { Overlay.player = null; Overlay.changes++ },
                            onUpload = { f -> uploadFile(ctx, f); Overlay.changes++ },
                            onTogglePosted = { f -> Posted.toggle(ctx, f); Overlay.changes++ },
                            onReels = { f -> requestReels(ctx, f) },
                            onDelete = { f ->
                                if (f.delete()) {
                                    Posted.forget(ctx, f)
                                    val rest = list.filterNot { it.absolutePath == f.absolutePath }
                                    Overlay.player = if (rest.isEmpty()) null
                                    else rest to list.indexOf(f).coerceAtMost(rest.size - 1)
                                    Overlay.changes++
                                }
                            }
                        )
                    }

                    if (NavState.showAbout) AboutScreen(
                        onClose = { NavState.showAbout = false },
                        onTour = { NavState.showAbout = false; NavState.showTour = true },
                        onWhatsNew = { NavState.showWhatsNew = true }
                    )
                    if (NavState.showWhatsNew && !showSplash.value && !NavState.showTour) {
                        WhatsNewDialog { NavState.showWhatsNew = false; Intro.markSeen(this@MainActivity) }
                    }
                    if (NavState.showTour && !showSplash.value) WelcomeTour {
                        NavState.showTour = false
                        Intro.setOnboarded(this@MainActivity, true)
                        Intro.markSeen(this@MainActivity)
                    }
                    if (locked.value && !showSplash.value) LockScreen { unlock() }
                    if (showSplash.value) AbSplash { showSplash.value = false }

                    // Notification ka "🚀 Upload" (lock khulne ke baad)
                    val ctx = LocalContext.current
                    LaunchedEffect(NavState.pendingUpload, locked.value, showSplash.value) {
                        val path = NavState.pendingUpload
                        if (path != null && !locked.value && !showSplash.value) {
                            NavState.pendingUpload = null
                            NavState.tab = 2
                            val f = java.io.File(path)
                            if (f.exists()) uploadFile(ctx, f)
                        }
                    }
                }
            }
        }
    }

    fun unlock() {
        AppLock.prompt(this, "AB Downloader kholein", onOk = { locked.value = false })
    }

    override fun onStop() {
        super.onStop()
        hiddenAt = SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        // 30 second se zyada bahar rahe to dobara lock
        if (AppLock.enabled(this) && hiddenAt > 0 && SystemClock.elapsedRealtime() - hiddenAt > 30_000) {
            locked.value = true
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        sharedLink.value = extractLink(intent)
        handleNotificationIntent(intent)
    }

    private fun handleNotificationIntent(i: Intent?) {
        i?.getStringExtra("upload_path")?.let { NavState.pendingUpload = it }
        val t = i?.getIntExtra("open_tab", -1) ?: -1
        if (t >= 0) NavState.tab = t
    }

    private fun extractLink(intent: Intent?): String {
        if (intent?.action != Intent.ACTION_SEND) return ""
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return ""
        return Regex("https?://\\S+").find(text)?.value ?: text
    }
}

// ===== Lock screen =====
@Composable
fun LockScreen(onUnlock: () -> Unit) {
    val glow = rememberInfiniteTransition(label = "lock")
    val pulse by glow.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "p")
    LaunchedEffect(Unit) { onUnlock() }
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Neon.Bg1, Neon.Bg2, Neon.Bg1)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(R.drawable.ic_launcher), null,
            modifier = Modifier.size(120.dp).scale(pulse)
        )
        Spacer(Modifier.height(20.dp))
        Text(
            stringResource(R.string.app_name),
            style = TextStyle(brush = Neon.Gradient, fontSize = 30.sp, fontWeight = FontWeight.Black)
        )
        Text("🔒 VIP lock laga hua hai", color = Neon.Muted, fontSize = 14.sp)
        Spacer(Modifier.height(36.dp))
        Box(Modifier.padding(horizontal = 48.dp)) {
            GlowButton("👆  UNLOCK KAREIN", onClick = onUnlock)
        }
    }
}

// ===== Root =====
@Composable
fun AppRoot(sharedLink: String) {
    val context = LocalContext.current
    var tab by NavState::tab
    var showLogin by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    var checkNow by remember { mutableIntStateOf(0) }

    LaunchedEffect(sharedLink) { if (sharedLink.isNotBlank()) tab = 0 }
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { Engine.autoUpdateIfNeeded(context) } }
    LaunchedEffect(checkNow) {
        val info = withContext(Dispatchers.IO) { try { Updater.check(context) } catch (e: Exception) { null } }
        update = info
        if (checkNow > 0 && info == null) toast = "Aap latest version par hain ✓"
    }
    LaunchedEffect(toast) {
        if (toast.isNotEmpty()) { kotlinx.coroutines.delay(3000); toast = "" }
    }
    BackHandler(enabled = showLogin) { showLogin = false }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Neon.Bg1, Neon.Bg2)))
        ) {
            Box(Modifier.weight(1f)) {
                TabPage(visible = tab == 0) { HomeScreen(sharedLink) }
                TabPage(visible = tab == 1) { CreatorsScreen() }
                TabPage(visible = tab == 2) { GalleryScreen(visible = tab == 2) }
                TabPage(visible = tab == 3) { StatsScreen(visible = tab == 3) }
                TabPage(visible = tab == 4) {
                    SettingsScreen(
                        onLogin = { showLogin = true },
                        onCheckUpdate = { checkNow++ },
                        onToast = { toast = it },
                        onAbout = { NavState.showAbout = true }
                    )
                }
            }
            VipBottomBar(tab) { tab = it }
        }

        update?.let { u ->
            AlertDialog(
                onDismissRequest = { update = null },
                containerColor = Neon.Card,
                title = { Text("🎉 Naya update: v${u.version}", color = Neon.Text, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "AB Downloader ka naya version aa gaya hai. Download karke install karein, aap ka data salamat rahega.",
                        color = Neon.Muted, fontSize = 13.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = { Updater.openDownload(context, u); update = null }) {
                        Text("Update karein", color = Neon.Purple, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = { TextButton(onClick = { update = null }) { Text("Baad mein", color = Neon.Muted) } }
            )
        }

        if (showLogin) {
            LoginScreen { msg -> showLogin = false; toast = msg }
        }

        if (toast.isNotEmpty()) {
            Text(
                toast,
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Neon.Gradient)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
fun TabPage(visible: Boolean, content: @Composable () -> Unit) {
    // Narmi se aana jana (fade + halka slide)
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(260), label = "tab")
    Box(
        Modifier
            .fillMaxSize()
            .offset { if (visible || a > 0.02f) IntOffset.Zero else IntOffset(100_000, 0) }
            .graphicsLayer {
                alpha = a
                translationY = (1f - a) * 24.dp.toPx()
            }
    ) { content() }
}

// ===== Download (Home) =====
@Composable
fun HomeScreen(initialLink: String) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val appName = stringResource(R.string.app_name)
    val owner = stringResource(R.string.owner_name)

    var link by remember(initialLink) { mutableStateOf(initialLink) }
    var quality by remember { mutableStateOf("Best") }
    val status = Jobs.singleStatus
    val progress = Jobs.singleProgress
    val busy = Jobs.singleBusy

    val glow = rememberInfiniteTransition(label = "glow")
    val glowAlpha by glow.animateFloat(0.35f, 1f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "g")
    val animatedProgress by animateFloatAsState(progress, label = "progress")

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(46.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(appName, style = TextStyle(brush = Neon.Gradient, fontSize = 24.sp, fontWeight = FontWeight.Black))
                Text("$owner Turbo Engine  •  1000+ sites", color = Neon.Muted, fontSize = 12.sp)
            }
            Text(
                "👑 VIP", color = Neon.Gold, fontSize = 12.sp, fontWeight = FontWeight.Black,
                modifier = Modifier
                    .border(1.dp, Neon.Gold.copy(alpha = glowAlpha), RoundedCornerShape(50))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            )
        }

        // Hero card
        NeonCard {
            Text("Video link paste karein", color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("YouTube, TikTok, Instagram, Facebook, X...", color = Neon.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            NeonField(link, { link = it }, "https://...")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonOutlineButton("📋  Paste", Modifier.weight(1f)) {
                    clipboard.getText()?.text?.let { link = it.trim() }
                }
                NeonOutlineButton("✕  Clear", Modifier.weight(1f)) { link = "" }
            }
            Spacer(Modifier.height(14.dp))
            Text("Quality", color = Neon.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                qualities.forEach { q -> QualityChip(q, quality == q, Modifier.weight(1f)) { quality = q } }
            }
            Spacer(Modifier.height(16.dp))
            GlowButton(
                if (busy) "DOWNLOADING..." else "⚡  DOWNLOAD",
                enabled = !busy && link.isNotBlank(),
                modifier = if (busy) Modifier.alpha(glowAlpha) else Modifier
            ) {
                val folder = Engine.publicFolder("Download", appName.replace(" ", ""))
                Jobs.startSingle(context, link.trim(), quality, folder)
            }
        }

        // Progress
        NeonCard {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    "${(animatedProgress * 100).toInt()}%",
                    style = TextStyle(brush = Neon.Gradient, fontSize = 38.sp, fontWeight = FontWeight.Black)
                )
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text("⚡ ${Jobs.singleSpeed}", color = Neon.Text, fontSize = 13.sp)
                    Text("⏱ ${Jobs.singleEta}", color = Neon.Muted, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            NeonProgressBar(animatedProgress, 10)
            Spacer(Modifier.height(10.dp))
            Text(status, color = Neon.Muted, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }

        Text(
            "Made with 💜 by $owner",
            color = Neon.Muted, fontSize = 11.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp)
        )
    }
}
