package com.mydownloader.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ===== VIP Neon colors =====
object Neon {
    val Bg1 = Color(0xFF07030F)
    val Bg2 = Color(0xFF160A2B)
    val Card = Color(0xFF1A1030)
    val Violet = Color(0xFF7B2FF7)
    val Purple = Color(0xFFB026FF)
    val Pink = Color(0xFFFF2BD6)
    val Text = Color(0xFFF3E9FF)
    val Muted = Color(0xFFA894C7)
    val Gradient = Brush.horizontalGradient(listOf(Violet, Purple, Pink))
}

class MainActivity : ComponentActivity() {

    private val sharedLink = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)

        try {
            YoutubeDL.getInstance().init(this)
            FFmpeg.getInstance().init(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        Jobs.init(applicationContext)

        // Zaroori ijazatein: notification (background progress) + videos parhna (gallery)
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            perms += Manifest.permission.POST_NOTIFICATIONS
            perms += Manifest.permission.READ_MEDIA_VIDEO
            perms += Manifest.permission.READ_MEDIA_AUDIO
        } else {
            perms += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
        requestPermissions(perms.toTypedArray(), 1)

        sharedLink.value = extractLink(intent)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Neon.Purple)) {
                AppRoot(sharedLink.value)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        sharedLink.value = extractLink(intent)
    }

    private fun extractLink(intent: Intent?): String {
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT) ?: return ""
        return Regex("https?://\\S+").find(text)?.value ?: text
    }
}

val qualities = listOf("Best", "1080p", "720p", "480p", "MP3")

// ===== Root: Tabs + Login =====
@Composable
fun AppRoot(sharedLink: String) {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var showLogin by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    var checkNow by remember { mutableIntStateOf(0) }

    LaunchedEffect(sharedLink) { if (sharedLink.isNotBlank()) tab = 0 }
    // Engine roz khud update ho
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { Engine.autoUpdateIfNeeded(context) } }
    // App ka naya version check (khulte waqt, aur "Update check" dabane par)
    LaunchedEffect(checkNow) {
        val info = withContext(Dispatchers.IO) { try { Updater.check(context) } catch (e: Exception) { null } }
        update = info
        if (checkNow > 0 && info == null) toast = "Aap latest version par hain ✓"
    }
    LaunchedEffect(toast) {
        if (toast.isNotEmpty()) { kotlinx.coroutines.delay(3000); toast = "" }
    }
    BackHandler(enabled = showLogin) { showLogin = false }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Neon.Bg1, Neon.Bg2)))
        ) {
            Box(Modifier.weight(1f)) {
                // Dono screens zinda rehti hain, taake tab badalne se download na ruke
                TabPage(visible = tab == 0) {
                    VipScreen(sharedLink, onLogin = { showLogin = true }, onCheckUpdate = { checkNow++ })
                }
                TabPage(visible = tab == 1) { CreatorsScreen() }
                TabPage(visible = tab == 2) { GalleryScreen(visible = tab == 2) }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Neon.Card)
                    .navigationBarsPadding()
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TabButton("⬇ Download", tab == 0, Modifier.weight(1f)) { tab = 0 }
                TabButton("👥 Creators", tab == 1, Modifier.weight(1f)) { tab = 1 }
                TabButton("🎬 Gallery", tab == 2, Modifier.weight(1f)) { tab = 2 }
            }
        }

        update?.let { u ->
            AlertDialog(
                onDismissRequest = { update = null },
                containerColor = Neon.Card,
                title = { Text("🎉 Naya update: v${u.version}", color = Neon.Text, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "AB Downloader ka naya version aa gaya hai. Download karke install karein, aap ka data salamat rahega.",
                        color = Neon.Muted, fontSize = 13.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = { Updater.openDownload(context, u); update = null }) {
                        Text("Update karein", color = Neon.Purple, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { update = null }) { Text("Baad mein", color = Neon.Muted) }
                }
            )
        }

        if (showLogin) {
            LoginScreen { msg -> showLogin = false; toast = msg }
        }

        if (toast.isNotEmpty()) {
            Text(
                toast,
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Neon.Gradient)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
fun TabPage(visible: Boolean, content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .offset { if (visible) IntOffset.Zero else IntOffset(100_000, 0) }
    ) { content() }
}

@Composable
fun TabButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .clip(shape)
            .then(if (selected) Modifier.background(Neon.Gradient) else Modifier)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color.White else Neon.Muted, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
    }
}

// ===== Download tab =====
@Composable
fun VipScreen(initialLink: String, onLogin: () -> Unit, onCheckUpdate: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val appName = stringResource(R.string.app_name)
    val owner = stringResource(R.string.owner_name)

    var link by remember(initialLink) { mutableStateOf(initialLink) }
    var quality by remember { mutableStateOf("Best") }
    var status by Jobs::singleStatus
    val progress = Jobs.singleProgress
    val speed = Jobs.singleSpeed
    val eta = Jobs.singleEta
    val busy = Jobs.singleBusy
    var updating by remember { mutableStateOf(false) }

    val glow = rememberInfiniteTransition(label = "glow")
    val glowAlpha by glow.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "glowAlpha"
    )
    val animatedProgress by animateFloatAsState(progress, label = "progress")

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.ic_launcher),
                contentDescription = null,
                modifier = Modifier.size(40.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                "👑 $owner VIP",
                color = Neon.Pink, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .border(1.dp, Neon.Pink.copy(alpha = glowAlpha), RoundedCornerShape(50))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            )
            Spacer(Modifier.weight(1f))
            Text(
                if (Engine.hasLogin(context)) "🔑 Logged in" else "🔑 Login",
                color = Neon.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .border(1.dp, Neon.Purple.copy(alpha = 0.6f), RoundedCornerShape(50))
                    .clickable(onClick = onLogin)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
        Column {
            Text(appName, style = TextStyle(brush = Neon.Gradient, fontSize = 34.sp, fontWeight = FontWeight.Black))
            Text("$owner Turbo Engine  •  1000+ sites  •  HD", color = Neon.Muted, fontSize = 13.sp)
        }

        NeonCard {
            Text("Video link", color = Neon.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            NeonField(link, { link = it }, "https://...")
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonOutlineButton("📋  Paste", Modifier.weight(1f)) {
                    clipboard.getText()?.text?.let { link = it.trim() }
                }
                NeonOutlineButton("✕  Clear", Modifier.weight(1f)) { link = "" }
            }
        }

        Text("Quality", color = Neon.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            qualities.forEach { q -> QualityChip(q, quality == q, Modifier.weight(1f)) { quality = q } }
        }

        val enabled = !busy && !updating && link.isNotBlank()
        val btnShape = RoundedCornerShape(18.dp)
        Box(
            Modifier
                .fillMaxWidth()
                .height(58.dp)
                .shadow(if (enabled || busy) 20.dp else 0.dp, btnShape, ambientColor = Neon.Purple, spotColor = Neon.Pink)
                .clip(btnShape)
                .background(if (enabled || busy) Neon.Gradient else SolidColor(Neon.Card))
                .clickable(enabled = enabled) {
                    // Download Jobs mein chalta hai — app band ho to bhi jari rahega
                    val folder = Engine.publicFolder("Download", appName.replace(" ", ""))
                    Jobs.startSingle(context, link.trim(), quality, folder)
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (busy) "Downloading..." else "⚡  DOWNLOAD",
                color = if (enabled || busy) Color.White else Neon.Muted,
                fontWeight = FontWeight.Black, fontSize = 17.sp, letterSpacing = 1.sp,
                modifier = if (busy) Modifier.alpha(glowAlpha) else Modifier
            )
        }

        NeonCard {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    "${(animatedProgress * 100).toInt()}%",
                    style = TextStyle(brush = Neon.Gradient, fontSize = 40.sp, fontWeight = FontWeight.Black)
                )
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text("Speed  $speed", color = Neon.Text, fontSize = 13.sp)
                    Text("Time left  $eta", color = Neon.Muted, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            NeonProgressBar(animatedProgress, 10)
            Spacer(Modifier.height(10.dp))
            Text(status, color = Neon.Muted, fontSize = 12.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (updating) "↻  Updating..." else "↻  Engine update",
                color = Neon.Purple, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(enabled = !busy && !updating) {
                        updating = true
                        status = "Engine update ho raha hai..."
                        scope.launch {
                            status = withContext(Dispatchers.IO) { Engine.update(context) }
                            updating = false
                        }
                    }
                    .padding(8.dp)
            )
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "⟳ Update check  •  v${Updater.currentVersion(context)}",
                    color = Neon.Purple, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onCheckUpdate).padding(4.dp)
                )
                Text("Made with 💜 by $owner", color = Neon.Muted, fontSize = 11.sp)
            }
        }
    }
}

// ===== Shared neon components =====
@Composable
fun NeonCard(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Neon.Card)
            .border(1.dp, Brush.linearGradient(listOf(Neon.Violet.copy(alpha = 0.8f), Neon.Pink.copy(alpha = 0.25f))), shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun NeonProgressBar(value: Float, heightDp: Int) {
    Box(Modifier.fillMaxWidth().height(heightDp.dp).clip(RoundedCornerShape(50)).background(Neon.Bg1)) {
        Box(
            Modifier.fillMaxHeight().fillMaxWidth(value.coerceIn(0f, 1f))
                .clip(RoundedCornerShape(50)).background(Neon.Gradient)
        )
    }
}

@Composable
fun NeonOutlineButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .clip(shape)
            .border(1.dp, Neon.Purple.copy(alpha = 0.6f), shape)
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Neon.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun QualityChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .clip(shape)
            .then(
                if (selected) Modifier.background(Neon.Gradient)
                else Modifier.background(Neon.Card).border(1.dp, Neon.Violet.copy(alpha = 0.5f), shape)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, color = if (selected) Color.White else Neon.Muted,
            fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

@Composable
fun NeonField(value: String, onChange: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        placeholder = { Text(hint, color = Neon.Muted, fontSize = 14.sp) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Neon.Purple,
            unfocusedBorderColor = Neon.Violet.copy(alpha = 0.4f),
            focusedTextColor = Neon.Text,
            unfocusedTextColor = Neon.Text,
            cursorColor = Neon.Pink
        )
    )
}
