package com.mydownloader.app

import android.content.Context
import android.media.MediaMetadataRetriever
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 📐 Reels format: video ko 9:16 (720x1280) mein, khali jagah par usi video ka blur background.
 * Asal video salamat rehti hai, nayi file "[Reels]" naam se banti hai.
 */
object ReelsMaker {
    var busyFile by mutableStateOf<File?>(null)
    var progress by mutableFloatStateOf(0f)
    var doneCount by mutableIntStateOf(0)       // gallery ko taaza karne ke liye
    var lastMessage by mutableStateOf("")
    @Volatile private var proc: Process? = null
    @Volatile private var cancelled = false

    private const val W = 720
    private const val H = 1280

    /** Pehle se lambi (9:16 jaisi) video hai? */
    fun isVertical(f: File): Boolean = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        r.release()
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        w > 0 && h.toFloat() / w >= 1.7f
    } catch (e: Exception) { false }

    var batchIndex by mutableIntStateOf(0)
    var batchTotal by mutableIntStateOf(0)

    /** Kai videos ki reels, ek ke baad ek */
    fun startBatch(ctx: Context, inputs: List<File>) {
        if (busyFile != null || inputs.isEmpty()) return
        val app = ctx.applicationContext
        cancelled = false
        batchTotal = inputs.size
        Jobs.scope.launch {
            var ok = 0
            for ((i, f) in inputs.withIndex()) {
                if (cancelled) break
                batchIndex = i + 1
                busyFile = f
                progress = 0f
                if (withContext(Dispatchers.IO) { convert(app, f) } != null) ok++
            }
            lastMessage = if (cancelled) "Reels banana roka gaya ($ok bani)" else "📐 $ok reels tayyar"
            busyFile = null
            batchTotal = 0
            doneCount++
        }
    }

    fun start(ctx: Context, input: File) {
        if (busyFile != null) return
        batchTotal = 0
        val app = ctx.applicationContext
        busyFile = input
        progress = 0f
        cancelled = false
        Jobs.scope.launch {
            val out = withContext(Dispatchers.IO) { convert(app, input) }
            lastMessage = when {
                cancelled -> "Reels banana roka gaya"
                out != null -> "📐 Reels tayyar: ${out.name}"
                else -> "Reels nahi ban saki, dobara try karein"
            }
            busyFile = null
            doneCount++
        }
    }

    fun cancel() {
        cancelled = true
        proc?.destroy()
    }

    private fun duration(f: File): Double = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        ms / 1000.0
    } catch (e: Exception) { 0.0 }

    private fun convert(ctx: Context, input: File): File? {
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so")
        val pkgs = File(ctx.noBackupFilesDir, "youtubedl-android/packages")
        val ld = "${pkgs.absolutePath}/ffmpeg/usr/lib:${pkgs.absolutePath}/python/usr/lib"
        val dir = input.parentFile ?: return null
        val out = File(dir, "${input.nameWithoutExtension} [Reels].mp4")
        val total = duration(input)

        val filter =
            "[0:v]scale=$W:$H:force_original_aspect_ratio=increase,crop=$W:$H,boxblur=20:2[bg];" +
            "[0:v]scale=$W:$H:force_original_aspect_ratio=decrease[fg];" +
            "[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1,format=yuv420p[v]"

        // Pehle tez H.264, na chale to aam encoder
        val encoders = listOf(
            listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "23"),
            listOf("-c:v", "mpeg4", "-q:v", "3")
        )
        for (enc in encoders) {
            if (cancelled) return null
            out.delete()
            val cmd = mutableListOf(
                bin.absolutePath, "-hide_banner", "-y", "-i", input.absolutePath,
                "-filter_complex", filter, "-map", "[v]", "-map", "0:a?"
            )
            cmd += enc
            cmd += listOf("-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", out.absolutePath)
            try {
                val pb = ProcessBuilder(cmd).redirectErrorStream(true)
                pb.environment()["LD_LIBRARY_PATH"] = ld
                val p = pb.start()
                proc = p
                // ffmpeg progress "time=00:00:12.34" deta hai (\r ke saath)
                val reader = p.inputStream.bufferedReader()
                val sb = StringBuilder()
                while (true) {
                    val c = reader.read()
                    if (c == -1) break
                    if (c == '\r'.code || c == '\n'.code) {
                        val line = sb.toString(); sb.clear()
                        Regex("time=(\\d+):(\\d+):(\\d+\\.?\\d*)").find(line)?.let { m ->
                            val t = m.groupValues[1].toInt() * 3600 + m.groupValues[2].toInt() * 60 +
                                m.groupValues[3].toDouble()
                            if (total > 0) progress = (t / total).toFloat().coerceIn(0f, 1f)
                        }
                    } else sb.append(c.toChar())
                }
                val code = p.waitFor()
                proc = null
                if (code == 0 && out.exists() && out.length() > 0) {
                    progress = 1f
                    return out
                }
            } catch (e: Exception) {
                proc = null
            }
        }
        out.delete()
        return null
    }
}
