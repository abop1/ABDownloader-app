package com.mydownloader.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// ================= Data =================

data class Creator(
    val id: String,
    val name: String,
    val url: String,
    val base: String,      // "Download" ya "Documents"
    val folder: String,    // jaise "ABDownloader/MrBeast"
    val enabled: Boolean,  // false = stop (skip hoga)
    val split: Boolean = false, // true = download ke baad parts mein todo
    val splitSec: Int = 60      // har part kitne second ka
)

fun safeName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "Creator" }

fun defaultFolder(ctx: Context, name: String) =
    ctx.getString(R.string.app_name).replace(" ", "") + "/" + safeName(name)

object CreatorStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("creators", Context.MODE_PRIVATE)

    fun load(ctx: Context): List<Creator> = try {
        val arr = JSONArray(prefs(ctx).getString("list", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val name = o.getString("name")
            Creator(
                id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                name = name,
                url = o.getString("url"),
                base = o.optString("base").ifBlank { "Download" },
                folder = o.optString("folder").ifBlank { defaultFolder(ctx, name) },
                enabled = o.optBoolean("enabled", true),
                split = o.optBoolean("split", false),
                splitSec = o.optInt("splitSec", 60)
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(ctx: Context, list: List<Creator>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)
                    .put("base", it.base).put("folder", it.folder).put("enabled", it.enabled)
                    .put("split", it.split).put("splitSec", it.splitSec)
            )
        }
        prefs(ctx).edit().putString("list", arr.toString()).apply()
    }
}

// Ek dafa download hui videos ki history (dobara download nahi hongi)
fun archiveFile(ctx: Context) = File(ctx.filesDir, "downloaded_history.txt")

fun countLines(f: File): Int = if (f.exists()) f.readLines().count { it.isNotBlank() } else 0

fun normalizeCreatorUrl(url: String): String {
    val u = url.trim().trimEnd('/')
    val isYtChannel = u.contains("youtube.com/@") || u.contains("youtube.com/channel/") || u.contains("youtube.com/c/")
    val hasTab = listOf("/videos", "/shorts", "/streams", "/playlist").any { u.contains(it) }
    return if (isYtChannel && !hasTab) "$u/videos" else u
}

data class CreatorResult(val videos: Int, val parts: Int, val deleted: Int = 0)

private val oldMediaExt = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp", "mp3", "m4a", "opus", "aac", "wav")

/** Ek creator ki nayi videos (+ split agar on ho). Fail ho to engine update karke dobara try. */
fun downloadFromCreator(
    ctx: Context,
    creator: Creator,
    count: Int,
    random: Boolean,
    quality: String,
    processId: String,
    cleanOld: Boolean = false,
    onProgress: (Float, String) -> Unit
): CreatorResult {
    val folder = Engine.publicFolder(creator.base, creator.folder)
    folder.mkdirs()
    // Download se pehle jo videos folder mein thin (purani) — unki list
    val oldFiles = folder.listFiles()
        ?.filter { it.isFile && it.extension.lowercase() in oldMediaExt }
        ?: emptyList()
    val archive = archiveFile(ctx)
    // Nayi download hui files ke raaste yahan likhe jayenge
    val newFilesList = File(ctx.cacheDir, "new_$processId.txt")
    newFilesList.delete()

    fun attempt(pid: String): Pair<Int, String?> {
        val before = countLines(archive)
        val request = YoutubeDLRequest(normalizeCreatorUrl(creator.url)).apply {
            addOption("-o", folder.absolutePath + "/%(title).70s [%(id)s].%(ext)s")
            addOption("--download-archive", archive.absolutePath)
            addOption("--max-downloads", count.toString())
            addOption("-I", "1:30")
            if (random) addOption("--playlist-random")
            addOption("--ignore-errors")
            addOption("--no-simulate")
            addCommands(listOf("--print-to-file", "after_move:filepath", newFilesList.absolutePath))
            Engine.applyRobust(this, ctx)
            Engine.applyQuality(this, quality)
        }
        var error: String? = null
        try {
            YoutubeDL.getInstance().execute(request, pid, false) { p, _, line -> onProgress(p, line) }
        } catch (e: YoutubeDL.CanceledException) {
            throw e
        } catch (e: Exception) {
            error = e.message ?: "Unknown error"
        }
        val added = countLines(archive) - before
        val realError = if (error != null && !error.contains("Maximum number of downloads")) error else null
        return added to realError
    }

    var (added, error) = attempt(processId)
    if (added == 0 && error != null) {
        onProgress(-1f, "Masla aaya, engine update karke dobara try...")
        Engine.update(ctx)
        val second = attempt(processId + "_r")
        added = second.first
        error = second.second
    }
    if (added == 0 && error != null) throw Exception(error.take(200))

    // ---- Split ----
    var parts = 0
    if (creator.split && creator.splitSec > 0 && newFilesList.exists()) {
        val files = newFilesList.readLines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        files.forEachIndexed { i, path ->
            onProgress(-1f, "✂ Split ho rahi hai (${i + 1}/${files.size}): ${File(path).name}")
            parts += Splitter.split(ctx, File(path), creator.splitSec)
        }
    }
    newFilesList.delete()

    // ---- Purani videos delete (sirf tab jab nayi aa chuki hon) ----
    var deleted = 0
    if (cleanOld && added > 0) {
        oldFiles.forEach { if (it.exists() && it.delete()) deleted++ }
    }
    return CreatorResult(added, parts, deleted)
}

// ================= UI =================

@Composable
fun CreatorsScreen() {
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()

    // Sab data Jobs mein hai, taake app band hone par bhi download chalta rahe
    val creators = Jobs.creators
    val results = Jobs.results
    fun persist() = Jobs.saveCreators(context)

    // Search
    var query by remember { mutableStateOf("") }
    var online by remember { mutableStateOf<List<FoundCreator>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searchMsg by remember { mutableStateOf("") }

    // Add
    var newName by remember { mutableStateOf("") }
    var newUrl by remember { mutableStateOf("") }
    var addError by remember { mutableStateOf("") }

    // Settings + run state (Jobs se)
    var perCreator by Jobs::perCreator
    var random by Jobs::random
    var quality by Jobs::quality
    var cleanOld by Jobs::cleanOld
    val running = Jobs.running
    val currentId = Jobs.currentId
    val progress = Jobs.progress
    val status = Jobs.status
    val totalNew = Jobs.totalNew
    val historyCount = Jobs.historyCount

    var editing by remember { mutableStateOf<Creator?>(null) }
    var splitting by remember { mutableStateOf<Creator?>(null) }

    fun addCreator(name: String, url: String): String? {
        val u = url.trim()
        if (!u.startsWith("http")) return "Sahi link daalein (https:// se shuru)"
        if (creators.any { it.url.trimEnd('/') == u.trimEnd('/') }) return "Ye creator pehle se list mein hai"
        val n = name.trim().ifBlank { u.trimEnd('/').substringAfterLast("/").removePrefix("@").ifBlank { "Creator" } }
        val folder = defaultFolder(context, n)
        creators.add(Creator(UUID.randomUUID().toString(), n, u, "Download", folder, true))
        Engine.publicFolder("Download", folder).mkdirs() // creator ke naam ka folder foran ban jaye
        persist()
        return null
    }

    fun stopCurrentIf(id: String) = Jobs.stopCurrentIf(id)
    fun runQueue(ids: List<String>, manual: Boolean) = Jobs.runQueue(context, ids, manual)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column {
            Text("Creators", style = TextStyle(brush = Neon.Gradient, fontSize = 32.sp, fontWeight = FontWeight.Black))
            Text("Creators add karein, Start dabayein, nayi videos khud download hongi", color = Neon.Muted, fontSize = 13.sp)
        }

        // ---- Search ----
        NeonCard {
            Text("🔍  Search", color = Neon.Text, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            NeonField(query, { query = it; searchMsg = "" }, "Creator ka naam likhein")
            Spacer(Modifier.height(10.dp))
            NeonOutlineButton(
                if (searching) "Dhoond rahe hain..." else "🌐  YouTube par dhoondein",
                Modifier.fillMaxWidth()
            ) {
                if (searching) return@NeonOutlineButton
                if (query.isBlank()) { searchMsg = "Pehle naam likhein"; return@NeonOutlineButton }
                searching = true
                searchMsg = ""
                scope.launch {
                    val res = withContext(Dispatchers.IO) {
                        try { searchYouTubeCreators(query.trim()) } catch (e: Exception) { null }
                    }
                    searching = false
                    if (res == null) searchMsg = "Search nahi hua, internet check karein"
                    else { online = res; if (res.isEmpty()) searchMsg = "Koi creator nahi mila" }
                }
            }
            if (searchMsg.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(searchMsg, color = Neon.Pink, fontSize = 12.sp)
            }
            online.forEach { f ->
                val added = creators.any { it.url.trimEnd('/') == f.url.trimEnd('/') }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(f.name, 34)
                    Spacer(Modifier.width(10.dp))
                    Text(f.name, color = Neon.Text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    SmallPill(if (added) "✓ Added" else "＋ Add", filled = !added) {
                        if (!added) addCreator(f.name, f.url)
                    }
                }
            }
            if (online.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("Saaf karein", color = Neon.Muted, fontSize = 12.sp,
                    modifier = Modifier.clickable { online = emptyList() }.padding(4.dp))
            }
        }

        // ---- Add manually ----
        NeonCard {
            Text("Naya creator (link se)", color = Neon.Text, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            NeonField(newName, { newName = it; addError = "" }, "Naam (jaise MrBeast)")
            Spacer(Modifier.height(8.dp))
            NeonField(newUrl, { newUrl = it; addError = "" }, "Channel / profile link")
            if (addError.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(addError, color = Neon.Pink, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            NeonOutlineButton("＋  Creator add karein", Modifier.fillMaxWidth()) {
                val err = addCreator(newName, newUrl)
                if (err != null) addError = err else { newName = ""; newUrl = "" }
            }
        }

        // ---- Settings ----
        NeonCard {
            Text("Har creator se kitni nayi videos", color = Neon.Text, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 3, 5, 10).forEach { n ->
                    QualityChip("$n", perCreator == n, Modifier.weight(1f)) { if (!running) perCreator = n }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Quality", color = Neon.Text, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                qualities.forEach { q -> QualityChip(q, quality == q, Modifier.weight(1f)) { if (!running) quality = q } }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Random videos", color = Neon.Text, fontWeight = FontWeight.SemiBold)
                    Text("Latest 30 mein se random chunein", color = Neon.Muted, fontSize = 12.sp)
                }
                Switch(
                    checked = random,
                    onCheckedChange = { if (!running) random = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Neon.Purple,
                        uncheckedTrackColor = Neon.Bg1,
                        uncheckedBorderColor = Neon.Violet
                    )
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("🧹 Purani videos hatao", color = Neon.Text, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Nayi videos aate hi us creator ki purani videos delete",
                        color = Neon.Muted, fontSize = 12.sp
                    )
                }
                Switch(
                    checked = cleanOld,
                    onCheckedChange = { if (!running) cleanOld = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Neon.Purple,
                        uncheckedTrackColor = Neon.Bg1,
                        uncheckedBorderColor = Neon.Violet
                    )
                )
            }
        }

        // ---- List (search filter ke saath) ----
        val shown = creators.filter {
            query.isBlank() || it.name.contains(query.trim(), true) || it.url.contains(query.trim(), true)
        }
        val activeCount = creators.count { it.enabled }
        Text(
            "Meri list (${creators.size})  •  $activeCount on",
            color = Neon.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp
        )
        if (creators.isEmpty()) {
            Text("Abhi koi creator nahi. Search karein ya link se add karein.", color = Neon.Muted, fontSize = 13.sp)
        } else if (shown.isEmpty()) {
            Text("List mein \"$query\" naam ka koi creator nahi", color = Neon.Muted, fontSize = 13.sp)
        }
        shown.forEach { c ->
            CreatorRow(
                creator = c,
                result = results[c.id],
                active = running && currentId == c.id,
                busy = running,
                onToggle = {
                    val idx = creators.indexOfFirst { it.id == c.id }
                    if (idx >= 0) {
                        creators[idx] = c.copy(enabled = !c.enabled)
                        persist()
                        if (c.enabled) stopCurrentIf(c.id) // stop dabaya to chalti download bhi ruk jaye
                    }
                },
                onStart = {
                    if (running && currentId == c.id) {
                        // Isi creator ki chalti download rokein
                        Jobs.stopAll()
                    } else if (!running) {
                        runQueue(listOf(c.id), manual = true)
                    }
                },
                onEdit = { if (!running) editing = c },
                onSplit = { if (!running) splitting = c }
            )
        }

        // ---- START / STOP all ----
        val canStart = activeCount > 0 || running
        val shape = RoundedCornerShape(18.dp)
        Box(
            Modifier
                .fillMaxWidth()
                .height(58.dp)
                .shadow(if (canStart) 20.dp else 0.dp, shape, ambientColor = Neon.Purple, spotColor = Neon.Pink)
                .clip(shape)
                .background(if (canStart) Neon.Gradient else SolidColor(Neon.Card))
                .clickable(enabled = canStart) {
                    if (running) {
                        Jobs.stopAll()
                        return@clickable
                    }
                    runQueue(creators.map { it.id }, manual = false)
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (running) "■  SAB STOP" else "▶  START",
                color = if (canStart) Color.White else Neon.Muted,
                fontWeight = FontWeight.Black, fontSize = 17.sp, letterSpacing = 1.sp
            )
        }

        // ---- Progress ----
        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (running) creators.find { it.id == currentId }?.name ?: "" else "Total nayi: $totalNew",
                    color = Neon.Text, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${(progress * 100).toInt()}%",
                    style = TextStyle(brush = Neon.Gradient, fontSize = 22.sp, fontWeight = FontWeight.Black)
                )
            }
            Spacer(Modifier.height(10.dp))
            NeonProgressBar(progress, 8)
            Spacer(Modifier.height(8.dp))
            Text(status, color = Neon.Muted, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }

        Text(
            "History: $historyCount videos pehle download ho chuki hain (ye dobara nahi aayengi)",
            color = Neon.Muted, fontSize = 12.sp
        )
    }

    // ---- Split dialog ----
    splitting?.let { c ->
        SplitDialog(
            creator = c,
            onDismiss = { splitting = null },
            onSave = { on, sec ->
                val idx = creators.indexOfFirst { it.id == c.id }
                if (idx >= 0) creators[idx] = c.copy(split = on, splitSec = sec)
                persist()
                splitting = null
            }
        )
    }

    // ---- Edit dialog: naam, link, folder ----
    editing?.let { c ->
        EditCreatorDialog(
            creator = c,
            onDismiss = { editing = null },
            onSave = { edited ->
                // Naam badla aur folder purane naam wala tha, to folder bhi naye naam ka
                val updated = if (edited.name != c.name && edited.folder == defaultFolder(context, c.name))
                    edited.copy(folder = defaultFolder(context, edited.name)) else edited
                Engine.publicFolder(updated.base, updated.folder).mkdirs()
                val idx = creators.indexOfFirst { it.id == c.id }
                if (idx >= 0) creators[idx] = updated
                persist()
                editing = null
            },
            onDelete = {
                creators.removeAll { it.id == c.id }
                persist()
                editing = null
            }
        )
    }
}

@Composable
fun Avatar(name: String, sizeDp: Int) {
    Box(
        Modifier.size(sizeDp.dp).clip(CircleShape).background(Neon.Gradient),
        contentAlignment = Alignment.Center
    ) {
        Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Black, fontSize = (sizeDp / 2.3).sp)
    }
}

@Composable
fun SmallPill(label: String, filled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        label,
        color = if (filled) Color.White else Neon.Pink,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        modifier = Modifier
            .clip(shape)
            .then(if (filled) Modifier.background(Neon.Gradient) else Modifier.border(1.dp, Neon.Pink, shape))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    )
}

@Composable
fun CreatorRow(
    creator: Creator,
    result: String?,
    active: Boolean,
    busy: Boolean,
    onToggle: () -> Unit,
    onStart: () -> Unit,
    onEdit: () -> Unit,
    onSplit: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (creator.enabled) Neon.Card else Neon.Card.copy(alpha = 0.5f))
            .border(1.dp, if (active) Neon.Pink else Neon.Violet.copy(alpha = 0.35f), shape)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(creator.name, 34)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                creator.name,
                color = if (creator.enabled) Neon.Text else Neon.Muted,
                fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            val sub = when {
                result != null -> result
                !creator.enabled -> "⏸ Ruka hua"
                else -> "📁 ${creator.folder.substringAfterLast('/')}" +
                    (if (creator.split) "  •  ✂ ${Splitter.label(creator.splitSec)}" else "")
            }
            Text(
                sub,
                color = if (result != null) Neon.Pink else Neon.Muted,
                fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(6.dp))
        // ✂ Split (on ho to bhara hua)
        IconCircle("✂", filled = creator.split, onClick = onSplit)
        Spacer(Modifier.width(6.dp))
        // ⬇ Sirf isay abhi download karein (chalte waqt ■ = isay rokein)
        IconCircle(
            if (active) "■" else "⬇",
            filled = true,
            enabled = active || !busy,
            onClick = onStart
        )
        Spacer(Modifier.width(6.dp))
        // ⏸ / ▶  creator ko list mein on/off
        IconCircle(if (creator.enabled) "⏸" else "▶", filled = false, onClick = onToggle)
        Text(
            "⋮",
            color = Neon.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(CircleShape).clickable(onClick = onEdit).padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun IconCircle(icon: String, filled: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .then(
                if (filled && enabled) Modifier.background(Neon.Gradient)
                else Modifier.border(1.dp, (if (enabled) Neon.Pink else Neon.Muted).copy(alpha = 0.7f), CircleShape)
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            icon,
            color = if (filled && enabled) Color.White else if (enabled) Neon.Pink else Neon.Muted,
            fontSize = 14.sp, fontWeight = FontWeight.Bold
        )
    }
}

val splitPresets = listOf(15, 30, 60, 120, 180, 300, 600)

@Composable
fun SplitDialog(creator: Creator, onDismiss: () -> Unit, onSave: (Boolean, Int) -> Unit) {
    var on by remember { mutableStateOf(creator.split) }
    var sec by remember { mutableIntStateOf(creator.splitSec) }
    var custom by remember { mutableStateOf(if (creator.splitSec in splitPresets) "" else creator.splitSec.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Neon.Card,
        title = { Text("✂ ${creator.name} – Split", color = Neon.Text, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Split on", color = Neon.Text, fontWeight = FontWeight.SemiBold)
                        Text("Download ke baad video parts mein toot jayegi aur asal video delete ho jayegi", color = Neon.Muted, fontSize = 12.sp)
                    }
                    Switch(
                        checked = on, onCheckedChange = { on = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White, checkedTrackColor = Neon.Purple,
                            uncheckedTrackColor = Neon.Bg1, uncheckedBorderColor = Neon.Violet
                        )
                    )
                }
                Text("Har part ka time", color = Neon.Text, fontWeight = FontWeight.SemiBold)
                splitPresets.chunked(4).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        rowItems.forEach { p ->
                            QualityChip(Splitter.label(p), sec == p && custom.isBlank(), Modifier.weight(1f)) {
                                sec = p; custom = ""; on = true
                            }
                        }
                        repeat(4 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                NeonField(custom, { v ->
                    custom = v.filter { it.isDigit() }.take(5)
                    custom.toIntOrNull()?.let { if (it > 0) { sec = it; on = true } }
                }, "Apna time (seconds mein, jaise 45)")
                Text(
                    if (on) "Har video ${Splitter.label(sec)} ke parts mein tootegi" else "Split band hai, poori video save hogi",
                    color = Neon.Pink, fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(on && sec > 0, if (sec > 0) sec else 60) }) {
                Text("Save", color = Neon.Purple, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Neon.Muted) }
        }
    )
}

@Composable
fun EditCreatorDialog(
    creator: Creator,
    onDismiss: () -> Unit,
    onSave: (Creator) -> Unit,
    onDelete: () -> Unit
) {
    var name by remember { mutableStateOf(creator.name) }
    var url by remember { mutableStateOf(creator.url) }
    var base by remember { mutableStateOf(creator.base) }
    var folder by remember { mutableStateOf(creator.folder) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Neon.Card,
        title = { Text("Creator settings", color = Neon.Text, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonField(name, { name = it }, "Naam")
                NeonField(url, { url = it }, "Link")
                Text("📁 Save location", color = Neon.Text, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QualityChip("Download", base == "Download", Modifier.weight(1f)) { base = "Download" }
                    QualityChip("Documents", base == "Documents", Modifier.weight(1f)) { base = "Documents" }
                }
                NeonField(folder, { folder = it }, "Folder (jaise ABDownloader/MrBeast)")
                Text(
                    "Videos yahan jayengi: $base/${folder.trim().trim('/')}",
                    color = Neon.Muted, fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    creator.copy(
                        name = name.trim().ifBlank { creator.name },
                        url = url.trim().ifBlank { creator.url },
                        base = base,
                        folder = folder.trim().trim('/').ifBlank { creator.folder }
                    )
                )
            }) { Text("Save", color = Neon.Purple, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) { Text("Delete", color = Neon.Pink) }
                TextButton(onClick = onDismiss) { Text("Cancel", color = Neon.Muted) }
            }
        }
    )
}
