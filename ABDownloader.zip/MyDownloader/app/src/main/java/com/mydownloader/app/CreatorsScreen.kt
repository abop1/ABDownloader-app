package com.mydownloader.app

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// ================= Data =================

data class Creator(
    val id: String,
    val name: String,
    val url: String,
    val base: String,      // "Download" ya "Documents"
    val folder: String,    // jaise "ABDownloader/MrBeast"
    val enabled: Boolean,  // false = stop (skip hoga)
    val split: Boolean = false, // true = download ke baad parts mein todo
    val splitSec: Int = 60,     // har part kitne second ka
    val count: Int = 0          // 0 = settings wali ginti, warna is creator ki apni
)

fun safeName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "Creator" }

fun defaultFolder(ctx: Context, name: String) =
    ctx.getString(R.string.app_name).replace(" ", "") + "/" + safeName(name)

object CreatorStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("creators", Context.MODE_PRIVATE)

    fun fromJson(ctx: Context, arr: JSONArray): List<Creator> =
        (0 until arr.length()).mapNotNull {
            try {
                val o = arr.getJSONObject(it)
                val name = o.getString("name")
                Creator(
                    id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                    name = name,
                    url = o.getString("url"),
                    base = o.optString("base").ifBlank { "Download" },
                    folder = o.optString("folder").ifBlank { defaultFolder(ctx, name) },
                    enabled = o.optBoolean("enabled", true),
                    split = o.optBoolean("split", false),
                    splitSec = o.optInt("splitSec", 60),
                    count = o.optInt("count", 0)
                )
            } catch (e: Exception) { null }
        }

    fun toJson(list: List<Creator>): JSONArray {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)
                    .put("base", it.base).put("folder", it.folder).put("enabled", it.enabled)
                    .put("split", it.split).put("splitSec", it.splitSec).put("count", it.count)
            )
        }
        return arr
    }

    fun load(ctx: Context): List<Creator> = try {
        fromJson(ctx, JSONArray(prefs(ctx).getString("list", "[]")))
    } catch (e: Exception) {
        emptyList()
    }

    fun save(ctx: Context, list: List<Creator>) {
        prefs(ctx).edit().putString("list", toJson(list).toString()).apply()
    }
}

// Ek dafa download hui videos ki history (dobara download nahi hongi)
fun archiveFile(ctx: Context) = File(ctx.filesDir, "downloaded_history.txt")

fun countLines(f: File): Int = if (f.exists()) f.readLines().count { it.isNotBlank() } else 0

fun normalizeCreatorUrl(url: String): String {
    val u = url.trim().trimEnd('/')
    val isYtChannel = u.contains("youtube.com/@") || u.contains("youtube.com/channel/") || u.contains("youtube.com/c/")
    val hasTab = listOf("/videos", "/shorts", "/streams", "/playlist").any { u.contains(it) }
    return if (isYtChannel && !hasTab) "$u/videos" else u
}

data class CreatorResult(val videos: Int, val parts: Int, val deleted: Int = 0)

private val oldMediaExt = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp", "mp3", "m4a", "opus", "aac", "wav")

/**
 * TEZ SCAN: creator ke account ki videos ki list (sirf naam/link, video nahi) ek dafa
 * nikal kar 6 ghante ke liye phone mein yaad rakhta hai. Agli dafa list foran mil jati hai.
 */
object CreatorIndex {
    data class Entry(val id: String, val url: String)

    // Poori list hamesha yaad rehti hai (koi expiry nahi).
    // Har run par sirf upar ki 50 (nayi uploads) 2-3 second mein check hoti hain.
    private const val HEAD_SIZE = 50
    private const val HEAD_EVERY = 3L * 60 * 60 * 1000   // nayi uploads har 3 ghante mein ek dafa check
    private val building = java.util.Collections.synchronizedSet(HashSet<String>())
    private val oneAtATime = kotlinx.coroutines.sync.Mutex()

    private fun dir(ctx: Context) = File(ctx.filesDir, "index").apply { mkdirs() }
    private fun cacheFile(ctx: Context, c: Creator) = File(dir(ctx), "${c.id}.json")
    private fun fullTimeFile(ctx: Context, c: Creator) = File(dir(ctx), "${c.id}.full")
    private fun headTimeFile(ctx: Context, c: Creator) = File(dir(ctx), "${c.id}.head")

    private fun load(f: File): List<Entry> = try {
        val arr = JSONArray(f.readText())
        (0 until arr.length()).map { val o = arr.getJSONObject(it); Entry(o.getString("id"), o.getString("url")) }
    } catch (e: Exception) { emptyList() }

    private fun save(f: File, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("url", it.url)) }
        try { f.writeText(arr.toString()) } catch (e: Exception) { }
    }

    /** head = true: sirf sabse nayi 50 (ek page, bohat tez). false: poora account */
    private fun fetch(ctx: Context, c: Creator, pid: String, head: Boolean): List<Entry> {
        val req = YoutubeDLRequest(normalizeCreatorUrl(c.url)).apply {
            addOption("--flat-playlist")
            addOption("-J")
            addOption("--ignore-errors")
            addOption("--extractor-retries", "3")
            addOption("--socket-timeout", "30")
            Engine.applyGentle(this, c.url)
            if (head) {
                addOption("-I", "1:$HEAD_SIZE")
                addOption("--lazy-playlist")   // pehle page ke baad ruk jaye
            }
            if (Engine.hasLogin(ctx)) addOption("--cookies", Engine.cookiesFile(ctx).absolutePath)
        }
        val resp = YoutubeDL.getInstance().execute(req, pid, false, null)
        val list = ArrayList<Entry>()
        fun collect(arr: JSONArray?) {
            if (arr == null) return
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                val nested = e.optJSONArray("entries")
                if (nested != null) { collect(nested); continue }
                val id = e.optString("id")
                var url = e.optString("url").ifBlank { e.optString("webpage_url") }
                if (!url.startsWith("http") && id.isNotBlank()) {
                    url = if (c.url.contains("youtu", true)) "https://www.youtube.com/watch?v=$id" else ""
                }
                if (id.isNotBlank() && url.startsWith("http")) list += Entry(id, url)
            }
        }
        collect(JSONObject(resp.out).optJSONArray("entries"))
        return list
    }

    fun isComplete(ctx: Context, c: Creator) = fullTimeFile(ctx, c).exists()

    @Synchronized
    private fun mergeSave(ctx: Context, c: Creator, incoming: List<Entry>, replaceAll: Boolean): List<Entry> {
        val f = cacheFile(ctx, c)
        val cached = if (f.exists()) load(f) else emptyList()
        val result = if (replaceAll) {
            // Poori list aayi: us ke saath woh nayi bhi rakhein jo beech mein judi thin
            val ids = incoming.map { it.id }.toHashSet()
            cached.filter { it.id !in ids }.take(HEAD_SIZE) + incoming
        } else {
            val known = cached.map { it.id }.toHashSet()
            incoming.filter { it.id !in known } + cached
        }
        if (result.size != cached.size || replaceAll) save(f, result)
        return result
    }

    /** Poora account peeche (background) mein — download rukta nahi */
    private fun buildFullInBackground(ctx: Context, c: Creator) {
        if (!building.add(c.id)) return
        Jobs.scope.launch(Dispatchers.IO) {
            try {
                // Download chal raha ho to us ke khatam hone ka intezar (phone ki taqat download ko mile)
                while (Jobs.running) kotlinx.coroutines.delay(5000)
                oneAtATime.lock()
                val full = try {
                    fetch(ctx, c, "full_${c.id}_${System.currentTimeMillis()}", head = false)
                } finally { oneAtATime.unlock() }
                if (full.isNotEmpty()) {
                    mergeSave(ctx, c, full, replaceAll = true)
                    fullTimeFile(ctx, c).writeText("ok")
                }
            } catch (e: Exception) {
                // agli dafa phir koshish hogi
            } finally {
                building.remove(c.id)
            }
        }
    }

    /**
     * Foran list deta hai: upar ki nayi 50 + pehle se yaad rakhi list.
     * Agar poora account abhi yaad nahi, to woh peeche se ban'ta rehta hai.
     * waitFull = true: poori list ka intezar (sirf tab jab jaldi wali list khatam ho jaye)
     */
    fun get(ctx: Context, c: Creator, pid: String, waitFull: Boolean = false, forceHead: Boolean = false): List<Entry> {
        // Haal hi mein check hua tha: internet ke baghair foran yaad rakhi list
        val headFile = headTimeFile(ctx, c)
        val headAge = if (headFile.exists()) System.currentTimeMillis() - headFile.lastModified() else Long.MAX_VALUE
        if (!waitFull && !forceHead && headAge < HEAD_EVERY) {
            val f = cacheFile(ctx, c)
            val cached = if (f.exists()) load(f) else emptyList()
            if (cached.isNotEmpty()) {
                if (!isComplete(ctx, c)) buildFullInBackground(ctx, c)
                return cached
            }
        }
        if (waitFull && !isComplete(ctx, c)) {
            val full = fetch(ctx, c, pid + "_full", head = false)
            fullTimeFile(ctx, c).writeText("ok")
            return mergeSave(ctx, c, full, replaceAll = true)
        }
        val head = try {
            fetch(ctx, c, "${pid}_head", head = true)
        } catch (e: YoutubeDL.CanceledException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
        val merged = mergeSave(ctx, c, head, replaceAll = false)
        if (head.isNotEmpty()) try { headFile.writeText("ok") } catch (e: Exception) { }
        if (!isComplete(ctx, c)) buildFullInBackground(ctx, c)
        return merged
    }
}

/** Jo videos 2 dafa fail huin (photo post, delete, block) — dobara nahi chuni jayengi */
object BadVideos {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("bad_videos", Context.MODE_PRIVATE)
    private val idRx = Regex("ERROR: \\[[^\\]]+\\] ([A-Za-z0-9_-]{5,}):")

    fun recordFrom(ctx: Context, errorText: String?) {
        if (errorText.isNullOrBlank()) return
        val ids = idRx.findAll(errorText).map { it.groupValues[1] }.toSet()
        if (ids.isEmpty()) return
        val p = prefs(ctx); val e = p.edit()
        ids.forEach { e.putInt(it, p.getInt(it, 0) + 1) }
        e.apply()
    }

    fun blocked(ctx: Context): Set<String> =
        prefs(ctx).all.filter { (it.value as? Int ?: 0) >= 2 }.keys
}

/** History file mein se download ho chuki videos ki IDs */
fun downloadedIds(ctx: Context): Set<String> {
    val f = archiveFile(ctx)
    if (!f.exists()) return emptySet()
    return f.readLines().mapNotNull { it.trim().substringAfterLast(' ').ifBlank { null } }.toHashSet()
}

/** Ek creator ki nayi videos (+ split + purani safai). */
fun downloadFromCreator(
    ctx: Context,
    creator: Creator,
    count: Int,
    random: Boolean,
    quality: String,
    processId: String,
    cleanOld: Boolean = false,
    onProgress: (Float, String) -> Unit
): CreatorResult {
    val folder = Engine.publicFolder(creator.base, creator.folder)
    folder.mkdirs()
    val oldFiles = folder.listFiles()
        ?.filter { it.isFile && it.extension.lowercase() in oldMediaExt }
        ?: emptyList()
    val archive = archiveFile(ctx)
    val newFilesList = File(ctx.cacheDir, "new_$processId.txt")
    newFilesList.delete()

    // ---- 1) Tez list: kaunsi videos abhi tak download nahi huin ----
    onProgress(-1f, "Videos ki list dekhi ja rahi hai...")
    val done = downloadedIds(ctx)
    val bad = BadVideos.blocked(ctx)
    var entries = CreatorIndex.get(ctx, creator, "${processId}_list")
    var fresh = entries.filter { it.id !in done && it.id !in bad }
    if (fresh.isEmpty() && CreatorIndex.isComplete(ctx, creator)) {
        // Yaad rakhi list khatam — shayad nayi uploads aayi hon
        onProgress(-1f, "Nayi uploads check ho rahi hain...")
        entries = CreatorIndex.get(ctx, creator, "${processId}_head2", forceHead = true)
        fresh = entries.filter { it.id !in done && it.id !in bad }
    }
    if (fresh.isEmpty() && !CreatorIndex.isComplete(ctx, creator)) {
        // Upar ki sab videos ho chuki aur poori list abhi bani nahi — us ka intezar
        onProgress(-1f, "Purani videos ki list dekhi ja rahi hai...")
        entries = CreatorIndex.get(ctx, creator, "${processId}_list2", waitFull = true)
        fresh = entries.filter { it.id !in done && it.id !in bad }
    }
    if (entries.isEmpty()) throw Exception("Is account se videos ki list nahi mili")
    if (fresh.isEmpty()) return CreatorResult(0, 0)

    val picked = (if (random) fresh.shuffled() else fresh).take(count * 3 + 3) // extra, agar koi fail ho

    // ---- 2) Sirf chuni hui videos download ----
    fun attempt(pid: String, urls: List<String>, want: Int): String? {
        val request = YoutubeDLRequest(urls).apply {
            addOption("-o", folder.absolutePath + "/%(title).70s [%(id)s].%(ext)s")
            addOption("--download-archive", archive.absolutePath)
            addOption("--max-downloads", want.toString())
            addOption("--ignore-errors")
            addOption("--no-simulate")
            addCommands(listOf("--print-to-file", "after_move:filepath", newFilesList.absolutePath))
            addCommands(Titles.command(ctx))   // caption ke liye asal title yaad rakhein
            Engine.applyRobust(this, ctx)
            Engine.applyGentle(this, creator.url)
            Engine.applyQuality(this, quality)
        }
        return try {
            YoutubeDL.getInstance().execute(request, pid, false) { p, _, line -> onProgress(p, line) }
            null
        } catch (e: YoutubeDL.CanceledException) {
            throw e
        } catch (e: Exception) {
            val m = e.message ?: "Unknown error"
            BadVideos.recordFrom(ctx, m)   // jo videos fail huin unhein yaad rakho
            if (m.contains("Maximum number of downloads")) null else m
        }
    }
    fun newCount() = if (newFilesList.exists()) newFilesList.readLines().map { it.trim() }.filter { it.isNotEmpty() }.distinct().size else 0

    var error = attempt(processId, picked.map { it.url }, count)
    if (newCount() == 0 && error != null && Jobs.activeCount() <= 1) {
        // Sirf tab engine update jab koi aur creator download na ho raha ho
        onProgress(-1f, "Masla aaya, engine update karke dobara try...")
        Engine.update(ctx)
        error = attempt(processId + "_r", picked.map { it.url }, count)
    }
    val added = newCount()
    Titles.invalidate()
    if (added == 0 && error != null) throw Exception(error.take(200))

    // ---- 3) Split ----
    var parts = 0
    if (creator.split && creator.splitSec > 0 && newFilesList.exists()) {
        val files = newFilesList.readLines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        files.forEachIndexed { i, path ->
            onProgress(-1f, "✂ Split ho rahi hai (${i + 1}/${files.size}): ${File(path).name}")
            parts += Splitter.split(ctx, File(path), creator.splitSec)
        }
    }
    newFilesList.delete()

    // ---- 4) Purani videos delete (sirf jab nayi aa chuki hon) ----
    var deleted = 0
    if (cleanOld && added > 0) {
        oldFiles.forEach { if (it.exists() && it.delete()) deleted++ }
    }
    return CreatorResult(added, parts, deleted)
}

// ================= UI =================

@Composable
fun CreatorsScreen() {
    val context = LocalContext.current
    val creators = Jobs.creators
    val results = Jobs.results
    fun persist() = Jobs.saveCreators(context)
    val running = Jobs.running

    var query by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Creator?>(null) }
    var splitting by remember { mutableStateOf<Creator?>(null) }
    var errorFor by remember { mutableStateOf<Creator?>(null) }

    fun addCreator(name: String, url: String): String? {
        val u = url.trim()
        if (!u.startsWith("http")) return "Sahi link daalein (https:// se shuru)"
        if (creators.any { it.url.trimEnd('/') == u.trimEnd('/') }) return "Ye creator pehle se list mein hai"
        val n = name.trim().ifBlank { u.trimEnd('/').substringAfterLast("/").removePrefix("@").ifBlank { "Creator" } }
        val folder = defaultFolder(context, n)
        creators.add(Creator(UUID.randomUUID().toString(), n, u, "Download", folder, true))
        Engine.publicFolder("Download", folder).mkdirs()
        persist()
        return null
    }

    val activeOn = creators.count { it.enabled }
    val shown = creators.filter {
        query.isBlank() || it.name.contains(query.trim(), true) || it.url.contains(query.trim(), true)
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp)
                .padding(bottom = 150.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ScreenTitle("Creators", "${creators.size} creators  •  $activeOn on") {
                IconBtn(Icons.Rounded.Search, filled = showSearch) { showSearch = !showSearch; if (!showSearch) query = "" }
                Spacer(Modifier.width(8.dp))
                IconBtn(Icons.Rounded.Add, filled = true, enabled = !running) { showAdd = true }
            }
            if (showSearch) NeonField(query, { query = it }, "List mein dhoondein")

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("${Jobs.totalNew}", "Is dafa nayi", Modifier.weight(1f))
                StatBox("${Jobs.historyCount}", "Kul download", Modifier.weight(1f))
                StatBox("${Jobs.parallel}x", "Ek saath", Modifier.weight(1f))
            }

            when {
                creators.isEmpty() -> NeonCard {
                    Text("Abhi koi creator nahi", color = Neon.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Creator add karein, phir START dabayein. Nayi videos khud aa jayengi.", color = Neon.Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    GlowButton("＋  PEHLA CREATOR ADD KAREIN") { showAdd = true }
                }
                shown.isEmpty() -> Text("\"$query\" naam ka koi creator nahi", color = Neon.Muted, fontSize = 13.sp)
            }

            shown.forEach { c ->
                CreatorRow(
                    creator = c,
                    result = results[c.id],
                    active = Jobs.active.containsKey(c.id),
                    busy = running,
                    onToggle = {
                        val idx = creators.indexOfFirst { it.id == c.id }
                        if (idx >= 0) {
                            creators[idx] = c.copy(enabled = !c.enabled)
                            persist()
                            if (c.enabled) Jobs.stopCurrentIf(c.id)
                        }
                    },
                    onStart = {
                        if (Jobs.active.containsKey(c.id)) Jobs.stopCurrentIf(c.id)
                        else if (!running) Jobs.runQueue(context, listOf(c.id), manual = true)
                    },
                    onEdit = { if (!running) editing = c },
                    onSplit = { if (!running) splitting = c },
                    onShowError = { errorFor = c }
                )
            }
        }

        // ---- Neeche chipka hua control panel ----
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Neon.Bg2.copy(alpha = 0.95f), Neon.Bg2)))
                .padding(start = 18.dp, end = 18.dp, top = 28.dp, bottom = 12.dp)
        ) {
            if (running) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "⚡ ${Jobs.active.size} chal rahe  •  ${Jobs.doneCount}/${Jobs.totalCount} mukammal",
                        color = Neon.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                    )
                    Text(
                        "${(Jobs.progress * 100).toInt()}%",
                        style = TextStyle(brush = Neon.Gradient, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    )
                }
                Spacer(Modifier.height(6.dp))
                NeonProgressBar(Jobs.progress, 6)
                Spacer(Modifier.height(4.dp))
                Text(Jobs.status, color = Neon.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                GlowButton("SAB STOP", icon = Icons.Rounded.Stop) { Jobs.stopAll() }
            } else {
                if (Jobs.totalCount > 0 || Jobs.status.startsWith("📶") || Jobs.status.startsWith("💾")) {
                    Text(Jobs.status, color = Neon.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                }
                GlowButton("START  ($activeOn)", enabled = activeOn > 0, icon = Icons.Rounded.RocketLaunch) {
                    Jobs.runQueue(context, creators.map { it.id }, manual = false)
                }
            }
        }
    }

    errorFor?.let { c ->
        val full = Jobs.errors[c.id] ?: ""
        AlertDialog(
            onDismissRequest = { errorFor = null },
            containerColor = Neon.Card,
            title = { Text("ⓘ ${c.name}", color = Neon.Text, fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    Text(Engine.friendlyError(full), color = Neon.Pink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Text("Kya karein:", color = Neon.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "1. Settings → 🛠 Download engine update\n2. TikTok/Instagram ho to Settings → 🔑 Login\n" +
                            "3. 'Ek saath' 1 ya 2 rakhein\n4. Thori der baad ⬇ se sirf isi creator ko chalayein",
                        color = Neon.Muted, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("Poori tafseel:", color = Neon.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(full.takeLast(1500).ifBlank { "—" }, color = Neon.Muted, fontSize = 10.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { copyText(context, full); errorFor = null }) {
                    Text("📋 Copy", color = Neon.Purple, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { errorFor = null }) { Text("Theek hai", color = Neon.Muted) } }
        )
    }

    if (showAdd) {
        AddCreatorDialog(
            existing = creators,
            onDismiss = { showAdd = false },
            onAdd = { n, u -> addCreator(n, u) }
        )
    }

    splitting?.let { c ->
        SplitDialog(
            creator = c,
            onDismiss = { splitting = null },
            onSave = { on, sec ->
                val idx = creators.indexOfFirst { it.id == c.id }
                if (idx >= 0) creators[idx] = c.copy(split = on, splitSec = sec)
                persist()
                splitting = null
            }
        )
    }

    editing?.let { c ->
        EditCreatorDialog(
            creator = c,
            onDismiss = { editing = null },
            onSave = { edited ->
                val updated = if (edited.name != c.name && edited.folder == defaultFolder(context, c.name))
                    edited.copy(folder = defaultFolder(context, edited.name)) else edited
                Engine.publicFolder(updated.base, updated.folder).mkdirs()
                val idx = creators.indexOfFirst { it.id == c.id }
                if (idx >= 0) creators[idx] = updated
                persist()
                editing = null
            },
            onDelete = {
                creators.removeAll { it.id == c.id }
                persist()
                editing = null
            }
        )
    }
}

/** Naya creator: link se ya YouTube search se */
@Composable
fun AddCreatorDialog(existing: List<Creator>, onDismiss: () -> Unit, onAdd: (String, String) -> String?) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    var online by remember { mutableStateOf<List<FoundCreator>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        val shape = RoundedCornerShape(24.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 640.dp)
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Neon.Card2, Neon.Card)))
                .border(1.dp, Neon.Violet.copy(alpha = 0.7f), shape)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "＋ Naya creator", modifier = Modifier.weight(1f),
                    style = TextStyle(brush = Neon.Gradient, fontSize = 22.sp, fontWeight = FontWeight.Black)
                )
                Text("✕", color = Neon.Muted, fontSize = 20.sp,
                    modifier = Modifier.clip(CircleShape).clickable(onClick = onDismiss).padding(8.dp))
            }

            SectionLabel("🔗 Link se")
            NeonField(name, { name = it; err = "" }, "Naam (jaise MrBeast)")
            NeonField(url, { url = it; err = "" }, "Channel / profile link")
            if (err.isNotEmpty()) Text(err, color = Neon.Pink, fontSize = 12.sp)
            GlowButton("ADD KAREIN", enabled = url.isNotBlank()) {
                val e = onAdd(name, url)
                if (e == null) onDismiss() else err = e
            }

            SectionLabel("🌐 YouTube par dhoondein")
            NeonField(q, { q = it; msg = "" }, "Creator ka naam")
            NeonOutlineButton(if (searching) "Dhoond rahe hain..." else "🔍  Dhoondein", Modifier.fillMaxWidth()) {
                if (searching || q.isBlank()) return@NeonOutlineButton
                searching = true; msg = ""
                scope.launch {
                    val res = withContext(Dispatchers.IO) { try { searchYouTubeCreators(q.trim()) } catch (e: Exception) { null } }
                    searching = false
                    if (res == null) msg = "Search nahi hua, internet check karein"
                    else { online = res; if (res.isEmpty()) msg = "Koi creator nahi mila" }
                }
            }
            if (msg.isNotEmpty()) Text(msg, color = Neon.Pink, fontSize = 12.sp)
            online.forEach { f ->
                val added = existing.any { it.url.trimEnd('/') == f.url.trimEnd('/') }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(f.name, 32)
                    Spacer(Modifier.width(10.dp))
                    Text(f.name, color = Neon.Text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    SmallPill(if (added) "✓ Added" else "＋ Add", filled = !added) {
                        if (!added) onAdd(f.name, f.url)
                    }
                }
            }
        }
    }
}

@Composable
fun SmallPill(label: String, filled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        label,
        color = if (filled) Color.White else Neon.Pink,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        modifier = Modifier
            .clip(shape)
            .then(if (filled) Modifier.background(Neon.Gradient) else Modifier.border(1.dp, Neon.Pink, shape))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    )
}

@Composable
fun CreatorRow(
    creator: Creator,
    result: String?,
    active: Boolean,
    busy: Boolean,
    onToggle: () -> Unit,
    onStart: () -> Unit,
    onEdit: () -> Unit,
    onSplit: () -> Unit,
    onShowError: () -> Unit = {}
) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (creator.enabled) Neon.Card else Neon.Card.copy(alpha = 0.5f))
            .border(1.dp, if (active) Neon.Pink else Neon.Violet.copy(alpha = 0.35f), shape)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(creator.name, 34)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                creator.name,
                color = if (creator.enabled) Neon.Text else Neon.Muted,
                fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            val sub = when {
                result != null -> result
                !creator.enabled -> "⏸ Ruka hua"
                else -> "📁 ${creator.folder.substringAfterLast('/')}" +
                    (if (creator.count > 0) "  •  🎬 ${creator.count}" else "") +
                    (if (creator.split) "  •  ✂ ${Splitter.label(creator.splitSec)}" else "")
            }
            val isErr = result?.startsWith("✕") == true
            Text(
                if (isErr) "$sub  ⓘ" else sub,
                color = if (result != null) Neon.Pink else Neon.Muted,
                fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = if (isErr) Modifier.clickable(onClick = onShowError) else Modifier
            )
        }
        Spacer(Modifier.width(6.dp))
        // ✂ Split (on ho to bhara hua)
        IconBtn(Icons.Rounded.ContentCut, filled = creator.split, size = 32, onClick = onSplit)
        Spacer(Modifier.width(6.dp))
        // ⬇ Sirf isay abhi download karein (chalte waqt ■ = isay rokein)
        IconBtn(
            if (active) Icons.Rounded.Stop else Icons.Rounded.Download,
            filled = true, size = 32,
            enabled = active || !busy,
            onClick = onStart
        )
        Spacer(Modifier.width(6.dp))
        IconBtn(if (creator.enabled) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, filled = false, size = 32, onClick = onToggle)
        Icon(
            Icons.Rounded.MoreVert, "Settings", tint = Neon.Text,
            modifier = Modifier.clip(CircleShape).clickable(onClick = onEdit).padding(6.dp)
        )
    }
}

@Composable
fun IconCircle(icon: String, filled: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .then(
                if (filled && enabled) Modifier.background(Neon.Gradient)
                else Modifier.border(1.dp, (if (enabled) Neon.Pink else Neon.Muted).copy(alpha = 0.7f), CircleShape)
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            icon,
            color = if (filled && enabled) Color.White else if (enabled) Neon.Pink else Neon.Muted,
            fontSize = 14.sp, fontWeight = FontWeight.Bold
        )
    }
}

val splitPresets = listOf(15, 30, 60, 120, 180, 300, 600)

@Composable
fun SplitDialog(creator: Creator, onDismiss: () -> Unit, onSave: (Boolean, Int) -> Unit) {
    var on by remember { mutableStateOf(creator.split) }
    var sec by remember { mutableIntStateOf(creator.splitSec) }
    var custom by remember { mutableStateOf(if (creator.splitSec in splitPresets) "" else creator.splitSec.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Neon.Card,
        title = { Text("✂ ${creator.name} – Split", color = Neon.Text, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Split on", color = Neon.Text, fontWeight = FontWeight.SemiBold)
                        Text("Download ke baad video parts mein toot jayegi aur asal video delete ho jayegi", color = Neon.Muted, fontSize = 12.sp)
                    }
                    Switch(
                        checked = on, onCheckedChange = { on = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White, checkedTrackColor = Neon.Purple,
                            uncheckedTrackColor = Neon.Bg1, uncheckedBorderColor = Neon.Violet
                        )
                    )
                }
                Text("Har part ka time", color = Neon.Text, fontWeight = FontWeight.SemiBold)
                splitPresets.chunked(4).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        rowItems.forEach { p ->
                            QualityChip(Splitter.label(p), sec == p && custom.isBlank(), Modifier.weight(1f)) {
                                sec = p; custom = ""; on = true
                            }
                        }
                        repeat(4 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                NeonField(custom, { v ->
                    custom = v.filter { it.isDigit() }.take(5)
                    custom.toIntOrNull()?.let { if (it > 0) { sec = it; on = true } }
                }, "Apna time (seconds mein, jaise 45)")
                Text(
                    if (on) "Har video ${Splitter.label(sec)} ke parts mein tootegi" else "Split band hai, poori video save hogi",
                    color = Neon.Pink, fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(on && sec > 0, if (sec > 0) sec else 60) }) {
                Text("Save", color = Neon.Purple, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Neon.Muted) }
        }
    )
}

@Composable
fun EditCreatorDialog(
    creator: Creator,
    onDismiss: () -> Unit,
    onSave: (Creator) -> Unit,
    onDelete: () -> Unit
) {
    var name by remember { mutableStateOf(creator.name) }
    var url by remember { mutableStateOf(creator.url) }
    var base by remember { mutableStateOf(creator.base) }
    var folder by remember { mutableStateOf(creator.folder) }
    var count by remember { mutableIntStateOf(creator.count) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Neon.Card,
        title = { Text("Creator settings", color = Neon.Text, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonField(name, { name = it }, "Naam")
                NeonField(url, { url = it }, "Link")
                Text("🎬 Is creator se kitni videos", color = Neon.Text, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0, 1, 3, 5, 10).forEach { n ->
                        QualityChip(if (n == 0) "Auto" else "$n", count == n, Modifier.weight(1f)) { count = n }
                    }
                }
                Text(
                    if (count == 0) "Auto = upar settings wali ginti" else "Har dafa $count nayi videos",
                    color = Neon.Muted, fontSize = 11.sp
                )
                Text("📁 Save location", color = Neon.Text, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QualityChip("Download", base == "Download", Modifier.weight(1f)) { base = "Download" }
                    QualityChip("Documents", base == "Documents", Modifier.weight(1f)) { base = "Documents" }
                }
                NeonField(folder, { folder = it }, "Folder (jaise ABDownloader/MrBeast)")
                Text(
                    "Videos yahan jayengi: $base/${folder.trim().trim('/')}",
                    color = Neon.Muted, fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    creator.copy(
                        name = name.trim().ifBlank { creator.name },
                        url = url.trim().ifBlank { creator.url },
                        base = base,
                        folder = folder.trim().trim('/').ifBlank { creator.folder },
                        count = count
                    )
                )
            }) { Text("Save", color = Neon.Purple, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) { Text("Delete", color = Neon.Pink) }
                TextButton(onClick = onDismiss) { Text("Cancel", color = Neon.Muted) }
            }
        }
    )
}
